/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: dlm_medika
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `causer_type` varchar(255) DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `attribute_changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attribute_changes`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
(1,'satuan','created','App\\Models\\Unit',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pieces\",\"symbol\":\"pcs\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'satuan','created','App\\Models\\Unit',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Box\",\"symbol\":\"box\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'satuan','created','App\\Models\\Unit',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Unit\",\"symbol\":\"unit\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'satuan','created','App\\Models\\Unit',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Set\",\"symbol\":\"set\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'satuan','created','App\\Models\\Unit',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pack\",\"symbol\":\"pack\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'satuan','created','App\\Models\\Unit',6,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Lusin\",\"symbol\":\"lsn\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'kategori','created','App\\Models\\Category',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'kategori','created','App\\Models\\Category',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Non Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'kategori','created','App\\Models\\Category',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Diagnostik In Vitro\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'kategori','created','App\\Models\\Category',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alat Laboratorium\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'kategori','created','App\\Models\\Category',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Consumable Medis\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'produk','created','App\\Models\\Product',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0001\",\"name\":\"Masker Bedah 3 Ply (Box 50)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"22000.00\",\"sell_price\":\"35000.00\",\"min_stock\":\"50.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'produk','created','App\\Models\\Product',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0002\",\"name\":\"Sarung Tangan Latex Steril (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"65000.00\",\"sell_price\":\"95000.00\",\"min_stock\":\"30.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'produk','created','App\\Models\\Product',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0003\",\"name\":\"Spuit \\/ Syringe 3ml (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"48000.00\",\"sell_price\":\"72000.00\",\"min_stock\":\"25.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'produk','created','App\\Models\\Product',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0004\",\"name\":\"Infus Set Dewasa\",\"category_id\":1,\"unit_id\":1,\"cost_price\":\"4500.00\",\"sell_price\":\"8000.00\",\"min_stock\":\"100.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'produk','created','App\\Models\\Product',5,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0005\",\"name\":\"Kasa Steril 16x16 (Pack)\",\"category_id\":1,\"unit_id\":5,\"cost_price\":\"3500.00\",\"sell_price\":\"6500.00\",\"min_stock\":\"80.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'produk','created','App\\Models\\Product',6,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0006\",\"name\":\"Rapid Test Antigen (Box 25)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"210000.00\",\"sell_price\":\"320000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'produk','created','App\\Models\\Product',7,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0007\",\"name\":\"Tabung Vacutainer EDTA (Box 100)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"85000.00\",\"sell_price\":\"130000.00\",\"min_stock\":\"15.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'produk','created','App\\Models\\Product',8,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0008\",\"name\":\"Alkohol Swab (Box 100)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"9000.00\",\"sell_price\":\"16000.00\",\"min_stock\":\"40.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'produk','created','App\\Models\\Product',9,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0009\",\"name\":\"Termometer Digital\",\"category_id\":4,\"unit_id\":3,\"cost_price\":\"28000.00\",\"sell_price\":\"55000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'produk','created','App\\Models\\Product',10,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0010\",\"name\":\"Pinset Anatomis Stainless\",\"category_id\":2,\"unit_id\":1,\"cost_price\":\"15000.00\",\"sell_price\":\"30000.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'pelanggan','created','App\\Models\\Customer',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0001\",\"name\":\"RS Medika Sentosa\",\"phone\":\"021-5551001\",\"npwp\":\"01.234.567.8-091.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'pelanggan','created','App\\Models\\Customer',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0002\",\"name\":\"Klinik Sehat Bersama\",\"phone\":\"021-5552002\",\"npwp\":\"02.345.678.9-091.000\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'pelanggan','created','App\\Models\\Customer',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0003\",\"name\":\"Apotek Kimia Farmasi\",\"phone\":\"0812-1111-2222\",\"npwp\":\"\",\"payment_term_days\":7,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'pelanggan','created','App\\Models\\Customer',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0004\",\"name\":\"Puskesmas Serpong\",\"phone\":\"021-5553003\",\"npwp\":\"\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'supplier','created','App\\Models\\Supplier',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0001\",\"name\":\"PT Onemed Distribusi\",\"phone\":\"021-7770001\",\"npwp\":\"03.111.222.3-093.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'supplier','created','App\\Models\\Supplier',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0002\",\"name\":\"PT Enseval Medika Prima\",\"phone\":\"021-7770002\",\"npwp\":\"04.222.333.4-093.000\",\"payment_term_days\":45,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'supplier','created','App\\Models\\Supplier',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0003\",\"name\":\"CV Sumber Medis Jaya\",\"phone\":\"0813-3333-4444\",\"npwp\":\"\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'pelanggan','created','App\\Models\\Customer',5,'created','App\\Models\\User',1,'{\"attributes\":{\"code\":\"CUST-0005\",\"name\":\"joko\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 00:01:34','2026-07-13 00:01:34'),
(30,'satuan','created','App\\Models\\Unit',7,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:28:55','2026-07-13 12:28:55'),
(31,'satuan','updated','App\\Models\\Unit',7,'updated','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Vial\",\"symbol\":\"Vial\"},\"old\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:29:17','2026-07-13 12:29:17'),
(32,'produk','created','App\\Models\\Product',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:07','2026-07-13 12:41:07'),
(33,'produk','created','App\\Models\\Product',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:50','2026-07-13 12:41:50'),
(34,'produk','created','App\\Models\\Product',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:42:38','2026-07-13 12:42:38'),
(35,'produk','created','App\\Models\\Product',14,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:43:21','2026-07-13 12:43:21'),
(36,'produk','created','App\\Models\\Product',15,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:44:26','2026-07-13 12:44:26'),
(37,'produk','created','App\\Models\\Product',16,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:45:59','2026-07-13 12:45:59'),
(38,'produk','created','App\\Models\\Product',17,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:46:53','2026-07-13 12:46:53'),
(39,'produk','created','App\\Models\\Product',18,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:48:42','2026-07-13 12:48:42'),
(40,'produk','created','App\\Models\\Product',19,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:49:31','2026-07-13 12:49:31'),
(41,'pelanggan','created','App\\Models\\Customer',6,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0006\",\"name\":\"PT Amanah Husada Pamulang\",\"phone\":null,\"npwp\":\"66.376.297.9-411.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 12:57:55','2026-07-13 12:57:55'),
(42,'pelanggan','created','App\\Models\\Customer',7,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0007\",\"name\":\"PT Allaya Mandiri Sejahtera\",\"phone\":null,\"npwp\":\"902616440452000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 13:10:48','2026-07-13 13:10:48'),
(43,'produk','deleted','App\\Models\\Product',17,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:02','2026-07-13 13:13:02'),
(44,'produk','deleted','App\\Models\\Product',15,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:09','2026-07-13 13:13:09'),
(45,'produk','deleted','App\\Models\\Product',16,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:13','2026-07-13 13:13:13'),
(46,'produk','created','App\\Models\\Product',20,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0020\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"245000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:15:32','2026-07-13 13:15:32'),
(47,'produk','created','App\\Models\\Product',21,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0021\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:01','2026-07-13 13:16:01'),
(48,'produk','created','App\\Models\\Product',22,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0022\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:39','2026-07-13 13:16:39'),
(49,'produk','deleted','App\\Models\\Product',18,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:15','2026-07-13 13:18:15'),
(50,'produk','created','App\\Models\\Product',23,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0023\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:18:47','2026-07-13 13:18:47'),
(51,'produk','deleted','App\\Models\\Product',19,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:58','2026-07-13 13:18:58'),
(52,'produk','created','App\\Models\\Product',24,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0024\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:19:25','2026-07-13 13:19:25'),
(53,'produk','deleted','App\\Models\\Product',12,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:19:36','2026-07-13 13:19:36'),
(54,'produk','created','App\\Models\\Product',25,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:20','2026-07-13 13:20:20'),
(55,'produk','deleted','App\\Models\\Product',25,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:41','2026-07-13 13:20:41'),
(56,'produk','created','App\\Models\\Product',26,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:21:11','2026-07-13 13:21:11'),
(57,'produk','deleted','App\\Models\\Product',11,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:21:16','2026-07-13 13:21:16'),
(58,'produk','created','App\\Models\\Product',27,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0027\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:22:25','2026-07-13 13:22:25'),
(59,'produk','updated','App\\Models\\Product',26,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"299999.99\"},\"old\":{\"cost_price\":\"350000.00\"}}','[]','2026-07-13 13:22:39','2026-07-13 13:22:39'),
(60,'produk','deleted','App\\Models\\Product',13,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:23:01','2026-07-13 13:23:01'),
(61,'satuan','created','App\\Models\\Unit',8,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Botol\",\"symbol\":\"btl\"}}','[]','2026-07-13 13:23:41','2026-07-13 13:23:41'),
(62,'produk','created','App\\Models\\Product',28,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0028\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:24:50','2026-07-13 13:24:50'),
(63,'produk','deleted','App\\Models\\Product',14,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:24:57','2026-07-13 13:24:57'),
(64,'produk','created','App\\Models\\Product',29,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:32','2026-07-13 13:25:32'),
(65,'produk','deleted','App\\Models\\Product',29,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:54','2026-07-13 13:25:54'),
(66,'produk','created','App\\Models\\Product',30,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:26:28','2026-07-13 13:26:28'),
(67,'pelanggan','created','App\\Models\\Customer',8,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0008\",\"name\":\"RSIA Vitalaya\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:09:33','2026-07-13 14:09:33'),
(68,'pelanggan','created','App\\Models\\Customer',9,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0009\",\"name\":\"RS Citra Insani\",\"phone\":null,\"npwp\":\"O23803026403000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:10:42','2026-07-13 14:10:42'),
(69,'pelanggan','updated','App\\Models\\Customer',9,'updated','App\\Models\\User',3,'{\"attributes\":{\"payment_term_days\":30},\"old\":{\"payment_term_days\":0}}','[]','2026-07-13 14:11:06','2026-07-13 14:11:06'),
(70,'pelanggan','created','App\\Models\\Customer',10,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0010\",\"name\":\"RS BHAYANGKARA\",\"phone\":null,\"npwp\":\"1237767013000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 14:12:57','2026-07-13 14:12:57'),
(71,'pelanggan','created','App\\Models\\Customer',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0011\",\"name\":\"PT Nauli Sejahtera Medika\",\"phone\":null,\"npwp\":\"86.947.018.7-452.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:16:43','2026-07-13 14:16:43'),
(72,'supplier','created','App\\Models\\Supplier',4,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0004\",\"name\":\"Sarana Maju Sejahtera\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:48:51','2026-07-13 14:48:51'),
(73,'pelanggan','created','App\\Models\\Customer',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0012\",\"name\":\"Permata Alkes\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 15:59:32','2026-07-13 15:59:32'),
(74,'produk','updated','App\\Models\\Product',26,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"300000.00\",\"sell_price\":\"375000.00\"},\"old\":{\"cost_price\":\"299999.99\",\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:01:41','2026-07-13 16:01:41'),
(75,'produk','updated','App\\Models\\Product',27,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"600000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:01','2026-07-13 16:02:01'),
(76,'produk','updated','App\\Models\\Product',28,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"400000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:16','2026-07-13 16:02:16'),
(77,'produk','updated','App\\Models\\Product',30,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"700000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:37','2026-07-13 16:02:37'),
(78,'produk','created','App\\Models\\Product',31,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0031\",\"name\":\"Probe Cleanser Lifotronik\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 16:03:40','2026-07-13 16:03:40'),
(79,'produk','created','App\\Models\\Product',32,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0032\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"120000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 16:04:43','2026-07-13 16:04:43'),
(80,'produk','updated','App\\Models\\Product',31,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"50000.00\",\"sell_price\":\"150000.00\"},\"old\":{\"cost_price\":\"0.00\",\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:05:27','2026-07-13 16:05:27'),
(81,'produk','deleted','App\\Models\\Product',7,'deleted','App\\Models\\User',1,'{\"old\":{\"code\":\"PRD-0007\",\"name\":\"Tabung Vacutainer EDTA (Box 100)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"85000.00\",\"sell_price\":\"130000.00\",\"min_stock\":\"15.00\",\"is_active\":true}}','[]','2026-07-13 22:05:02','2026-07-13 22:05:02'),
(82,'produk','updated','App\\Models\\Product',31,'updated','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Probe Cleanser Lifotronic (50 ML)\"},\"old\":{\"name\":\"Probe Cleanser Lifotronik\"}}','[]','2026-07-14 10:33:01','2026-07-14 10:33:01'),
(83,'produk','deleted','App\\Models\\Product',27,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0027\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:38:54','2026-07-14 10:38:54'),
(84,'produk','created','App\\Models\\Product',33,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0033\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:40:11','2026-07-14 10:40:11'),
(85,'produk','deleted','App\\Models\\Product',26,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:40:39','2026-07-14 10:40:39'),
(86,'produk','created','App\\Models\\Product',34,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0034\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"267000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:42:10','2026-07-14 10:42:10'),
(87,'produk','deleted','App\\Models\\Product',28,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0028\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"330000.00\",\"sell_price\":\"400000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:42:22','2026-07-14 10:42:22'),
(88,'produk','created','App\\Models\\Product',35,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0035\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:43:15','2026-07-14 10:43:15'),
(89,'produk','deleted','App\\Models\\Product',32,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0032\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"120000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:44:21','2026-07-14 10:44:21'),
(90,'produk','created','App\\Models\\Product',36,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0036\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:45:37','2026-07-14 10:45:37'),
(91,'produk','deleted','App\\Models\\Product',24,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0024\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:46:21','2026-07-14 10:46:21'),
(92,'produk','created','App\\Models\\Product',37,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0037\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:00','2026-07-14 10:47:00'),
(93,'produk','deleted','App\\Models\\Product',23,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0023\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:13','2026-07-14 10:47:13'),
(94,'produk','created','App\\Models\\Product',38,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0038\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:44','2026-07-14 10:47:44'),
(95,'produk','created','App\\Models\\Product',39,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0039\",\"name\":\"Diluent Labnova\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:48:55','2026-07-14 10:48:55'),
(96,'produk','created','App\\Models\\Product',40,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0040\",\"name\":\"Lyse Labnova\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:49:47','2026-07-14 10:49:47'),
(97,'produk','created','App\\Models\\Product',41,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0041\",\"name\":\"Lyse M-52DIFF Mindray\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:50:32','2026-07-14 10:50:32'),
(98,'produk','created','App\\Models\\Product',42,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0042\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:53:49','2026-07-14 10:53:49'),
(99,'produk','created','App\\Models\\Product',43,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:08','2026-07-14 10:54:08'),
(100,'produk','deleted','App\\Models\\Product',43,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:17','2026-07-14 10:54:17'),
(101,'produk','created','App\\Models\\Product',44,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:27','2026-07-14 10:54:27'),
(102,'produk','created','App\\Models\\Product',45,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0045\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:29','2026-07-14 10:54:29'),
(103,'produk','deleted','App\\Models\\Product',44,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:37','2026-07-14 10:54:37'),
(104,'produk','deleted','App\\Models\\Product',45,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0045\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:53','2026-07-14 10:54:53'),
(105,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3},\"old\":{\"category_id\":null}}','[]','2026-07-14 10:55:05','2026-07-14 10:55:05'),
(106,'produk','created','App\\Models\\Product',46,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:55:38','2026-07-14 10:55:38'),
(107,'produk','created','App\\Models\\Product',47,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0047\",\"name\":\"VITAMIN D (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:56:16','2026-07-14 10:56:16'),
(108,'produk','deleted','App\\Models\\Product',1,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0001\",\"name\":\"Masker Bedah 3 Ply (Box 50)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"22000.00\",\"sell_price\":\"35000.00\",\"min_stock\":\"50.00\",\"is_active\":true}}','[]','2026-07-14 10:56:55','2026-07-14 10:56:55'),
(109,'produk','deleted','App\\Models\\Product',5,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0005\",\"name\":\"Kasa Steril 16x16 (Pack)\",\"category_id\":1,\"unit_id\":5,\"cost_price\":\"3500.00\",\"sell_price\":\"6500.00\",\"min_stock\":\"80.00\",\"is_active\":true}}','[]','2026-07-14 10:57:02','2026-07-14 10:57:02'),
(110,'produk','deleted','App\\Models\\Product',8,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0008\",\"name\":\"Alkohol Swab (Box 100)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"9000.00\",\"sell_price\":\"16000.00\",\"min_stock\":\"40.00\",\"is_active\":true}}','[]','2026-07-14 10:57:09','2026-07-14 10:57:09'),
(111,'produk','deleted','App\\Models\\Product',4,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0004\",\"name\":\"Infus Set Dewasa\",\"category_id\":1,\"unit_id\":1,\"cost_price\":\"4500.00\",\"sell_price\":\"8000.00\",\"min_stock\":\"100.00\",\"is_active\":true}}','[]','2026-07-14 10:57:21','2026-07-14 10:57:21'),
(112,'produk','deleted','App\\Models\\Product',10,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0010\",\"name\":\"Pinset Anatomis Stainless\",\"category_id\":2,\"unit_id\":1,\"cost_price\":\"15000.00\",\"sell_price\":\"30000.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-14 10:57:32','2026-07-14 10:57:32'),
(113,'produk','deleted','App\\Models\\Product',2,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0002\",\"name\":\"Sarung Tangan Latex Steril (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"65000.00\",\"sell_price\":\"95000.00\",\"min_stock\":\"30.00\",\"is_active\":true}}','[]','2026-07-14 10:57:40','2026-07-14 10:57:40'),
(114,'produk','deleted','App\\Models\\Product',3,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0003\",\"name\":\"Spuit \\/ Syringe 3ml (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"48000.00\",\"sell_price\":\"72000.00\",\"min_stock\":\"25.00\",\"is_active\":true}}','[]','2026-07-14 10:57:48','2026-07-14 10:57:48'),
(115,'produk','updated','App\\Models\\Product',42,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"1026000.00\"},\"old\":{\"cost_price\":\"0.00\"}}','[]','2026-07-14 11:12:54','2026-07-14 11:12:54'),
(116,'supplier','created','App\\Models\\Supplier',5,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0005\",\"name\":\"pak egi\",\"phone\":\"08131081203\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 11:16:05','2026-07-14 11:16:05'),
(117,'produk','deleted','App\\Models\\Product',9,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0009\",\"name\":\"Termometer Digital\",\"category_id\":4,\"unit_id\":3,\"cost_price\":\"28000.00\",\"sell_price\":\"55000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-14 11:25:23','2026-07-14 11:25:23'),
(118,'produk','deleted','App\\Models\\Product',6,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0006\",\"name\":\"Rapid Test Antigen (Box 25)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"210000.00\",\"sell_price\":\"320000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-14 11:25:30','2026-07-14 11:25:30'),
(119,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"is_active\":false},\"old\":{\"is_active\":true}}','[]','2026-07-14 11:29:03','2026-07-14 11:29:03'),
(120,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"is_active\":true},\"old\":{\"is_active\":false}}','[]','2026-07-14 11:29:16','2026-07-14 11:29:16'),
(121,'produk','deleted','App\\Models\\Product',47,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0047\",\"name\":\"VITAMIN D (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:30:13','2026-07-14 11:30:13'),
(122,'produk','updated','App\\Models\\Product',37,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"60000.00\"},\"old\":{\"cost_price\":\"0.00\"}}','[]','2026-07-14 11:30:35','2026-07-14 11:30:35'),
(123,'supplier','created','App\\Models\\Supplier',6,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0006\",\"name\":\"PT ARDHIKA UMRAN ABADI\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 11:40:03','2026-07-14 11:40:03'),
(124,'produk','created','App\\Models\\Product',48,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0047\",\"name\":\"Arumamed Dliuent 5-Diff\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"1709400.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:44:14','2026-07-14 11:44:14'),
(125,'produk','updated','App\\Models\\Product',48,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"2200000.00\"},\"old\":{\"cost_price\":\"1709400.00\"}}','[]','2026-07-14 11:52:22','2026-07-14 11:52:22'),
(126,'produk','created','App\\Models\\Product',49,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0049\",\"name\":\"Arumamed LD Lyse 5-Diff\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"5000000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:55:24','2026-07-14 11:55:24'),
(127,'produk','created','App\\Models\\Product',50,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0050\",\"name\":\"Arumamed LH Lyse 5-Diff\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"2600000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:56:27','2026-07-14 11:56:27'),
(128,'produk','created','App\\Models\\Product',51,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0051\",\"name\":\"Arumamed Probe Cleaser\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"750000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:58:02','2026-07-14 11:58:02'),
(129,'produk','created','App\\Models\\Product',52,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0052\",\"name\":\"Arumamed Hematology  Control Normal 5-Diff\",\"category_id\":3,\"unit_id\":7,\"cost_price\":\"2400000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:59:09','2026-07-14 11:59:09'),
(130,'supplier','created','App\\Models\\Supplier',7,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0007\",\"name\":\"PT Demaz Noer Abadi\",\"phone\":\"085814390858\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:20:34','2026-07-14 12:20:34'),
(131,'produk','created','App\\Models\\Product',53,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0053\",\"name\":\"Vitamin D SD Biosensor\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 12:21:38','2026-07-14 12:21:38'),
(132,'supplier','created','App\\Models\\Supplier',8,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0008\",\"name\":\"Rumah Sakit Ibu dan Anak Dhia\",\"phone\":\"081282103297\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:27:08','2026-07-14 12:27:08'),
(133,'pelanggan','created','App\\Models\\Customer',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0013\",\"name\":\"Rumah Sakit Ibu dan Anak Dhia\",\"phone\":\"081282103297\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:28:09','2026-07-14 12:28:09'),
(134,'produk','deleted','App\\Models\\Product',22,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0022\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:42','2026-07-14 13:02:42'),
(135,'produk','deleted','App\\Models\\Product',20,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0020\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"245000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:46','2026-07-14 13:02:46'),
(136,'produk','deleted','App\\Models\\Product',21,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0021\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:50','2026-07-14 13:02:50'),
(137,'produk','deleted','App\\Models\\Product',30,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"700000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:03:46','2026-07-14 13:03:46'),
(138,'produk','deleted','App\\Models\\Product',39,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0039\",\"name\":\"Diluent Labnova\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:08','2026-07-14 13:04:08'),
(139,'produk','deleted','App\\Models\\Product',40,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0040\",\"name\":\"Lyse Labnova\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:21','2026-07-14 13:04:21'),
(140,'produk','deleted','App\\Models\\Product',33,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0033\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:29','2026-07-14 13:04:29'),
(141,'produk','deleted','App\\Models\\Product',34,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0034\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"267000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:46','2026-07-14 13:04:46'),
(142,'produk','deleted','App\\Models\\Product',37,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0037\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:53','2026-07-14 13:04:53'),
(143,'produk','deleted','App\\Models\\Product',38,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0038\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:59','2026-07-14 13:04:59'),
(144,'produk','deleted','App\\Models\\Product',42,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0042\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"1026000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:11','2026-07-14 13:05:11'),
(145,'produk','deleted','App\\Models\\Product',36,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0036\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:18','2026-07-14 13:05:18'),
(146,'produk','deleted','App\\Models\\Product',31,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0031\",\"name\":\"Probe Cleanser Lifotronic (50 ML)\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"50000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:31','2026-07-14 13:05:31'),
(147,'produk','deleted','App\\Models\\Product',35,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0035\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:06:03','2026-07-14 13:06:03'),
(148,'produk','deleted','App\\Models\\Product',46,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:06:10','2026-07-14 13:06:10'),
(149,'produk','created','App\\Models\\Product',54,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0054\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:07:27','2026-07-14 13:07:27'),
(150,'produk','created','App\\Models\\Product',55,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0055\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:07:50','2026-07-14 13:07:50'),
(151,'produk','created','App\\Models\\Product',56,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0056\",\"name\":\"Lyse Mindray M30\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:09','2026-07-14 13:08:09'),
(152,'produk','created','App\\Models\\Product',57,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0057\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:23','2026-07-14 13:08:23'),
(153,'produk','created','App\\Models\\Product',58,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0058\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:33','2026-07-14 13:08:33'),
(154,'produk','created','App\\Models\\Product',59,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0059\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:48','2026-07-14 13:08:48'),
(155,'produk','created','App\\Models\\Product',60,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0060\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:09:35','2026-07-14 13:09:35'),
(156,'produk','created','App\\Models\\Product',61,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0061\",\"name\":\"Diluent Labnovation\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:10:10','2026-07-14 13:10:10'),
(157,'produk','created','App\\Models\\Product',62,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0062\",\"name\":\"Lyse Labnovation\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:10:34','2026-07-14 13:10:34'),
(158,'produk','updated','App\\Models\\Product',56,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3,\"unit_id\":8},\"old\":{\"category_id\":null,\"unit_id\":null}}','[]','2026-07-14 13:11:06','2026-07-14 13:11:06'),
(159,'produk','updated','App\\Models\\Product',62,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3,\"unit_id\":8},\"old\":{\"category_id\":null,\"unit_id\":null}}','[]','2026-07-14 13:11:15','2026-07-14 13:11:15'),
(160,'produk','created','App\\Models\\Product',63,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0063\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:12:00','2026-07-14 13:12:00'),
(161,'produk','created','App\\Models\\Product',64,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0064\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:12:11','2026-07-14 13:12:11'),
(162,'supplier','created','App\\Models\\Supplier',9,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0009\",\"name\":\"CV. SAMZIO NUSA MEDIKA\",\"phone\":\"0816 1794 2649\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:17:00','2026-07-14 13:17:00'),
(163,'supplier','created','App\\Models\\Supplier',10,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0010\",\"name\":\"PT LIFOTRONIC TECHNOLOGY INDONESIA\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:26:02','2026-07-14 13:26:02'),
(164,'supplier','created','App\\Models\\Supplier',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0011\",\"name\":\"PT. ERA MEDIKA AKESINDO\",\"phone\":null,\"npwp\":\"91.542.645.6-125.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:34:39','2026-07-14 13:34:39'),
(165,'supplier','created','App\\Models\\Supplier',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0012\",\"name\":\"PT Andalas Prima Sentosa\",\"phone\":\"089611918823\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 14:34:54','2026-07-14 14:34:54'),
(166,'produk','created','App\\Models\\Product',65,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0065\",\"name\":\"Cuvette Segment\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:36:14','2026-07-14 14:36:14'),
(167,'produk','created','App\\Models\\Product',66,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0066\",\"name\":\"Thermal Paper Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:36:51','2026-07-14 14:36:51'),
(168,'produk','created','App\\Models\\Product',67,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0067\",\"name\":\"Gluc Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:37:24','2026-07-14 14:37:24'),
(169,'produk','created','App\\Models\\Product',68,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0068\",\"name\":\"Cleaner Cobas C111\",\"category_id\":null,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:38:02','2026-07-14 14:38:02'),
(170,'produk','created','App\\Models\\Product',69,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0069\",\"name\":\"Cleaner Basic Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:38:45','2026-07-14 14:38:45'),
(171,'produk','created','App\\Models\\Product',70,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0070\",\"name\":\"Creap Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:39:09','2026-07-14 14:39:09'),
(172,'produk','created','App\\Models\\Product',71,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0071\",\"name\":\"HDL C4 Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:39:34','2026-07-14 14:39:34'),
(173,'produk','created','App\\Models\\Product',72,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0072\",\"name\":\"Triglyceride\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:07','2026-07-14 14:40:07'),
(174,'produk','created','App\\Models\\Product',73,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0073\",\"name\":\"Ureal Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:23','2026-07-14 14:40:23'),
(175,'produk','created','App\\Models\\Product',74,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0074\",\"name\":\"Cholestrol Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:50','2026-07-14 14:40:50'),
(176,'produk','created','App\\Models\\Product',75,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0075\",\"name\":\"HBA1C SD Biosensor\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 15:55:34','2026-07-14 15:55:34');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('pt-dimas-love-medika-cache-admin@rafli.com|127.0.0.1','i:1;',1784002185),
('pt-dimas-love-medika-cache-admin@rafli.com|127.0.0.1:timer','i:1784002185;',1784002185),
('pt-dimas-love-medika-cache-settings.all','a:18:{s:12:\"company_name\";s:20:\"PT DIMAS LOVE MEDIKA\";s:12:\"company_npwp\";s:19:\"1000 0000 0468 5165\";s:11:\"company_nib\";s:13:\"0108250170791\";s:12:\"company_izin\";s:17:\"01082501707910001\";s:12:\"company_kbli\";s:71:\"46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia\";s:15:\"company_address\";s:116:\"Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310\";s:13:\"company_phone\";s:29:\"021-38939414 / 0859-3319-1346\";s:13:\"company_email\";s:21:\"anggihdimas@gmail.com\";s:11:\"company_pjt\";s:37:\"Nia Love Fiana Puteri (D.III Farmasi)\";s:8:\"ppn_rate\";s:2:\"11\";s:19:\"fp_transaction_code\";s:2:\"04\";s:9:\"fp_prefix\";s:0:\"\";s:14:\"fp_last_serial\";s:2:\"11\";s:14:\"fp_serial_year\";s:2:\"26\";s:9:\"bank_name\";s:8:\"Bank BCA\";s:15:\"bank_account_no\";s:10:\"8011111629\";s:19:\"bank_account_holder\";s:20:\"PT DIMAS LOVE MEDIKA\";s:13:\"director_name\";s:16:\"M Anggih Dimas W\";}',2099362500),
('pt-dimas-love-medika-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:45:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:13:\"products.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:15:\"products.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"products.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:15:\"products.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:15:\"categories.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:17:\"categories.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:17:\"categories.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:17:\"categories.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:10:\"units.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:12:\"units.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:12:\"units.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:12:\"units.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:14:\"customers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:16:\"customers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:16:\"customers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:16:\"customers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:14:\"suppliers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:16:\"suppliers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:16:\"suppliers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:16:\"suppliers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:17:\"sales-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:19:\"sales-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:19:\"sales-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:19:\"sales-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:15:\"invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:15:\"invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:15:\"invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:20:\"purchase-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:29;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:22:\"purchase-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:30;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:22:\"purchase-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:31;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:22:\"purchase-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:17:\"tax-invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:33;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:19:\"tax-invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:34;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:19:\"tax-invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:19:\"tax-invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:15:\"quotations.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:37;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:17:\"quotations.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:38;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:17:\"quotations.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:39;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:17:\"quotations.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:40;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:19:\"reports.operational\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:41;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:15:\"reports.finance\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:42;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:15:\"settings.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:43;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:12:\"users.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:44;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:17:\"transactions.void\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:2:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"Admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"Staff\";s:1:\"c\";s:3:\"web\";}}}',1784041455);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Alkes Nonelektromedik Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Alkes Nonelektromedik Non Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Alkes Diagnostik In Vitro',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Alat Laboratorium',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Consumable Medis',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_payments`
--

DROP TABLE IF EXISTS `customer_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_payments_invoice_id_foreign` (`invoice_id`),
  KEY `customer_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `customer_payments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_payments`
--

LOCK TABLES `customer_payments` WRITE;
/*!40000 ALTER TABLE `customer_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'CUST-0001','RS Medika Sentosa','dr. Andi','021-5551001',NULL,NULL,'01.234.567.8-091.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'CUST-0002','Klinik Sehat Bersama','Ibu Rina','021-5552002',NULL,NULL,'02.345.678.9-091.000',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'CUST-0003','Apotek Kimia Farmasi','Bpk. Joko','0812-1111-2222',NULL,NULL,'',7,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'CUST-0004','Puskesmas Serpong','Ibu Sari','021-5553003',NULL,NULL,'',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'CUST-0005','joko',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 00:01:34','2026-07-13 00:01:34'),
(6,'CUST-0006','PT Amanah Husada Pamulang',NULL,NULL,NULL,'Jl Raya Siliwangi 1A Pondok Benda Pamulang Kota Tangerang Selatan Banten','66.376.297.9-411.000',30,1,'2026-07-13 12:57:55','2026-07-13 12:57:55'),
(7,'CUST-0007','PT Allaya Mandiri Sejahtera',NULL,NULL,NULL,'Ruko Mardi Grass Citra Raya KF 02, 02 Mekar Bakti Panongan Kab Tangerang Banten 15757\r\nTangerang Banten','902616440452000',0,1,'2026-07-13 13:10:48','2026-07-13 13:10:48'),
(8,'CUST-0008','RSIA Vitalaya',NULL,NULL,NULL,'Jl. Siliwangi No.50, Pd. Benda, Kec. Pamulang, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-13 14:09:33','2026-07-13 14:09:33'),
(9,'CUST-0009','RS Citra Insani',NULL,NULL,NULL,'Jl. Permata Lb. Wangi Jl. Raya Parung No.242, Pamegarsari, Kec. Parung, Kabupaten Bogor, Jawa Barat','O23803026403000',30,1,'2026-07-13 14:10:42','2026-07-13 14:11:06'),
(10,'CUST-0010','RS BHAYANGKARA',NULL,NULL,NULL,'Jl. Ciputat Raya No.40, RT.1/RW.9, Pd. Pinang, Kec. Kebayoran Lama, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12310','1237767013000',30,1,'2026-07-13 14:12:57','2026-07-13 14:12:57'),
(11,'CUST-0011','PT Nauli Sejahtera Medika',NULL,NULL,NULL,'Ruko golden Road Jl Pahlawan Seribu BSD City (Sektor VII.C) C32,22 Lengkong Wetan Serpong Tangerang Selatan Banten','86.947.018.7-452.000',0,1,'2026-07-13 14:16:43','2026-07-13 14:16:43'),
(12,'CUST-0012','Permata Alkes',NULL,NULL,NULL,'Komplek Permata Cimahi Jalan Mutiara 1 Nomor 19 Blok C1 RT 06 RW 12 tanimulya Kecamatan ngamprah Bandung',NULL,0,1,'2026-07-13 15:59:32','2026-07-13 15:59:32'),
(13,'CUST-0013','Rumah Sakit Ibu dan Anak Dhia',NULL,'081282103297',NULL,'Jl. Cendrawasih Raya No.90, Sawah Lama, Kec. Ciputat, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-14 12:28:09','2026-07-14 12:28:09');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipt_items`
--

DROP TABLE IF EXISTS `goods_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipt_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` bigint(20) unsigned NOT NULL,
  `purchase_order_item_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `goods_receipt_items_goods_receipt_id_foreign` (`goods_receipt_id`),
  KEY `goods_receipt_items_purchase_order_item_id_foreign` (`purchase_order_item_id`),
  KEY `goods_receipt_items_product_id_foreign` (`product_id`),
  CONSTRAINT `goods_receipt_items_goods_receipt_id_foreign` FOREIGN KEY (`goods_receipt_id`) REFERENCES `goods_receipts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipt_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `goods_receipt_items_purchase_order_item_id_foreign` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `purchase_order_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipt_items`
--

LOCK TABLES `goods_receipt_items` WRITE;
/*!40000 ALTER TABLE `goods_receipt_items` DISABLE KEYS */;
INSERT INTO `goods_receipt_items` VALUES
(1,1,1,41,2.00,'2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,2,12,53,1.00,'2026-07-14 12:23:50','2026-07-14 12:23:50'),
(3,3,13,58,29.00,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(4,3,14,55,6.00,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(5,4,15,57,21.00,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(6,4,16,54,28.00,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(7,5,17,63,12.00,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(8,5,18,64,4.00,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(9,6,19,61,1.00,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(10,6,20,62,1.00,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(11,7,21,59,5.00,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(12,7,22,60,1.00,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(13,8,31,69,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(14,8,32,71,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(15,8,33,67,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(16,9,34,75,2.00,'2026-07-14 15:59:02','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `goods_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipts`
--

DROP TABLE IF EXISTS `goods_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gr_number` varchar(255) NOT NULL,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `goods_receipts_gr_number_unique` (`gr_number`),
  KEY `goods_receipts_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `goods_receipts_warehouse_id_foreign` (`warehouse_id`),
  KEY `goods_receipts_user_id_foreign` (`user_id`),
  CONSTRAINT `goods_receipts_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `goods_receipts_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipts`
--

LOCK TABLES `goods_receipts` WRITE;
/*!40000 ALTER TABLE `goods_receipts` DISABLE KEYS */;
INSERT INTO `goods_receipts` VALUES
(1,'GR/2607/00001',1,1,3,'2026-07-14',NULL,'2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,'GR/2607/00002',3,1,3,'2026-07-14',NULL,'2026-07-14 12:23:50','2026-07-14 12:23:50'),
(3,'GR/2607/00003',4,1,3,'2026-07-14',NULL,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(4,'GR/2607/00004',5,1,3,'2026-07-14',NULL,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(5,'GR/2607/00005',6,1,3,'2026-07-14',NULL,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(6,'GR/2607/00006',7,1,3,'2026-07-14',NULL,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(7,'GR/2607/00007',8,1,3,'2026-07-14',NULL,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(8,'GR/2607/00008',10,1,3,'2026-07-14',NULL,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(9,'GR/2607/00009',11,1,3,'2026-07-14',NULL,'2026-07-14 15:59:02','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `goods_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'unpaid',
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_sales_order_id_foreign` (`sales_order_id`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'INV/2607/00001',1,3,'2026-07-14','2026-07-14','unpaid',2600000.00,0.00,NULL,'2026-07-14 11:22:05','2026-07-14 11:22:05'),
(2,'INV/2607/00002',2,3,'2026-07-14','2026-08-13','unpaid',2000000.00,0.00,NULL,'2026-07-14 12:29:30','2026-07-14 12:29:30');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_07_10_142631_create_activity_log_table',1),
(5,'2026_07_10_142631_create_permission_tables',1),
(6,'2026_07_11_000001_create_categories_table',1),
(7,'2026_07_11_000002_create_units_table',1),
(8,'2026_07_11_000003_create_warehouses_table',1),
(9,'2026_07_11_000004_create_products_table',1),
(10,'2026_07_11_000005_create_customers_table',1),
(11,'2026_07_11_000006_create_suppliers_table',1),
(12,'2026_07_11_000007_create_settings_table',1),
(13,'2026_07_12_000001_create_stock_movements_table',1),
(14,'2026_07_12_000002_create_purchase_orders_table',1),
(15,'2026_07_12_000003_create_purchase_order_items_table',1),
(16,'2026_07_12_000004_create_goods_receipts_table',1),
(17,'2026_07_12_000005_create_supplier_payments_table',1),
(18,'2026_07_12_000006_create_sales_orders_table',1),
(19,'2026_07_12_000007_create_sales_order_items_table',1),
(20,'2026_07_12_000008_create_invoices_table',1),
(21,'2026_07_12_000009_create_customer_payments_table',1),
(22,'2026_07_13_000001_create_tax_invoices_table',1),
(23,'2026_07_13_000002_create_quotations_table',1),
(24,'2026_07_13_000003_add_due_date_to_purchase_orders_table',2),
(25,'2026_07_13_000004_add_due_date_to_sales_orders_table',2),
(26,'2026_07_13_000005_add_invoice_fields_to_supplier_payments_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1),
(1,'App\\Models\\User',3),
(2,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'products.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(2,'products.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(3,'products.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(4,'products.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(5,'categories.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(6,'categories.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(7,'categories.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(8,'categories.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(9,'units.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(10,'units.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'units.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'units.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'customers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'customers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'customers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'customers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'suppliers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'suppliers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'suppliers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'suppliers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'sales-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'sales-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'sales-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'sales-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'purchase-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(30,'purchase-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(31,'purchase-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(32,'purchase-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(33,'tax-invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(34,'tax-invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(35,'tax-invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(36,'tax-invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(37,'quotations.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(38,'quotations.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(39,'quotations.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(40,'quotations.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(41,'reports.operational','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(42,'reports.finance','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(43,'settings.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(44,'users.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(45,'transactions.void','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `cost_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sell_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `min_stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_unit_id_foreign` (`unit_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(41,'PRD-0041','Lyse M-52DIFF Mindray',3,NULL,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-14 10:50:32','2026-07-14 11:29:16'),
(48,'PRD-0047','Arumamed Dliuent 5-Diff',3,2,2200000.00,0.00,0.00,0.00,NULL,'size 20L',1,'2026-07-14 11:44:14','2026-07-14 11:57:05'),
(49,'PRD-0049','Arumamed LD Lyse 5-Diff',3,8,5000000.00,0.00,0.00,0.00,NULL,'SIZE 1L',1,'2026-07-14 11:55:23','2026-07-14 11:57:18'),
(50,'PRD-0050','Arumamed LH Lyse 5-Diff',3,8,2600000.00,0.00,0.00,0.00,NULL,'size 200ml',1,'2026-07-14 11:56:27','2026-07-14 11:56:27'),
(51,'PRD-0051','Arumamed Probe Cleaser',3,2,750000.00,0.00,0.00,0.00,NULL,'SIZE 50ML',1,'2026-07-14 11:58:02','2026-07-14 11:58:02'),
(52,'PRD-0052','Arumamed Hematology  Control Normal 5-Diff',3,7,2400000.00,0.00,0.00,0.00,NULL,'size 3ml',1,'2026-07-14 11:59:09','2026-07-14 11:59:09'),
(53,'PRD-0053','Vitamin D SD Biosensor',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 12:21:38','2026-07-14 12:29:14'),
(54,'PRD-0054','Lyse Lifotronic',3,8,0.00,0.00,28.00,0.00,NULL,NULL,1,'2026-07-14 13:07:27','2026-07-14 13:29:39'),
(55,'PRD-0055','Lyse Mindray M10',3,8,0.00,0.00,6.00,0.00,NULL,NULL,1,'2026-07-14 13:07:50','2026-07-14 13:19:52'),
(56,'PRD-0056','Lyse Mindray M30',3,8,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 13:08:09','2026-07-14 13:11:06'),
(57,'PRD-0057','Diluent Lifotronic',3,2,0.00,0.00,21.00,0.00,NULL,NULL,1,'2026-07-14 13:08:23','2026-07-14 13:29:39'),
(58,'PRD-0058','Diluent Mindray',3,2,0.00,0.00,29.00,0.00,NULL,NULL,1,'2026-07-14 13:08:33','2026-07-14 13:19:52'),
(59,'PRD-0059','TSH-II FIA (SD)',3,2,0.00,0.00,5.00,0.00,NULL,NULL,1,'2026-07-14 13:08:48','2026-07-14 13:54:44'),
(60,'PRD-0060','HS-CRP (SD)',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:09:35','2026-07-14 13:54:44'),
(61,'PRD-0061','Diluent Labnovation',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:10:10','2026-07-14 13:45:32'),
(62,'PRD-0062','Lyse Labnovation',3,8,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:10:34','2026-07-14 13:45:32'),
(63,'PRD-0063','Vacutube EDTA',3,2,0.00,0.00,12.00,0.00,NULL,NULL,1,'2026-07-14 13:12:00','2026-07-14 13:40:20'),
(64,'PRD-0064','Vacutube Plain (Tabung Merah)',3,2,0.00,0.00,4.00,0.00,NULL,NULL,1,'2026-07-14 13:12:11','2026-07-14 13:40:20'),
(65,'PRD-0065','Cuvette Segment',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:36:14','2026-07-14 14:36:14'),
(66,'PRD-0066','Thermal Paper Cobas C111',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:36:51','2026-07-14 14:36:51'),
(67,'PRD-0067','Gluc Cobas C111',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 14:37:24','2026-07-14 14:59:13'),
(68,'PRD-0068','Cleaner Cobas C111',NULL,8,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:38:02','2026-07-14 14:38:02'),
(69,'PRD-0069','Cleaner Basic Cobas C111',NULL,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 14:38:45','2026-07-14 14:59:13'),
(70,'PRD-0070','Creap Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:39:09','2026-07-14 14:39:09'),
(71,'PRD-0071','HDL C4 Cobas C111',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 14:39:34','2026-07-14 14:59:13'),
(72,'PRD-0072','Triglyceride',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:40:07','2026-07-14 14:40:07'),
(73,'PRD-0073','Ureal Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:40:23','2026-07-14 14:40:23'),
(74,'PRD-0074','Cholestrol Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:40:50','2026-07-14 14:40:50'),
(75,'PRD-0075','HBA1C SD Biosensor',NULL,2,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-14 15:55:34','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `qty_received` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cost_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_items_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `purchase_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `purchase_order_items_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES
(1,1,41,2.00,2.00,800000.00,0.00,1600000.00,'2026-07-14 11:17:09','2026-07-14 11:17:28'),
(7,2,48,1.00,0.00,2200000.00,660000.00,1540000.00,'2026-07-14 12:13:32','2026-07-14 12:13:32'),
(8,2,52,1.00,0.00,2400000.00,720000.00,1680000.00,'2026-07-14 12:13:32','2026-07-14 12:13:32'),
(9,2,49,1.00,0.00,5000000.00,1500000.00,3500000.00,'2026-07-14 12:13:32','2026-07-14 12:13:32'),
(10,2,50,1.00,0.00,2600000.00,780000.00,1820000.00,'2026-07-14 12:13:32','2026-07-14 12:13:32'),
(11,2,51,1.00,0.00,750000.00,225000.00,525000.00,'2026-07-14 12:13:32','2026-07-14 12:13:32'),
(12,3,53,1.00,1.00,2000000.00,500000.00,1500000.00,'2026-07-14 12:22:38','2026-07-14 12:23:50'),
(13,4,58,29.00,29.00,500000.00,0.00,14500000.00,'2026-07-14 13:18:56','2026-07-14 13:19:52'),
(14,4,55,6.00,6.00,630000.00,0.00,3780000.00,'2026-07-14 13:18:56','2026-07-14 13:19:52'),
(15,5,57,21.00,21.00,267000.00,0.00,5607000.00,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(16,5,54,28.00,28.00,300000.00,0.00,8400000.00,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(17,6,63,12.00,12.00,60000.00,0.00,720000.00,'2026-07-14 13:37:23','2026-07-14 13:40:20'),
(18,6,64,4.00,4.00,60000.00,0.00,240000.00,'2026-07-14 13:37:23','2026-07-14 13:40:20'),
(19,7,61,1.00,1.00,840000.00,0.00,840000.00,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(20,7,62,1.00,1.00,528000.00,0.00,528000.00,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(21,8,59,5.00,5.00,972973.00,243243.00,4621622.00,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(22,8,60,1.00,1.00,1760000.00,440000.00,1320000.00,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(23,9,74,1.00,0.00,735000.00,36750.00,698250.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(24,9,68,1.00,0.00,1558000.00,77900.00,1480100.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(25,9,70,1.00,0.00,692000.00,34600.00,657400.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(26,9,66,1.00,0.00,152000.00,7600.00,144400.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(27,9,72,1.00,0.00,498000.00,24900.00,473100.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(28,9,73,1.00,0.00,870000.00,43500.00,826500.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(29,9,67,3.00,0.00,518000.00,25900.00,1528100.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(30,9,65,2.00,0.00,3056000.00,152800.00,5959200.00,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(31,10,69,1.00,1.00,540000.00,27000.00,513000.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(32,10,71,1.00,1.00,1629000.00,81450.00,1547550.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(33,10,67,1.00,1.00,518000.00,25900.00,492100.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(34,11,75,2.00,2.00,1000000.00,500000.00,1500000.00,'2026-07-14 15:58:13','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `po_number` varchar(255) NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_orders_po_number_unique` (`po_number`),
  KEY `purchase_orders_supplier_id_foreign` (`supplier_id`),
  KEY `purchase_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES
(1,'PO/2607/00001',5,3,'2026-07-14','2026-07-14','received',0,11.00,1600000.00,0.00,1600000.00,0.00,1600000.00,1600000.00,NULL,'2026-07-14 11:17:09','2026-07-14 11:17:53'),
(2,'PO/2607/00002',6,3,'2026-07-14','2026-07-14','draft',1,11.00,9065000.00,0.00,9065000.00,997150.00,10062150.00,0.00,'KSO AR 580 HEMATOLOGGY ANALYSER','2026-07-14 12:11:04','2026-07-14 12:13:32'),
(3,'PO/2607/00003',7,3,'2026-07-14','2026-07-14','received',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,0.00,NULL,'2026-07-14 12:22:38','2026-07-14 12:23:51'),
(4,'PO/2607/00004',9,3,'2026-07-14','2026-07-14','received',0,11.00,18280000.00,0.00,18280000.00,0.00,18280000.00,18280000.00,NULL,'2026-07-14 13:18:56','2026-07-14 13:19:59'),
(5,'PO/2607/00005',10,3,'2026-07-14','2026-07-14','received',1,11.00,14007000.00,0.00,14007000.00,1540770.00,15547770.00,15547770.00,NULL,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(6,'PO/2607/00006',11,3,'2026-07-14','2026-07-14','received',1,11.00,960000.00,0.00,960000.00,105600.00,1065600.00,1065600.00,NULL,'2026-07-14 13:37:23','2026-07-14 13:40:21'),
(7,'PO/2607/00007',4,3,'2026-07-14','2026-07-14','received',1,11.00,1368000.00,0.00,1368000.00,150480.00,1518480.00,1518480.00,NULL,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(8,'PO/2607/00008',7,3,'2026-07-14','2026-07-14','received',1,11.00,5941622.00,0.00,5941622.00,653578.42,6595200.42,6595200.42,NULL,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(9,'PO/2607/00009',12,3,'2026-07-14','2026-07-16','draft',1,11.00,11767050.00,0.00,11767050.00,1294375.50,13061425.50,0.00,NULL,'2026-07-14 14:50:30','2026-07-14 14:50:30'),
(10,'PO/2607/00010',12,3,'2026-07-14','2026-07-14','received',1,11.00,2552650.00,0.00,2552650.00,280791.50,2833441.50,2833441.50,NULL,'2026-07-14 14:58:51','2026-07-14 14:59:27'),
(11,'PO/2607/00011',7,3,'2026-07-14','2026-07-14','received',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,0.00,NULL,'2026-07-14 15:58:13','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_items_quotation_id_foreign` (`quotation_id`),
  KEY `quotation_items_product_id_foreign` (`product_id`),
  CONSTRAINT `quotation_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `quotation_items_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `valid_until` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `terms` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `converted_sales_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotations_quotation_number_unique` (`quotation_number`),
  KEY `quotations_customer_id_foreign` (`customer_id`),
  KEY `quotations_user_id_foreign` (`user_id`),
  KEY `quotations_converted_sales_order_id_foreign` (`converted_sales_order_id`),
  CONSTRAINT `quotations_converted_sales_order_id_foreign` FOREIGN KEY (`converted_sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quotations_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `quotations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,1),
(1,2),
(2,1),
(2,2),
(3,1),
(3,2),
(4,1),
(5,1),
(5,2),
(6,1),
(6,2),
(7,1),
(7,2),
(8,1),
(9,1),
(9,2),
(10,1),
(10,2),
(11,1),
(11,2),
(12,1),
(13,1),
(13,2),
(14,1),
(14,2),
(15,1),
(15,2),
(16,1),
(17,1),
(17,2),
(18,1),
(18,2),
(19,1),
(19,2),
(20,1),
(21,1),
(21,2),
(22,1),
(22,2),
(23,1),
(23,2),
(24,1),
(25,1),
(25,2),
(26,1),
(26,2),
(27,1),
(27,2),
(28,1),
(29,1),
(29,2),
(30,1),
(30,2),
(31,1),
(31,2),
(32,1),
(33,1),
(33,2),
(34,1),
(34,2),
(35,1),
(36,1),
(37,1),
(37,2),
(38,1),
(38,2),
(39,1),
(39,2),
(40,1),
(41,1),
(41,2),
(42,1),
(43,1),
(44,1),
(45,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_items`
--

DROP TABLE IF EXISTS `sales_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount_reason` varchar(255) DEFAULT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_order_items_sales_order_id_foreign` (`sales_order_id`),
  KEY `sales_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sales_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `sales_order_items_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_items`
--

LOCK TABLES `sales_order_items` WRITE;
/*!40000 ALTER TABLE `sales_order_items` DISABLE KEYS */;
INSERT INTO `sales_order_items` VALUES
(1,1,41,2.00,1300000.00,0.00,NULL,2600000.00,'2026-07-14 11:21:06','2026-07-14 11:21:06'),
(2,2,53,1.00,2000000.00,0.00,NULL,2000000.00,'2026-07-14 12:29:01','2026-07-14 12:29:01');
/*!40000 ALTER TABLE `sales_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_orders`
--

DROP TABLE IF EXISTS `sales_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `so_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock_deducted` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_orders_so_number_unique` (`so_number`),
  KEY `sales_orders_customer_id_foreign` (`customer_id`),
  KEY `sales_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `sales_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_orders`
--

LOCK TABLES `sales_orders` WRITE;
/*!40000 ALTER TABLE `sales_orders` DISABLE KEYS */;
INSERT INTO `sales_orders` VALUES
(1,'SO/2607/00001',11,3,'2026-07-14','2026-07-14','completed',0,11.00,2600000.00,0.00,2600000.00,0.00,2600000.00,1,NULL,'2026-07-14 11:21:06','2026-07-14 11:22:05'),
(2,'SO/2607/00002',13,3,'2026-07-14','2026-08-13','completed',0,11.00,2000000.00,0.00,2000000.00,0.00,2000000.00,1,NULL,'2026-07-14 12:29:01','2026-07-14 12:29:30');
/*!40000 ALTER TABLE `sales_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('BrfYskSHJ7zZbTpho2tEbGb8aLDVQCaQlLdS0URK',3,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1','YTo0OntzOjY6Il90b2tlbiI7czo0MDoicHRESFQ4amRHUUphY1NGNEZmeXRKaXFpOTBiVENKaVFFeVhpaWIzZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mzt9',1784033411),
('d6wz12REJWboIgy0oA3WxOgiMbcYACOKZ0KPSRcE',3,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7.5 Mobile/15E148 Safari/604.1','YTo1OntzOjY6Il90b2tlbiI7czo0MDoicnBFSFFuTWxZWkNTRGRteW45TGJ1dXlFb0JEUzA3cmp3NFVkck5oQiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjMzOiJodHRwOi8vZGxtLm1lZHotZWFzeS5jb20vcHJvZHVjdHMiO3M6NToicm91dGUiO3M6MTQ6InByb2R1Y3RzLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mzt9',1784012290),
('PKmZSQgWN4UBTdwF13GX7pI26vbZOXBu2DtuLlfM',3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRlFyckNHa21tTzZXaVd6bGNLOUQzUXhXbllsSVNVSEtOUmg4ZjNEQSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQwOiJodHRwOi8vZGxtLm1lZHotZWFzeS5jb20vcHVyY2hhc2Utb3JkZXJzIjtzOjU6InJvdXRlIjtzOjIxOiJwdXJjaGFzZS1vcmRlcnMuaW5kZXgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1784023619),
('vhTDjqI4u7wH1D6mnKK5xCKm7tMu1UOn3oXMFK5H',1,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoieVdjRFRzSmdtSnp1bUgzcGI0NVJEcGI2VkU4eFZHeFhoSUgzb2plcyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9wdXJjaGFzZS1vcmRlcnMiO3M6NToicm91dGUiO3M6MjE6InB1cmNoYXNlLW9yZGVycy5pbmRleCI7fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=',1784011346);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'company_name','PT DIMAS LOVE MEDIKA','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'company_npwp','1000 0000 0468 5165','2026-07-10 20:33:43','2026-07-13 12:14:50'),
(3,'company_nib','0108250170791','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'company_izin','01082501707910001','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'company_kbli','46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'company_address','Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'company_phone','021-38939414 / 0859-3319-1346','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'company_email','anggihdimas@gmail.com','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'company_pjt','Nia Love Fiana Puteri (D.III Farmasi)','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'ppn_rate','11','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'fp_transaction_code','04','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'fp_prefix','','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'fp_last_serial','11','2026-07-10 20:52:07','2026-07-10 20:52:08'),
(14,'fp_serial_year','26','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(35,'bank_name','Bank BCA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(36,'bank_account_no','8011111629','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(37,'bank_account_holder','PT DIMAS LOVE MEDIKA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(38,'director_name','M Anggih Dimas W','2026-07-13 12:13:43','2026-07-13 12:13:43');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('in','out','adjustment') NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `balance_after` decimal(18,2) NOT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `moved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_warehouse_id_foreign` (`warehouse_id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  KEY `stock_movements_product_id_moved_at_index` (`product_id`,`moved_at`),
  CONSTRAINT `stock_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES
(1,41,1,'in',2.00,4.00,'Penerimaan PO PO/2607/00001',1,'GR GR/2607/00001',3,'2026-07-14 11:17:28','2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,41,1,'out',-2.00,2.00,'Sales Order SO/2607/00001',1,'Penjualan SO SO/2607/00001',3,'2026-07-14 11:21:52','2026-07-14 11:21:52','2026-07-14 11:21:52'),
(3,53,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00003',2,'GR GR/2607/00002',3,'2026-07-14 12:23:51','2026-07-14 12:23:51','2026-07-14 12:23:51'),
(4,53,1,'out',-1.00,0.00,'Sales Order SO/2607/00002',2,'Penjualan SO SO/2607/00002',3,'2026-07-14 12:29:14','2026-07-14 12:29:14','2026-07-14 12:29:14'),
(5,58,1,'in',29.00,29.00,'Penerimaan PO PO/2607/00004',3,'GR GR/2607/00003',3,'2026-07-14 13:19:52','2026-07-14 13:19:52','2026-07-14 13:19:52'),
(6,55,1,'in',6.00,6.00,'Penerimaan PO PO/2607/00004',3,'GR GR/2607/00003',3,'2026-07-14 13:19:52','2026-07-14 13:19:52','2026-07-14 13:19:52'),
(7,57,1,'in',21.00,21.00,'Penerimaan PO PO/2607/00005',4,'GR GR/2607/00004',3,'2026-07-14 13:29:39','2026-07-14 13:29:39','2026-07-14 13:29:39'),
(8,54,1,'in',28.00,28.00,'Penerimaan PO PO/2607/00005',4,'GR GR/2607/00004',3,'2026-07-14 13:29:39','2026-07-14 13:29:39','2026-07-14 13:29:39'),
(9,63,1,'in',12.00,12.00,'Penerimaan PO PO/2607/00006',5,'GR GR/2607/00005',3,'2026-07-14 13:40:20','2026-07-14 13:40:20','2026-07-14 13:40:20'),
(10,64,1,'in',4.00,4.00,'Penerimaan PO PO/2607/00006',5,'GR GR/2607/00005',3,'2026-07-14 13:40:21','2026-07-14 13:40:21','2026-07-14 13:40:21'),
(11,61,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00007',6,'GR GR/2607/00006',3,'2026-07-14 13:45:32','2026-07-14 13:45:32','2026-07-14 13:45:32'),
(12,62,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00007',6,'GR GR/2607/00006',3,'2026-07-14 13:45:32','2026-07-14 13:45:32','2026-07-14 13:45:32'),
(13,59,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00008',7,'GR GR/2607/00007',3,'2026-07-14 13:54:44','2026-07-14 13:54:44','2026-07-14 13:54:44'),
(14,60,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00008',7,'GR GR/2607/00007',3,'2026-07-14 13:54:44','2026-07-14 13:54:44','2026-07-14 13:54:44'),
(15,69,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(16,71,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(17,67,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(18,75,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00011',9,'GR GR/2607/00009',3,'2026-07-14 15:59:02','2026-07-14 15:59:02','2026-07-14 15:59:02');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payments`
--

DROP TABLE IF EXISTS `supplier_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_payments_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `supplier_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `supplier_payments_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payments`
--

LOCK TABLES `supplier_payments` WRITE;
/*!40000 ALTER TABLE `supplier_payments` DISABLE KEYS */;
INSERT INTO `supplier_payments` VALUES
(1,1,3,'2026-07-14',1600000.00,'transfer',NULL,NULL,NULL,'2026-07-14 11:17:53','2026-07-14 11:17:53'),
(2,4,3,'2026-07-14',18280000.00,NULL,NULL,NULL,NULL,'2026-07-14 13:19:59','2026-07-14 13:19:59'),
(3,5,3,'2026-07-14',15547770.00,'transfer',NULL,NULL,NULL,'2026-07-14 13:29:35','2026-07-14 13:29:35'),
(4,6,3,'2026-07-14',1065600.00,NULL,NULL,NULL,NULL,'2026-07-14 13:39:31','2026-07-14 13:39:31'),
(5,7,3,'2026-07-14',1518480.00,'transfer',NULL,NULL,NULL,'2026-07-14 13:44:48','2026-07-14 13:44:48'),
(6,8,3,'2026-07-14',6595200.42,NULL,NULL,NULL,NULL,'2026-07-14 13:54:41','2026-07-14 13:54:41'),
(7,10,3,'2026-07-14',2833441.50,'transfer',NULL,NULL,NULL,'2026-07-14 14:59:27','2026-07-14 14:59:27');
/*!40000 ALTER TABLE `supplier_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES
(1,'SUP-0001','PT Onemed Distribusi','Sales Onemed','021-7770001',NULL,NULL,'03.111.222.3-093.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'SUP-0002','PT Enseval Medika Prima','Sales Enseval','021-7770002',NULL,NULL,'04.222.333.4-093.000',45,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'SUP-0003','CV Sumber Medis Jaya','Bpk. Hendra','0813-3333-4444',NULL,NULL,'',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'SUP-0004','Sarana Maju Sejahtera',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 14:48:51','2026-07-13 14:48:51'),
(5,'SUP-0005','pak egi',NULL,'08131081203',NULL,'cisauk',NULL,0,1,'2026-07-14 11:16:05','2026-07-14 11:16:05'),
(6,'SUP-0006','PT ARDHIKA UMRAN ABADI',NULL,NULL,NULL,'Jl. Bintara VII No.100A RT.06 RW.03 Bintara, Bekasi - Jawa Barat',NULL,0,1,'2026-07-14 11:40:03','2026-07-14 11:40:03'),
(7,'SUP-0007','PT Demaz Noer Abadi','Adetya Nur Azis','085814390858',NULL,'Perkampungan Kecil Blok G62 Kel. Penggilingan Kec Cakung Jakarta Timur DKI Jakarta',NULL,0,1,'2026-07-14 12:20:34','2026-07-14 12:20:34'),
(8,'SUP-0008','Rumah Sakit Ibu dan Anak Dhia',NULL,'081282103297',NULL,'Jl. Cendrawasih Raya No.90, Sawah Lama, Kec. Ciputat, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-14 12:27:08','2026-07-14 12:27:08'),
(9,'SUP-0009','CV. SAMZIO NUSA MEDIKA',NULL,'0816 1794 2649',NULL,'Jl. Panglima Polim Perumahan Cluster Plawad Indah Blok C No.3 Tangerang 15141',NULL,0,1,'2026-07-14 13:17:00','2026-07-14 13:17:00'),
(10,'SUP-0010','PT LIFOTRONIC TECHNOLOGY INDONESIA',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-14 13:26:02','2026-07-14 13:26:02'),
(11,'SUP-0011','PT. ERA MEDIKA AKESINDO','BUDI RAHMAT',NULL,NULL,'JL. SISINGAMANGARAJA KM10.8 KOMPLEK AMPLAS TRADE CENTER BLOK MAHONI NO 08 KOTA MEDAN, SUMATERA UTARA','91.542.645.6-125.000',0,1,'2026-07-14 13:34:39','2026-07-14 13:34:39'),
(12,'SUP-0012','PT Andalas Prima Sentosa','Zalfiyah','089611918823',NULL,'Jl. Pemuda No.29 8, RT.8/RW.4, Rawamangun, Kec. Pulo Gadung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta',NULL,0,1,'2026-07-14 14:34:54','2026-07-14 14:34:54');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_invoices`
--

DROP TABLE IF EXISTS `tax_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('output','input') NOT NULL,
  `tax_number` varchar(255) NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `purchase_order_id` bigint(20) unsigned DEFAULT NULL,
  `partner_name` varchar(255) NOT NULL,
  `partner_npwp` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_invoices_tax_number_unique` (`tax_number`),
  KEY `tax_invoices_invoice_id_foreign` (`invoice_id`),
  KEY `tax_invoices_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `tax_invoices_user_id_foreign` (`user_id`),
  KEY `tax_invoices_type_date_index` (`type`,`date`),
  CONSTRAINT `tax_invoices_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_invoices`
--

LOCK TABLES `tax_invoices` WRITE;
/*!40000 ALTER TABLE `tax_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES
(1,'Pieces','pcs','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Box','box','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Unit','unit','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Set','set','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Pack','pack','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'Lusin','lsn','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'Vial','Vial','2026-07-13 12:28:55','2026-07-13 12:29:17'),
(8,'Botol','btl','2026-07-13 13:23:41','2026-07-13 13:23:41');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Administrator','admin@dimaslovemedika.com','2026-07-10 20:33:43','$2y$12$oCqRgpSNOFj/tgjHtDDqUecJBBYnOZPuYY5c9E7GNTf6Q5lw5bFlK',1,NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff Operasional','staff@dimaslovemedika.com','2026-07-10 20:33:44','$2y$12$Yg6Wf6sq6ZjqE1tPxacIbOTcrwDFuFVjaNcCpJe1e1G6hfUORuW4.',1,NULL,'2026-07-10 20:33:44','2026-07-10 20:33:44'),
(3,'rafly','admin@rafly.com',NULL,'$2y$12$ve0fYV0BDzI/j2M3iY43guTLzgK.dxAAj5OUONIl8qVzkIUj3p7BG',1,NULL,'2026-07-13 12:19:51','2026-07-13 15:11:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES
(1,'Gudang Utama','Jl. Kodiklat TNI Buaran Hankam No. 59, Serpong, Tangerang Selatan',1,1,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dlm_medika'
--

--
-- Dumping routines for database 'dlm_medika'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-15  2:00:01
