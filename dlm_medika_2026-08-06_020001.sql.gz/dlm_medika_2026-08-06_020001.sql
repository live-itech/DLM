/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: dlm_medika
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `causer_type` varchar(255) DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `attribute_changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attribute_changes`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=319 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
(1,'satuan','created','App\\Models\\Unit',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pieces\",\"symbol\":\"pcs\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'satuan','created','App\\Models\\Unit',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Box\",\"symbol\":\"box\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'satuan','created','App\\Models\\Unit',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Unit\",\"symbol\":\"unit\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'satuan','created','App\\Models\\Unit',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Set\",\"symbol\":\"set\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'satuan','created','App\\Models\\Unit',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pack\",\"symbol\":\"pack\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'satuan','created','App\\Models\\Unit',6,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Lusin\",\"symbol\":\"lsn\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'kategori','created','App\\Models\\Category',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'kategori','created','App\\Models\\Category',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Non Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'kategori','created','App\\Models\\Category',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Diagnostik In Vitro\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'kategori','created','App\\Models\\Category',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alat Laboratorium\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'kategori','created','App\\Models\\Category',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Consumable Medis\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'produk','created','App\\Models\\Product',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0001\",\"name\":\"Masker Bedah 3 Ply (Box 50)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"22000.00\",\"sell_price\":\"35000.00\",\"min_stock\":\"50.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'produk','created','App\\Models\\Product',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0002\",\"name\":\"Sarung Tangan Latex Steril (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"65000.00\",\"sell_price\":\"95000.00\",\"min_stock\":\"30.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'produk','created','App\\Models\\Product',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0003\",\"name\":\"Spuit \\/ Syringe 3ml (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"48000.00\",\"sell_price\":\"72000.00\",\"min_stock\":\"25.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'produk','created','App\\Models\\Product',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0004\",\"name\":\"Infus Set Dewasa\",\"category_id\":1,\"unit_id\":1,\"cost_price\":\"4500.00\",\"sell_price\":\"8000.00\",\"min_stock\":\"100.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'produk','created','App\\Models\\Product',5,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0005\",\"name\":\"Kasa Steril 16x16 (Pack)\",\"category_id\":1,\"unit_id\":5,\"cost_price\":\"3500.00\",\"sell_price\":\"6500.00\",\"min_stock\":\"80.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'produk','created','App\\Models\\Product',6,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0006\",\"name\":\"Rapid Test Antigen (Box 25)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"210000.00\",\"sell_price\":\"320000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'produk','created','App\\Models\\Product',7,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0007\",\"name\":\"Tabung Vacutainer EDTA (Box 100)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"85000.00\",\"sell_price\":\"130000.00\",\"min_stock\":\"15.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'produk','created','App\\Models\\Product',8,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0008\",\"name\":\"Alkohol Swab (Box 100)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"9000.00\",\"sell_price\":\"16000.00\",\"min_stock\":\"40.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'produk','created','App\\Models\\Product',9,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0009\",\"name\":\"Termometer Digital\",\"category_id\":4,\"unit_id\":3,\"cost_price\":\"28000.00\",\"sell_price\":\"55000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'produk','created','App\\Models\\Product',10,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0010\",\"name\":\"Pinset Anatomis Stainless\",\"category_id\":2,\"unit_id\":1,\"cost_price\":\"15000.00\",\"sell_price\":\"30000.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'pelanggan','created','App\\Models\\Customer',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0001\",\"name\":\"RS Medika Sentosa\",\"phone\":\"021-5551001\",\"npwp\":\"01.234.567.8-091.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'pelanggan','created','App\\Models\\Customer',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0002\",\"name\":\"Klinik Sehat Bersama\",\"phone\":\"021-5552002\",\"npwp\":\"02.345.678.9-091.000\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'pelanggan','created','App\\Models\\Customer',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0003\",\"name\":\"Apotek Kimia Farmasi\",\"phone\":\"0812-1111-2222\",\"npwp\":\"\",\"payment_term_days\":7,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'pelanggan','created','App\\Models\\Customer',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0004\",\"name\":\"Puskesmas Serpong\",\"phone\":\"021-5553003\",\"npwp\":\"\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'supplier','created','App\\Models\\Supplier',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0001\",\"name\":\"PT Onemed Distribusi\",\"phone\":\"021-7770001\",\"npwp\":\"03.111.222.3-093.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'supplier','created','App\\Models\\Supplier',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0002\",\"name\":\"PT Enseval Medika Prima\",\"phone\":\"021-7770002\",\"npwp\":\"04.222.333.4-093.000\",\"payment_term_days\":45,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'supplier','created','App\\Models\\Supplier',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0003\",\"name\":\"CV Sumber Medis Jaya\",\"phone\":\"0813-3333-4444\",\"npwp\":\"\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'pelanggan','created','App\\Models\\Customer',5,'created','App\\Models\\User',1,'{\"attributes\":{\"code\":\"CUST-0005\",\"name\":\"joko\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 00:01:34','2026-07-13 00:01:34'),
(30,'satuan','created','App\\Models\\Unit',7,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:28:55','2026-07-13 12:28:55'),
(31,'satuan','updated','App\\Models\\Unit',7,'updated','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Vial\",\"symbol\":\"Vial\"},\"old\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:29:17','2026-07-13 12:29:17'),
(32,'produk','created','App\\Models\\Product',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:07','2026-07-13 12:41:07'),
(33,'produk','created','App\\Models\\Product',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:50','2026-07-13 12:41:50'),
(34,'produk','created','App\\Models\\Product',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:42:38','2026-07-13 12:42:38'),
(35,'produk','created','App\\Models\\Product',14,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:43:21','2026-07-13 12:43:21'),
(36,'produk','created','App\\Models\\Product',15,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:44:26','2026-07-13 12:44:26'),
(37,'produk','created','App\\Models\\Product',16,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:45:59','2026-07-13 12:45:59'),
(38,'produk','created','App\\Models\\Product',17,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:46:53','2026-07-13 12:46:53'),
(39,'produk','created','App\\Models\\Product',18,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:48:42','2026-07-13 12:48:42'),
(40,'produk','created','App\\Models\\Product',19,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:49:31','2026-07-13 12:49:31'),
(41,'pelanggan','created','App\\Models\\Customer',6,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0006\",\"name\":\"PT Amanah Husada Pamulang\",\"phone\":null,\"npwp\":\"66.376.297.9-411.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 12:57:55','2026-07-13 12:57:55'),
(42,'pelanggan','created','App\\Models\\Customer',7,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0007\",\"name\":\"PT Allaya Mandiri Sejahtera\",\"phone\":null,\"npwp\":\"902616440452000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 13:10:48','2026-07-13 13:10:48'),
(43,'produk','deleted','App\\Models\\Product',17,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:02','2026-07-13 13:13:02'),
(44,'produk','deleted','App\\Models\\Product',15,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:09','2026-07-13 13:13:09'),
(45,'produk','deleted','App\\Models\\Product',16,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:13','2026-07-13 13:13:13'),
(46,'produk','created','App\\Models\\Product',20,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0020\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"245000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:15:32','2026-07-13 13:15:32'),
(47,'produk','created','App\\Models\\Product',21,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0021\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:01','2026-07-13 13:16:01'),
(48,'produk','created','App\\Models\\Product',22,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0022\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:39','2026-07-13 13:16:39'),
(49,'produk','deleted','App\\Models\\Product',18,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:15','2026-07-13 13:18:15'),
(50,'produk','created','App\\Models\\Product',23,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0023\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:18:47','2026-07-13 13:18:47'),
(51,'produk','deleted','App\\Models\\Product',19,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:58','2026-07-13 13:18:58'),
(52,'produk','created','App\\Models\\Product',24,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0024\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:19:25','2026-07-13 13:19:25'),
(53,'produk','deleted','App\\Models\\Product',12,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:19:36','2026-07-13 13:19:36'),
(54,'produk','created','App\\Models\\Product',25,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:20','2026-07-13 13:20:20'),
(55,'produk','deleted','App\\Models\\Product',25,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:41','2026-07-13 13:20:41'),
(56,'produk','created','App\\Models\\Product',26,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:21:11','2026-07-13 13:21:11'),
(57,'produk','deleted','App\\Models\\Product',11,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:21:16','2026-07-13 13:21:16'),
(58,'produk','created','App\\Models\\Product',27,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0027\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:22:25','2026-07-13 13:22:25'),
(59,'produk','updated','App\\Models\\Product',26,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"299999.99\"},\"old\":{\"cost_price\":\"350000.00\"}}','[]','2026-07-13 13:22:39','2026-07-13 13:22:39'),
(60,'produk','deleted','App\\Models\\Product',13,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:23:01','2026-07-13 13:23:01'),
(61,'satuan','created','App\\Models\\Unit',8,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Botol\",\"symbol\":\"btl\"}}','[]','2026-07-13 13:23:41','2026-07-13 13:23:41'),
(62,'produk','created','App\\Models\\Product',28,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0028\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:24:50','2026-07-13 13:24:50'),
(63,'produk','deleted','App\\Models\\Product',14,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:24:57','2026-07-13 13:24:57'),
(64,'produk','created','App\\Models\\Product',29,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:32','2026-07-13 13:25:32'),
(65,'produk','deleted','App\\Models\\Product',29,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:54','2026-07-13 13:25:54'),
(66,'produk','created','App\\Models\\Product',30,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:26:28','2026-07-13 13:26:28'),
(67,'pelanggan','created','App\\Models\\Customer',8,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0008\",\"name\":\"RSIA Vitalaya\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:09:33','2026-07-13 14:09:33'),
(68,'pelanggan','created','App\\Models\\Customer',9,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0009\",\"name\":\"RS Citra Insani\",\"phone\":null,\"npwp\":\"O23803026403000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:10:42','2026-07-13 14:10:42'),
(69,'pelanggan','updated','App\\Models\\Customer',9,'updated','App\\Models\\User',3,'{\"attributes\":{\"payment_term_days\":30},\"old\":{\"payment_term_days\":0}}','[]','2026-07-13 14:11:06','2026-07-13 14:11:06'),
(70,'pelanggan','created','App\\Models\\Customer',10,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0010\",\"name\":\"RS BHAYANGKARA\",\"phone\":null,\"npwp\":\"1237767013000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 14:12:57','2026-07-13 14:12:57'),
(71,'pelanggan','created','App\\Models\\Customer',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0011\",\"name\":\"PT Nauli Sejahtera Medika\",\"phone\":null,\"npwp\":\"86.947.018.7-452.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:16:43','2026-07-13 14:16:43'),
(72,'supplier','created','App\\Models\\Supplier',4,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0004\",\"name\":\"Sarana Maju Sejahtera\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:48:51','2026-07-13 14:48:51'),
(73,'pelanggan','created','App\\Models\\Customer',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0012\",\"name\":\"Permata Alkes\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 15:59:32','2026-07-13 15:59:32'),
(74,'produk','updated','App\\Models\\Product',26,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"300000.00\",\"sell_price\":\"375000.00\"},\"old\":{\"cost_price\":\"299999.99\",\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:01:41','2026-07-13 16:01:41'),
(75,'produk','updated','App\\Models\\Product',27,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"600000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:01','2026-07-13 16:02:01'),
(76,'produk','updated','App\\Models\\Product',28,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"400000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:16','2026-07-13 16:02:16'),
(77,'produk','updated','App\\Models\\Product',30,'updated','App\\Models\\User',3,'{\"attributes\":{\"sell_price\":\"700000.00\"},\"old\":{\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:02:37','2026-07-13 16:02:37'),
(78,'produk','created','App\\Models\\Product',31,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0031\",\"name\":\"Probe Cleanser Lifotronik\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 16:03:40','2026-07-13 16:03:40'),
(79,'produk','created','App\\Models\\Product',32,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0032\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"120000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 16:04:43','2026-07-13 16:04:43'),
(80,'produk','updated','App\\Models\\Product',31,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"50000.00\",\"sell_price\":\"150000.00\"},\"old\":{\"cost_price\":\"0.00\",\"sell_price\":\"0.00\"}}','[]','2026-07-13 16:05:27','2026-07-13 16:05:27'),
(81,'produk','deleted','App\\Models\\Product',7,'deleted','App\\Models\\User',1,'{\"old\":{\"code\":\"PRD-0007\",\"name\":\"Tabung Vacutainer EDTA (Box 100)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"85000.00\",\"sell_price\":\"130000.00\",\"min_stock\":\"15.00\",\"is_active\":true}}','[]','2026-07-13 22:05:02','2026-07-13 22:05:02'),
(82,'produk','updated','App\\Models\\Product',31,'updated','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Probe Cleanser Lifotronic (50 ML)\"},\"old\":{\"name\":\"Probe Cleanser Lifotronik\"}}','[]','2026-07-14 10:33:01','2026-07-14 10:33:01'),
(83,'produk','deleted','App\\Models\\Product',27,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0027\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:38:54','2026-07-14 10:38:54'),
(84,'produk','created','App\\Models\\Product',33,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0033\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:40:11','2026-07-14 10:40:11'),
(85,'produk','deleted','App\\Models\\Product',26,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:40:39','2026-07-14 10:40:39'),
(86,'produk','created','App\\Models\\Product',34,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0034\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"267000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:42:10','2026-07-14 10:42:10'),
(87,'produk','deleted','App\\Models\\Product',28,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0028\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"330000.00\",\"sell_price\":\"400000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:42:22','2026-07-14 10:42:22'),
(88,'produk','created','App\\Models\\Product',35,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0035\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:43:15','2026-07-14 10:43:15'),
(89,'produk','deleted','App\\Models\\Product',32,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0032\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"120000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:44:21','2026-07-14 10:44:21'),
(90,'produk','created','App\\Models\\Product',36,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0036\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:45:37','2026-07-14 10:45:37'),
(91,'produk','deleted','App\\Models\\Product',24,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0024\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:46:21','2026-07-14 10:46:21'),
(92,'produk','created','App\\Models\\Product',37,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0037\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:00','2026-07-14 10:47:00'),
(93,'produk','deleted','App\\Models\\Product',23,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0023\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:13','2026-07-14 10:47:13'),
(94,'produk','created','App\\Models\\Product',38,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0038\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:47:44','2026-07-14 10:47:44'),
(95,'produk','created','App\\Models\\Product',39,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0039\",\"name\":\"Diluent Labnova\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:48:55','2026-07-14 10:48:55'),
(96,'produk','created','App\\Models\\Product',40,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0040\",\"name\":\"Lyse Labnova\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:49:47','2026-07-14 10:49:47'),
(97,'produk','created','App\\Models\\Product',41,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0041\",\"name\":\"Lyse M-52DIFF Mindray\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:50:32','2026-07-14 10:50:32'),
(98,'produk','created','App\\Models\\Product',42,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0042\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:53:49','2026-07-14 10:53:49'),
(99,'produk','created','App\\Models\\Product',43,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:08','2026-07-14 10:54:08'),
(100,'produk','deleted','App\\Models\\Product',43,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:17','2026-07-14 10:54:17'),
(101,'produk','created','App\\Models\\Product',44,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:27','2026-07-14 10:54:27'),
(102,'produk','created','App\\Models\\Product',45,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0045\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:29','2026-07-14 10:54:29'),
(103,'produk','deleted','App\\Models\\Product',44,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:37','2026-07-14 10:54:37'),
(104,'produk','deleted','App\\Models\\Product',45,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0045\",\"name\":\"HS-CRP\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:54:53','2026-07-14 10:54:53'),
(105,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3},\"old\":{\"category_id\":null}}','[]','2026-07-14 10:55:05','2026-07-14 10:55:05'),
(106,'produk','created','App\\Models\\Product',46,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:55:38','2026-07-14 10:55:38'),
(107,'produk','created','App\\Models\\Product',47,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0047\",\"name\":\"VITAMIN D (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 10:56:16','2026-07-14 10:56:16'),
(108,'produk','deleted','App\\Models\\Product',1,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0001\",\"name\":\"Masker Bedah 3 Ply (Box 50)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"22000.00\",\"sell_price\":\"35000.00\",\"min_stock\":\"50.00\",\"is_active\":true}}','[]','2026-07-14 10:56:55','2026-07-14 10:56:55'),
(109,'produk','deleted','App\\Models\\Product',5,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0005\",\"name\":\"Kasa Steril 16x16 (Pack)\",\"category_id\":1,\"unit_id\":5,\"cost_price\":\"3500.00\",\"sell_price\":\"6500.00\",\"min_stock\":\"80.00\",\"is_active\":true}}','[]','2026-07-14 10:57:02','2026-07-14 10:57:02'),
(110,'produk','deleted','App\\Models\\Product',8,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0008\",\"name\":\"Alkohol Swab (Box 100)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"9000.00\",\"sell_price\":\"16000.00\",\"min_stock\":\"40.00\",\"is_active\":true}}','[]','2026-07-14 10:57:09','2026-07-14 10:57:09'),
(111,'produk','deleted','App\\Models\\Product',4,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0004\",\"name\":\"Infus Set Dewasa\",\"category_id\":1,\"unit_id\":1,\"cost_price\":\"4500.00\",\"sell_price\":\"8000.00\",\"min_stock\":\"100.00\",\"is_active\":true}}','[]','2026-07-14 10:57:21','2026-07-14 10:57:21'),
(112,'produk','deleted','App\\Models\\Product',10,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0010\",\"name\":\"Pinset Anatomis Stainless\",\"category_id\":2,\"unit_id\":1,\"cost_price\":\"15000.00\",\"sell_price\":\"30000.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-14 10:57:32','2026-07-14 10:57:32'),
(113,'produk','deleted','App\\Models\\Product',2,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0002\",\"name\":\"Sarung Tangan Latex Steril (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"65000.00\",\"sell_price\":\"95000.00\",\"min_stock\":\"30.00\",\"is_active\":true}}','[]','2026-07-14 10:57:40','2026-07-14 10:57:40'),
(114,'produk','deleted','App\\Models\\Product',3,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0003\",\"name\":\"Spuit \\/ Syringe 3ml (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"48000.00\",\"sell_price\":\"72000.00\",\"min_stock\":\"25.00\",\"is_active\":true}}','[]','2026-07-14 10:57:48','2026-07-14 10:57:48'),
(115,'produk','updated','App\\Models\\Product',42,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"1026000.00\"},\"old\":{\"cost_price\":\"0.00\"}}','[]','2026-07-14 11:12:54','2026-07-14 11:12:54'),
(116,'supplier','created','App\\Models\\Supplier',5,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0005\",\"name\":\"pak egi\",\"phone\":\"08131081203\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 11:16:05','2026-07-14 11:16:05'),
(117,'produk','deleted','App\\Models\\Product',9,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0009\",\"name\":\"Termometer Digital\",\"category_id\":4,\"unit_id\":3,\"cost_price\":\"28000.00\",\"sell_price\":\"55000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-14 11:25:23','2026-07-14 11:25:23'),
(118,'produk','deleted','App\\Models\\Product',6,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0006\",\"name\":\"Rapid Test Antigen (Box 25)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"210000.00\",\"sell_price\":\"320000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-14 11:25:30','2026-07-14 11:25:30'),
(119,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"is_active\":false},\"old\":{\"is_active\":true}}','[]','2026-07-14 11:29:03','2026-07-14 11:29:03'),
(120,'produk','updated','App\\Models\\Product',41,'updated','App\\Models\\User',3,'{\"attributes\":{\"is_active\":true},\"old\":{\"is_active\":false}}','[]','2026-07-14 11:29:16','2026-07-14 11:29:16'),
(121,'produk','deleted','App\\Models\\Product',47,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0047\",\"name\":\"VITAMIN D (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:30:13','2026-07-14 11:30:13'),
(122,'produk','updated','App\\Models\\Product',37,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"60000.00\"},\"old\":{\"cost_price\":\"0.00\"}}','[]','2026-07-14 11:30:35','2026-07-14 11:30:35'),
(123,'supplier','created','App\\Models\\Supplier',6,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0006\",\"name\":\"PT ARDHIKA UMRAN ABADI\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 11:40:03','2026-07-14 11:40:03'),
(124,'produk','created','App\\Models\\Product',48,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0047\",\"name\":\"Arumamed Dliuent 5-Diff\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"1709400.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:44:14','2026-07-14 11:44:14'),
(125,'produk','updated','App\\Models\\Product',48,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"2200000.00\"},\"old\":{\"cost_price\":\"1709400.00\"}}','[]','2026-07-14 11:52:22','2026-07-14 11:52:22'),
(126,'produk','created','App\\Models\\Product',49,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0049\",\"name\":\"Arumamed LD Lyse 5-Diff\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"5000000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:55:24','2026-07-14 11:55:24'),
(127,'produk','created','App\\Models\\Product',50,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0050\",\"name\":\"Arumamed LH Lyse 5-Diff\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"2600000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:56:27','2026-07-14 11:56:27'),
(128,'produk','created','App\\Models\\Product',51,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0051\",\"name\":\"Arumamed Probe Cleaser\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"750000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:58:02','2026-07-14 11:58:02'),
(129,'produk','created','App\\Models\\Product',52,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0052\",\"name\":\"Arumamed Hematology  Control Normal 5-Diff\",\"category_id\":3,\"unit_id\":7,\"cost_price\":\"2400000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 11:59:09','2026-07-14 11:59:09'),
(130,'supplier','created','App\\Models\\Supplier',7,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0007\",\"name\":\"PT Demaz Noer Abadi\",\"phone\":\"085814390858\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:20:34','2026-07-14 12:20:34'),
(131,'produk','created','App\\Models\\Product',53,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0053\",\"name\":\"Vitamin D SD Biosensor\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 12:21:38','2026-07-14 12:21:38'),
(132,'supplier','created','App\\Models\\Supplier',8,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0008\",\"name\":\"Rumah Sakit Ibu dan Anak Dhia\",\"phone\":\"081282103297\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:27:08','2026-07-14 12:27:08'),
(133,'pelanggan','created','App\\Models\\Customer',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0013\",\"name\":\"Rumah Sakit Ibu dan Anak Dhia\",\"phone\":\"081282103297\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 12:28:09','2026-07-14 12:28:09'),
(134,'produk','deleted','App\\Models\\Product',22,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0022\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:42','2026-07-14 13:02:42'),
(135,'produk','deleted','App\\Models\\Product',20,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0020\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"245000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:46','2026-07-14 13:02:46'),
(136,'produk','deleted','App\\Models\\Product',21,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0021\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:02:50','2026-07-14 13:02:50'),
(137,'produk','deleted','App\\Models\\Product',30,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"700000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:03:46','2026-07-14 13:03:46'),
(138,'produk','deleted','App\\Models\\Product',39,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0039\",\"name\":\"Diluent Labnova\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:08','2026-07-14 13:04:08'),
(139,'produk','deleted','App\\Models\\Product',40,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0040\",\"name\":\"Lyse Labnova\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:21','2026-07-14 13:04:21'),
(140,'produk','deleted','App\\Models\\Product',33,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0033\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"600000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:29','2026-07-14 13:04:29'),
(141,'produk','deleted','App\\Models\\Product',34,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0034\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"267000.00\",\"sell_price\":\"375000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:46','2026-07-14 13:04:46'),
(142,'produk','deleted','App\\Models\\Product',37,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0037\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:53','2026-07-14 13:04:53'),
(143,'produk','deleted','App\\Models\\Product',38,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0038\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:04:59','2026-07-14 13:04:59'),
(144,'produk','deleted','App\\Models\\Product',42,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0042\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"1026000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:11','2026-07-14 13:05:11'),
(145,'produk','deleted','App\\Models\\Product',36,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0036\",\"name\":\"Probe Cleanser Mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:18','2026-07-14 13:05:18'),
(146,'produk','deleted','App\\Models\\Product',31,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0031\",\"name\":\"Probe Cleanser Lifotronic (50 ML)\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"50000.00\",\"sell_price\":\"150000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:05:31','2026-07-14 13:05:31'),
(147,'produk','deleted','App\\Models\\Product',35,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0035\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:06:03','2026-07-14 13:06:03'),
(148,'produk','deleted','App\\Models\\Product',46,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0043\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:06:10','2026-07-14 13:06:10'),
(149,'produk','created','App\\Models\\Product',54,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0054\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:07:27','2026-07-14 13:07:27'),
(150,'produk','created','App\\Models\\Product',55,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0055\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:07:50','2026-07-14 13:07:50'),
(151,'produk','created','App\\Models\\Product',56,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0056\",\"name\":\"Lyse Mindray M30\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:09','2026-07-14 13:08:09'),
(152,'produk','created','App\\Models\\Product',57,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0057\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:23','2026-07-14 13:08:23'),
(153,'produk','created','App\\Models\\Product',58,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0058\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:33','2026-07-14 13:08:33'),
(154,'produk','created','App\\Models\\Product',59,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0059\",\"name\":\"TSH-II FIA (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:08:48','2026-07-14 13:08:48'),
(155,'produk','created','App\\Models\\Product',60,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0060\",\"name\":\"HS-CRP (SD)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:09:35','2026-07-14 13:09:35'),
(156,'produk','created','App\\Models\\Product',61,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0061\",\"name\":\"Diluent Labnovation\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:10:10','2026-07-14 13:10:10'),
(157,'produk','created','App\\Models\\Product',62,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0062\",\"name\":\"Lyse Labnovation\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:10:34','2026-07-14 13:10:34'),
(158,'produk','updated','App\\Models\\Product',56,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3,\"unit_id\":8},\"old\":{\"category_id\":null,\"unit_id\":null}}','[]','2026-07-14 13:11:06','2026-07-14 13:11:06'),
(159,'produk','updated','App\\Models\\Product',62,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3,\"unit_id\":8},\"old\":{\"category_id\":null,\"unit_id\":null}}','[]','2026-07-14 13:11:15','2026-07-14 13:11:15'),
(160,'produk','created','App\\Models\\Product',63,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0063\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:12:00','2026-07-14 13:12:00'),
(161,'produk','created','App\\Models\\Product',64,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0064\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 13:12:11','2026-07-14 13:12:11'),
(162,'supplier','created','App\\Models\\Supplier',9,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0009\",\"name\":\"CV. SAMZIO NUSA MEDIKA\",\"phone\":\"0816 1794 2649\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:17:00','2026-07-14 13:17:00'),
(163,'supplier','created','App\\Models\\Supplier',10,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0010\",\"name\":\"PT LIFOTRONIC TECHNOLOGY INDONESIA\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:26:02','2026-07-14 13:26:02'),
(164,'supplier','created','App\\Models\\Supplier',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0011\",\"name\":\"PT. ERA MEDIKA AKESINDO\",\"phone\":null,\"npwp\":\"91.542.645.6-125.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 13:34:39','2026-07-14 13:34:39'),
(165,'supplier','created','App\\Models\\Supplier',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0012\",\"name\":\"PT Andalas Prima Sentosa\",\"phone\":\"089611918823\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-14 14:34:54','2026-07-14 14:34:54'),
(166,'produk','created','App\\Models\\Product',65,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0065\",\"name\":\"Cuvette Segment\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:36:14','2026-07-14 14:36:14'),
(167,'produk','created','App\\Models\\Product',66,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0066\",\"name\":\"Thermal Paper Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:36:51','2026-07-14 14:36:51'),
(168,'produk','created','App\\Models\\Product',67,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0067\",\"name\":\"Gluc Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:37:24','2026-07-14 14:37:24'),
(169,'produk','created','App\\Models\\Product',68,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0068\",\"name\":\"Cleaner Cobas C111\",\"category_id\":null,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:38:02','2026-07-14 14:38:02'),
(170,'produk','created','App\\Models\\Product',69,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0069\",\"name\":\"Cleaner Basic Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:38:45','2026-07-14 14:38:45'),
(171,'produk','created','App\\Models\\Product',70,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0070\",\"name\":\"Creap Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:39:09','2026-07-14 14:39:09'),
(172,'produk','created','App\\Models\\Product',71,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0071\",\"name\":\"HDL C4 Cobas C111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:39:34','2026-07-14 14:39:34'),
(173,'produk','created','App\\Models\\Product',72,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0072\",\"name\":\"Triglyceride\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:07','2026-07-14 14:40:07'),
(174,'produk','created','App\\Models\\Product',73,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0073\",\"name\":\"Ureal Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:23','2026-07-14 14:40:23'),
(175,'produk','created','App\\Models\\Product',74,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0074\",\"name\":\"Cholestrol Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 14:40:50','2026-07-14 14:40:50'),
(176,'produk','created','App\\Models\\Product',75,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0075\",\"name\":\"HBA1C SD Biosensor\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-14 15:55:34','2026-07-14 15:55:34'),
(177,'produk','created','App\\Models\\Product',76,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0076\",\"name\":\"Standart F TB-Feron FIA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-15 15:01:06','2026-07-15 15:01:06'),
(178,'produk','created','App\\Models\\Product',77,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0077\",\"name\":\"Stadart E TB Feron Tubes\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-15 15:01:43','2026-07-15 15:01:43'),
(179,'supplier','created','App\\Models\\Supplier',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0013\",\"name\":\"Nur Khanif\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-15 15:24:39','2026-07-15 15:24:39'),
(180,'pelanggan','created','App\\Models\\Customer',14,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0014\",\"name\":\"Sarana Megamedilab Sejahtera\",\"phone\":null,\"npwp\":\"0665006243404000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-15 15:26:41','2026-07-15 15:26:41'),
(181,'produk','created','App\\Models\\Product',78,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0078\",\"name\":\"Board Spare Part Cobas C111\",\"category_id\":null,\"unit_id\":3,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-15 15:27:21','2026-07-15 15:27:21'),
(182,'produk','created','App\\Models\\Product',79,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0079\",\"name\":\"HIV Allcheck\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-15 16:06:15','2026-07-15 16:06:15'),
(183,'supplier','created','App\\Models\\Supplier',14,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0014\",\"name\":\"PT. Khabib Kreasi Mandiri\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-15 16:08:08','2026-07-15 16:08:08'),
(184,'pelanggan','created','App\\Models\\Customer',15,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0015\",\"name\":\"Ibu ayu\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 09:25:23','2026-07-16 09:25:23'),
(185,'pelanggan','created','App\\Models\\Customer',16,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0016\",\"name\":\"Amiau klinik maria dr rossy\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 10:21:31','2026-07-16 10:21:31'),
(186,'pelanggan','created','App\\Models\\Customer',17,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0017\",\"name\":\"Pak Azeh hamzah\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 11:54:14','2026-07-16 11:54:14'),
(187,'pelanggan','created','App\\Models\\Customer',18,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0018\",\"name\":\"Yulian Dini\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 12:40:05','2026-07-16 12:40:05'),
(188,'supplier','created','App\\Models\\Supplier',15,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0015\",\"name\":\"Asep Kurnia\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 15:10:57','2026-07-16 15:10:57'),
(189,'pelanggan','created','App\\Models\\Customer',19,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0019\",\"name\":\"PT Mutiara Mitra Kasih\",\"phone\":null,\"npwp\":\"99.333.974.6-445.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-16 16:17:17','2026-07-16 16:17:17'),
(190,'pelanggan','created','App\\Models\\Customer',20,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0020\",\"name\":\"Rahadian faisal\",\"phone\":\"081324261341\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-17 12:43:07','2026-07-17 12:43:07'),
(191,'supplier','created','App\\Models\\Supplier',16,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0016\",\"name\":\"PT Elba Lab Medika\",\"phone\":null,\"npwp\":\"76.532.551.9-008.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-17 12:47:52','2026-07-17 12:47:52'),
(192,'pelanggan','created','App\\Models\\Customer',21,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0021\",\"name\":\"Pak Latief\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-18 11:06:41','2026-07-18 11:06:41'),
(193,'pelanggan','created','App\\Models\\Customer',22,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0022\",\"name\":\"Klinik devina medika\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-18 12:13:15','2026-07-18 12:13:15'),
(194,'pelanggan','created','App\\Models\\Customer',23,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0023\",\"name\":\"Akp dr haykel mansyur,mars\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-18 13:42:22','2026-07-18 13:42:22'),
(195,'pelanggan','created','App\\Models\\Customer',24,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0024\",\"name\":\"PT Abi Tama Medika\",\"phone\":null,\"npwp\":\"0537794463401000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-18 17:07:57','2026-07-18 17:07:57'),
(196,'pelanggan','created','App\\Models\\Customer',25,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0025\",\"name\":\"Rumah sakit permata hati\",\"phone\":\"088594654492\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-19 10:14:17','2026-07-19 10:14:17'),
(197,'supplier','created','App\\Models\\Supplier',17,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0017\",\"name\":\"PT sarana maju sejahtera\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-20 11:29:31','2026-07-20 11:29:31'),
(198,'produk','created','App\\Models\\Product',80,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0080\",\"name\":\"Control 3D normal sysmex\",\"category_id\":3,\"unit_id\":7,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-20 11:35:08','2026-07-20 11:35:08'),
(199,'produk','created','App\\Models\\Product',81,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0081\",\"name\":\"Control 3D normal mindray\",\"category_id\":3,\"unit_id\":7,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-20 11:36:09','2026-07-20 11:36:09'),
(200,'pelanggan','created','App\\Models\\Customer',26,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0026\",\"name\":\"Pak Maulana\",\"phone\":\"081310971800\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-20 13:19:27','2026-07-20 13:19:27'),
(201,'pelanggan','created','App\\Models\\Customer',27,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0027\",\"name\":\"PT Telaga Medika Solusindo\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-20 13:29:12','2026-07-20 13:29:12'),
(202,'supplier','created','App\\Models\\Supplier',18,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0018\",\"name\":\"PT Telaga Medika Solusindo\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-20 13:31:41','2026-07-20 13:31:41'),
(203,'produk','created','App\\Models\\Product',82,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0082\",\"name\":\"Sgot\\/ast mindray bs200\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 08:49:48','2026-07-21 08:49:48'),
(204,'produk','created','App\\Models\\Product',83,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0083\",\"name\":\"Total cholestrol mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 08:50:10','2026-07-21 08:50:10'),
(205,'produk','created','App\\Models\\Product',84,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0084\",\"name\":\"Creatinine mindray bs200\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 11:07:04','2026-07-21 11:07:04'),
(206,'produk','created','App\\Models\\Product',85,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0085\",\"name\":\"Urea glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 11:17:24','2026-07-21 11:17:24'),
(207,'produk','created','App\\Models\\Product',86,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0086\",\"name\":\"Creatinine glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 11:17:46','2026-07-21 11:17:46'),
(208,'produk','created','App\\Models\\Product',87,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0087\",\"name\":\"Sgpt altl glory\",\"category_id\":3,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 11:18:25','2026-07-21 11:18:25'),
(209,'supplier','created','App\\Models\\Supplier',19,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0019\",\"name\":\"PT Berkat Mulia Simpolin\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 11:19:47','2026-07-21 11:19:47'),
(210,'produk','created','App\\Models\\Product',88,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0088\",\"name\":\"Control kimia normal glory\",\"category_id\":3,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 11:21:46','2026-07-21 11:21:46'),
(211,'pelanggan','created','App\\Models\\Customer',28,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0028\",\"name\":\"Rony Wijaya\",\"phone\":null,\"npwp\":\"90.873.749.7-066.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 13:16:28','2026-07-21 13:16:28'),
(212,'pelanggan','created','App\\Models\\Customer',29,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0029\",\"name\":\"Klinik Dr Ranny\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 14:39:24','2026-07-21 14:39:24'),
(213,'produk','created','App\\Models\\Product',89,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0089\",\"name\":\"Tubex TF\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 14:45:12','2026-07-21 14:45:12'),
(214,'supplier','created','App\\Models\\Supplier',20,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0020\",\"name\":\"PT Mikhael Anugrah Medikal Makasar\",\"phone\":null,\"npwp\":\"02.349.095.6-801.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 14:48:07','2026-07-21 14:48:07'),
(215,'supplier','created','App\\Models\\Supplier',21,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0021\",\"name\":\"Ardiyansyah\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 14:49:17','2026-07-21 14:49:17'),
(216,'pelanggan','created','App\\Models\\Customer',30,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0030\",\"name\":\"PT Mikhael Anugrah Medikal Makasar\",\"phone\":null,\"npwp\":\"02.349.095.6-801.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 14:53:24','2026-07-21 14:53:24'),
(217,'produk','created','App\\Models\\Product',90,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0090\",\"name\":\"Gluc Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:16:39','2026-07-21 15:16:39'),
(218,'produk','created','App\\Models\\Product',91,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0091\",\"name\":\"HDL Mindray\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:16:57','2026-07-21 15:16:57'),
(219,'produk','updated','App\\Models\\Product',91,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3,\"unit_id\":2},\"old\":{\"category_id\":null,\"unit_id\":null}}','[]','2026-07-21 15:17:35','2026-07-21 15:17:35'),
(220,'produk','created','App\\Models\\Product',92,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0092\",\"name\":\"Urea Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:18:07','2026-07-21 15:18:07'),
(221,'produk','created','App\\Models\\Product',93,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0093\",\"name\":\"ALT Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:18:43','2026-07-21 15:18:43'),
(222,'produk','created','App\\Models\\Product',94,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0094\",\"name\":\"Triglyceride Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:19:48','2026-07-21 15:19:48'),
(223,'supplier','created','App\\Models\\Supplier',22,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0022\",\"name\":\"Punjul Puromo\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 15:26:34','2026-07-21 15:26:34'),
(224,'produk','created','App\\Models\\Product',95,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0095\",\"name\":\"Uric Acid Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:32:32','2026-07-21 15:32:32'),
(225,'produk','created','App\\Models\\Product',96,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0096\",\"name\":\"HDL Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-21 15:53:48','2026-07-21 15:53:48'),
(226,'supplier','created','App\\Models\\Supplier',23,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0023\",\"name\":\"Pak Rahadian Tjahyo wibisono\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-21 16:09:14','2026-07-21 16:09:14'),
(227,'produk','created','App\\Models\\Product',97,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0097\",\"name\":\"Hiv card merk glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-23 09:49:04','2026-07-23 09:49:04'),
(228,'produk','created','App\\Models\\Product',98,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0098\",\"name\":\"Hbsag card merk glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-23 09:49:26','2026-07-23 09:49:26'),
(229,'supplier','created','App\\Models\\Supplier',24,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0024\",\"name\":\"Pak setya wahyu\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-23 14:58:07','2026-07-23 14:58:07'),
(230,'pelanggan','created','App\\Models\\Customer',31,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0031\",\"name\":\"Pak setya wahyu\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-23 14:58:50','2026-07-23 14:58:50'),
(231,'produk','updated','App\\Models\\Product',75,'updated','App\\Models\\User',3,'{\"attributes\":{\"category_id\":3},\"old\":{\"category_id\":null}}','[]','2026-07-23 15:10:54','2026-07-23 15:10:54'),
(232,'pelanggan','created','App\\Models\\Customer',32,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0032\",\"name\":\"Pak Idham\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-23 16:15:10','2026-07-23 16:15:10'),
(233,'produk','created','App\\Models\\Product',99,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0099\",\"name\":\"NS1 SD Biosensor\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-23 16:23:06','2026-07-23 16:23:06'),
(234,'pelanggan','created','App\\Models\\Customer',33,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0033\",\"name\":\"Dwi Budiono\",\"phone\":null,\"npwp\":\"80.329.481.8-434.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-24 09:18:44','2026-07-24 09:18:44'),
(235,'pelanggan','created','App\\Models\\Customer',34,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0034\",\"name\":\"Pak supriyanto\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-24 09:35:01','2026-07-24 09:35:01'),
(236,'pelanggan','created','App\\Models\\Customer',35,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0035\",\"name\":\"Tokopedia\",\"phone\":\"081213481708\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-24 15:57:27','2026-07-24 15:57:27'),
(237,'pelanggan','created','App\\Models\\Customer',36,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0036\",\"name\":\"Miftahul Huda\",\"phone\":\"081363631001\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-24 16:12:41','2026-07-24 16:12:41'),
(238,'produk','created','App\\Models\\Product',100,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0100\",\"name\":\"Bilirubin total cobas c111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-25 11:01:38','2026-07-25 11:01:38'),
(239,'produk','created','App\\Models\\Product',101,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0101\",\"name\":\"Bilirubin Direct cobas c111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-25 11:02:28','2026-07-25 11:02:28'),
(240,'produk','created','App\\Models\\Product',102,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0102\",\"name\":\"Altl cobas c111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-25 11:14:29','2026-07-25 11:14:29'),
(241,'produk','created','App\\Models\\Product',103,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0103\",\"name\":\"Astl cobas c111\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-25 11:14:44','2026-07-25 11:14:44'),
(242,'supplier','created','App\\Models\\Supplier',25,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0025\",\"name\":\"Ian Ardyansyah\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-25 11:37:41','2026-07-25 11:37:41'),
(243,'supplier','created','App\\Models\\Supplier',26,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0026\",\"name\":\"Ian Ardyansyah\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-25 11:39:49','2026-07-25 11:39:49'),
(244,'produk','created','App\\Models\\Product',104,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0104\",\"name\":\"MCU Urea\",\"category_id\":3,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-26 06:50:34','2026-07-26 06:50:34'),
(245,'produk','created','App\\Models\\Product',105,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0105\",\"name\":\"MCU Triglyceride\",\"category_id\":null,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-26 06:51:05','2026-07-26 06:51:05'),
(246,'pelanggan','created','App\\Models\\Customer',37,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0037\",\"name\":\"PT Tirta Medical Indonesia\",\"phone\":null,\"npwp\":\"02.430.553.4-121.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-26 06:59:16','2026-07-26 06:59:16'),
(247,'pelanggan','created','App\\Models\\Customer',38,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0038\",\"name\":\"Endira era\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-27 12:29:45','2026-07-27 12:29:45'),
(248,'pelanggan','created','App\\Models\\Customer',39,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0039\",\"name\":\"Bapak Masnan\",\"phone\":\"081943701999\",\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-27 15:24:04','2026-07-27 15:24:04'),
(249,'produk','created','App\\Models\\Product',106,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0106\",\"name\":\"AST\\/SGOT Glory\",\"category_id\":3,\"unit_id\":null,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-27 18:10:56','2026-07-27 18:10:56'),
(250,'produk','created','App\\Models\\Product',107,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0107\",\"name\":\"Urea Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-27 18:11:28','2026-07-27 18:11:28'),
(251,'produk','updated','App\\Models\\Product',106,'updated','App\\Models\\User',4,'{\"attributes\":{\"unit_id\":2},\"old\":{\"unit_id\":null}}','[]','2026-07-27 18:11:48','2026-07-27 18:11:48'),
(252,'produk','created','App\\Models\\Product',108,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0108\",\"name\":\"Albumin Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-27 18:12:50','2026-07-27 18:12:50'),
(253,'produk','created','App\\Models\\Product',109,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0109\",\"name\":\"Bilirubine direct mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-28 09:34:57','2026-07-28 09:34:57'),
(254,'produk','created','App\\Models\\Product',110,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0110\",\"name\":\"Bilirubine Total mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-28 09:36:28','2026-07-28 09:36:28'),
(255,'pelanggan','created','App\\Models\\Customer',40,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0040\",\"name\":\"PT Tunas Mulia\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-28 10:21:06','2026-07-28 10:21:06'),
(256,'produk','created','App\\Models\\Product',111,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0111\",\"name\":\"NS1 Arkan Medical\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-28 10:27:07','2026-07-28 10:27:07'),
(257,'supplier','created','App\\Models\\Supplier',27,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"SUP-0027\",\"name\":\"Ibu fitri\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-28 10:27:39','2026-07-28 10:27:39'),
(258,'produk','created','App\\Models\\Product',112,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0112\",\"name\":\"Probe Cleanser mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-28 14:45:29','2026-07-28 14:45:29'),
(259,'produk','created','App\\Models\\Product',113,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0113\",\"name\":\"CD 80 2 Liter mindray\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 09:04:23','2026-07-29 09:04:23'),
(260,'produk','created','App\\Models\\Product',114,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0114\",\"name\":\"CRP SD Biosensor\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:53:57','2026-07-29 22:53:57'),
(261,'produk','created','App\\Models\\Product',115,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0115\",\"name\":\"Troponin I\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:55:41','2026-07-29 22:55:41'),
(262,'produk','created','App\\Models\\Product',116,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0116\",\"name\":\"CKMB\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:56:00','2026-07-29 22:56:00'),
(263,'produk','created','App\\Models\\Product',117,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0117\",\"name\":\"T3 sd biosensor\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:56:24','2026-07-29 22:56:24'),
(264,'produk','created','App\\Models\\Product',118,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0118\",\"name\":\"T4 Sd biosensor\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:56:48','2026-07-29 22:56:48'),
(265,'produk','created','App\\Models\\Product',119,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0119\",\"name\":\"FT4\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 22:57:05','2026-07-29 22:57:05'),
(266,'produk','created','App\\Models\\Product',120,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0120\",\"name\":\"D Dimer sd biosensor\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-29 23:02:09','2026-07-29 23:02:09'),
(267,'produk','created','App\\Models\\Product',121,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0121\",\"name\":\"Autocheck Blood Glucose strip 25 T\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-30 13:53:08','2026-07-30 13:53:08'),
(268,'produk','created','App\\Models\\Product',122,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0122\",\"name\":\"Autocheck Total Cholestrol strip 10 T\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-30 13:53:50','2026-07-30 13:53:50'),
(269,'produk','created','App\\Models\\Product',123,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0123\",\"name\":\"Autocheck Uric Acid Strip 25T\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-30 13:54:30','2026-07-30 13:54:30'),
(270,'produk','created','App\\Models\\Product',124,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0124\",\"name\":\"RightSign HBAB Casette\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-30 13:55:12','2026-07-30 13:55:12'),
(271,'supplier','created','App\\Models\\Supplier',28,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0028\",\"name\":\"PT Burhan Sejahtera Mulia\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-30 13:56:47','2026-07-30 13:56:47'),
(272,'pelanggan','created','App\\Models\\Customer',41,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0041\",\"name\":\"PT Mikhael Anugrah Medikal\",\"phone\":null,\"npwp\":\"81.039.192.0-811.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-30 14:02:28','2026-07-30 14:02:28'),
(273,'produk','created','App\\Models\\Product',125,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0125\",\"name\":\"Triglyceride Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-31 09:13:57','2026-07-31 09:13:57'),
(274,'produk','created','App\\Models\\Product',126,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0126\",\"name\":\"Cholestrol Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-31 09:14:32','2026-07-31 09:14:32'),
(275,'produk','created','App\\Models\\Product',127,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0127\",\"name\":\"Glucose Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-31 09:15:18','2026-07-31 09:15:18'),
(276,'produk','created','App\\Models\\Product',128,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0128\",\"name\":\"Asam urat glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-31 09:16:36','2026-07-31 09:16:36'),
(277,'pelanggan','created','App\\Models\\Customer',42,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0042\",\"name\":\"PT Alam Bhakti\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-31 10:37:41','2026-07-31 10:37:41'),
(278,'pelanggan','created','App\\Models\\Customer',43,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0043\",\"name\":\"Klinik Himmah Husada Karya Utama\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-03 08:51:20','2026-08-03 08:51:20'),
(279,'pelanggan','created','App\\Models\\Customer',44,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0044\",\"name\":\"Klinik medistira 2\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-03 08:52:18','2026-08-03 08:52:18'),
(280,'pelanggan','created','App\\Models\\Customer',45,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0045\",\"name\":\"Klinik Makmal\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-03 08:53:00','2026-08-03 08:53:00'),
(281,'produk','created','App\\Models\\Product',129,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0129\",\"name\":\"Pasien hematology\",\"category_id\":5,\"unit_id\":3,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 09:00:16','2026-08-03 09:00:16'),
(282,'produk','created','App\\Models\\Product',130,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0130\",\"name\":\"Pasien kimia\",\"category_id\":null,\"unit_id\":3,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 09:11:57','2026-08-03 09:11:57'),
(283,'produk','created','App\\Models\\Product',131,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0131\",\"name\":\"C-Reactive Protein IV CRP 4\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 09:32:52','2026-08-03 09:32:52'),
(284,'produk','created','App\\Models\\Product',132,'created','App\\Models\\User',1,'{\"attributes\":{\"code\":\"PRD-0132\",\"name\":\"test produk\",\"category_id\":3,\"unit_id\":1,\"cost_price\":\"1000.00\",\"sell_price\":\"1000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 13:30:13','2026-08-03 13:30:13'),
(285,'produk','created','App\\Models\\Product',133,'created','App\\Models\\User',1,'{\"attributes\":{\"code\":\"PRD-0133\",\"name\":\"test produk 2\",\"category_id\":3,\"unit_id\":4,\"cost_price\":\"1000.00\",\"sell_price\":\"1000.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 13:42:18','2026-08-03 13:42:18'),
(286,'produk','created','App\\Models\\Product',134,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0134\",\"name\":\"Probe Cleanser\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 13:47:17','2026-08-03 13:47:17'),
(287,'pelanggan','created','App\\Models\\Customer',46,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0046\",\"name\":\"Klinik DK Bintaro\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-03 14:20:32','2026-08-03 14:20:32'),
(288,'produk','created','App\\Models\\Product',135,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0135\",\"name\":\"Ise Deproteinezer\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 15:06:37','2026-08-03 15:06:37'),
(289,'produk','created','App\\Models\\Product',136,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0136\",\"name\":\"LDL Choestrol Cobas C111\",\"category_id\":null,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 15:12:46','2026-08-03 15:12:46'),
(290,'produk','created','App\\Models\\Product',137,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0137\",\"name\":\"Dengue IGG\\/IGM Allcheck\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-03 16:25:44','2026-08-03 16:25:44'),
(291,'produk','created','App\\Models\\Product',138,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0138\",\"name\":\"Control 5 Diff normal mindray\",\"category_id\":3,\"unit_id\":7,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 09:07:05','2026-08-04 09:07:05'),
(292,'produk','created','App\\Models\\Product',139,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0139\",\"name\":\"Mikropipette ukuran 100-1000 merk transferepette\",\"category_id\":3,\"unit_id\":3,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 09:13:16','2026-08-04 09:13:16'),
(293,'produk','created','App\\Models\\Product',140,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0140\",\"name\":\"Mikropipette ukuran 500 merk Accucare\",\"category_id\":3,\"unit_id\":3,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 09:14:42','2026-08-04 09:14:42'),
(294,'pelanggan','created','App\\Models\\Customer',47,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0047\",\"name\":\"BWCC Bintaro\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-04 09:16:37','2026-08-04 09:16:37'),
(295,'pelanggan','created','App\\Models\\Customer',48,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0048\",\"name\":\"PT Bhayanaka Tama sakti\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-04 09:56:34','2026-08-04 09:56:34'),
(296,'produk','created','App\\Models\\Product',141,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0141\",\"name\":\"Tabung EDTA 0,5 ml\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:19:24','2026-08-04 12:19:24'),
(297,'produk','created','App\\Models\\Product',142,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0142\",\"name\":\"Stik Urine Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:21:31','2026-08-04 12:21:31'),
(298,'produk','created','App\\Models\\Product',143,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0143\",\"name\":\"HBSAG Card Glory\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:22:33','2026-08-04 12:22:33'),
(299,'produk','created','App\\Models\\Product',144,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0144\",\"name\":\"Kayu Rak TAbung Reaksi\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:46:23','2026-08-04 12:46:23'),
(300,'produk','created','App\\Models\\Product',145,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0145\",\"name\":\"TAbung LED\",\"category_id\":3,\"unit_id\":1,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:47:00','2026-08-04 12:47:00'),
(301,'produk','created','App\\Models\\Product',146,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0146\",\"name\":\"Yelow Tip GP RAk\",\"category_id\":3,\"unit_id\":1,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:48:21','2026-08-04 12:48:21'),
(302,'produk','created','App\\Models\\Product',147,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0147\",\"name\":\"Mikropipette 100-1000UL Dragon Lab\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:49:01','2026-08-04 12:49:01'),
(303,'produk','created','App\\Models\\Product',148,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0148\",\"name\":\"Plat Widal 8 Hole Acrylic\",\"category_id\":3,\"unit_id\":1,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:49:39','2026-08-04 12:49:39'),
(304,'produk','created','App\\Models\\Product',149,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0149\",\"name\":\"Blue Tips\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:50:03','2026-08-04 12:50:03'),
(305,'produk','created','App\\Models\\Product',150,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0150\",\"name\":\"Object Glass\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:50:55','2026-08-04 12:50:55'),
(306,'produk','created','App\\Models\\Product',151,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0151\",\"name\":\"Kartu Golongan Darah\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:51:15','2026-08-04 12:51:15'),
(307,'produk','created','App\\Models\\Product',152,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0152\",\"name\":\"Tabung Reaksi\",\"category_id\":3,\"unit_id\":1,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 12:52:36','2026-08-04 12:52:36'),
(308,'produk','created','App\\Models\\Product',153,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0153\",\"name\":\"Rapid Tes Narkoba 6P Free+\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 13:02:05','2026-08-04 13:02:05'),
(309,'produk','created','App\\Models\\Product',154,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0154\",\"name\":\"DeckGlass 18x18\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 15:38:24','2026-08-04 15:38:24'),
(310,'produk','created','App\\Models\\Product',155,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"PRD-0155\",\"name\":\"Centrifiug corona\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-04 16:39:46','2026-08-04 16:39:46'),
(311,'pelanggan','created','App\\Models\\Customer',49,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0049\",\"name\":\"Klinik Djakirah\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-04 18:45:50','2026-08-04 18:45:50'),
(312,'pelanggan','created','App\\Models\\Customer',50,'created','App\\Models\\User',4,'{\"attributes\":{\"code\":\"CUST-0050\",\"name\":\"Permata Alkes\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-04 19:42:00','2026-08-04 19:42:00'),
(313,'pelanggan','created','App\\Models\\Customer',51,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0051\",\"name\":\"Pak Rahadian\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-05 11:04:17','2026-08-05 11:04:17'),
(314,'produk','created','App\\Models\\Product',156,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0156\",\"name\":\"Faeces Container\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"0.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-08-05 11:06:56','2026-08-05 11:06:56'),
(315,'pelanggan','created','App\\Models\\Customer',52,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0052\",\"name\":\"Bapak Supriyanto\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-05 12:18:40','2026-08-05 12:18:40'),
(316,'pelanggan','created','App\\Models\\Customer',53,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0053\",\"name\":\"Pak Irfan\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-05 13:00:46','2026-08-05 13:00:46'),
(317,'pelanggan','created','App\\Models\\Customer',54,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0054\",\"name\":\"Pak Yamin\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-05 13:23:50','2026-08-05 13:23:50'),
(318,'pelanggan','created','App\\Models\\Customer',55,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0055\",\"name\":\"Shopee\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-08-05 16:24:04','2026-08-05 16:24:04');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('pt-dimas-love-medika-cache-admin@rafli.com|127.0.0.1','i:1;',1784350234),
('pt-dimas-love-medika-cache-admin@rafli.com|127.0.0.1:timer','i:1784350234;',1784350234),
('pt-dimas-love-medika-cache-settings.all','a:18:{s:12:\"company_name\";s:20:\"PT DIMAS LOVE MEDIKA\";s:12:\"company_npwp\";s:19:\"1000 0000 0468 5165\";s:11:\"company_nib\";s:13:\"0108250170791\";s:12:\"company_izin\";s:17:\"01082501707910001\";s:12:\"company_kbli\";s:71:\"46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia\";s:15:\"company_address\";s:116:\"Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310\";s:13:\"company_phone\";s:29:\"021-38939414 / 0859-3319-1346\";s:13:\"company_email\";s:21:\"anggihdimas@gmail.com\";s:11:\"company_pjt\";s:37:\"Nia Love Fiana Puteri (D.III Farmasi)\";s:8:\"ppn_rate\";s:2:\"11\";s:19:\"fp_transaction_code\";s:2:\"04\";s:9:\"fp_prefix\";s:0:\"\";s:14:\"fp_last_serial\";s:2:\"11\";s:14:\"fp_serial_year\";s:2:\"26\";s:9:\"bank_name\";s:8:\"Bank BCA\";s:15:\"bank_account_no\";s:10:\"8011111629\";s:19:\"bank_account_holder\";s:20:\"PT DIMAS LOVE MEDIKA\";s:13:\"director_name\";s:16:\"M Anggih Dimas W\";}',2099362500),
('pt-dimas-love-medika-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:45:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:13:\"products.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:15:\"products.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"products.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:15:\"products.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:15:\"categories.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:17:\"categories.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:17:\"categories.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:17:\"categories.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:10:\"units.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:12:\"units.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:12:\"units.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:12:\"units.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:14:\"customers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:16:\"customers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:16:\"customers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:16:\"customers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:14:\"suppliers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:16:\"suppliers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:16:\"suppliers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:16:\"suppliers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:17:\"sales-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:19:\"sales-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:19:\"sales-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:19:\"sales-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:15:\"invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:15:\"invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:15:\"invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:20:\"purchase-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:29;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:22:\"purchase-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:30;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:22:\"purchase-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:31;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:22:\"purchase-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:17:\"tax-invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:33;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:19:\"tax-invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:34;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:19:\"tax-invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:19:\"tax-invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:15:\"quotations.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:37;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:17:\"quotations.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:38;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:17:\"quotations.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:39;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:17:\"quotations.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:40;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:19:\"reports.operational\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:41;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:15:\"reports.finance\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:42;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:15:\"settings.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:43;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:12:\"users.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:44;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:17:\"transactions.void\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:2:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"Admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"Staff\";s:1:\"c\";s:3:\"web\";}}}',1785983390);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Alkes Nonelektromedik Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Alkes Nonelektromedik Non Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Alkes Diagnostik In Vitro',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Alat Laboratorium',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Consumable Medis',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_payments`
--

DROP TABLE IF EXISTS `customer_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_payments_invoice_id_foreign` (`invoice_id`),
  KEY `customer_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `customer_payments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_payments`
--

LOCK TABLES `customer_payments` WRITE;
/*!40000 ALTER TABLE `customer_payments` DISABLE KEYS */;
INSERT INTO `customer_payments` VALUES
(1,4,3,'2026-07-15',11500000.00,NULL,NULL,'2026-07-15 16:37:09','2026-07-15 16:37:09'),
(2,6,4,'2026-07-16',550000.00,'Transfer',NULL,'2026-07-16 10:08:47','2026-07-16 10:08:47'),
(3,7,4,'2026-07-16',530125.00,'Tokopedia',NULL,'2026-07-16 10:23:13','2026-07-16 10:23:13'),
(4,8,4,'2026-07-16',900000.00,NULL,NULL,'2026-07-16 13:00:56','2026-07-16 13:00:56'),
(5,10,4,'2026-07-16',2923500.00,NULL,NULL,'2026-07-16 13:01:10','2026-07-16 13:01:10'),
(6,1,3,'2026-07-16',2600000.00,NULL,NULL,'2026-07-16 14:57:43','2026-07-16 14:57:43'),
(7,9,3,'2026-07-16',1000000.00,NULL,NULL,'2026-07-16 14:59:01','2026-07-16 14:59:01'),
(8,15,4,'2026-07-16',6510000.00,'Transfer',NULL,'2026-07-16 16:45:52','2026-07-16 16:45:52'),
(9,16,4,'2026-07-17',1143250.00,NULL,NULL,'2026-07-17 12:45:10','2026-07-17 12:45:10'),
(10,17,3,'2026-07-18',650000.00,'tf',NULL,'2026-07-18 11:53:08','2026-07-18 11:53:08'),
(11,18,4,'2026-07-18',549000.00,'Transfer',NULL,'2026-07-18 12:15:44','2026-07-18 12:15:44'),
(12,19,4,'2026-07-18',571000.00,NULL,NULL,'2026-07-18 13:44:26','2026-07-18 13:44:26'),
(13,20,4,'2026-07-19',943500.00,'Tokopedia',NULL,'2026-07-19 10:09:17','2026-07-19 10:09:17'),
(14,21,3,'2026-07-20',601250.00,NULL,NULL,'2026-07-20 13:17:03','2026-07-20 13:17:03'),
(15,22,3,'2026-07-20',567500.00,NULL,NULL,'2026-07-20 13:17:50','2026-07-20 13:17:50'),
(16,25,3,'2026-07-21',2420000.00,NULL,NULL,'2026-07-21 14:51:52','2026-07-21 14:51:52'),
(17,24,4,'2026-07-22',1100000.00,'Transfer',NULL,'2026-07-22 14:07:25','2026-07-22 14:07:25'),
(18,30,4,'2026-07-23',2607500.00,NULL,NULL,'2026-07-23 09:18:50','2026-07-23 09:18:50'),
(19,34,3,'2026-07-23',656676.00,'transfer',NULL,'2026-07-23 16:00:23','2026-07-23 16:00:23'),
(20,32,3,'2026-07-23',3250000.00,NULL,NULL,'2026-07-23 16:00:45','2026-07-23 16:00:45'),
(21,27,3,'2026-07-23',21645000.00,NULL,NULL,'2026-07-23 16:12:13','2026-07-23 16:12:13'),
(22,38,4,'2026-07-24',1665000.00,'Transfer',NULL,'2026-07-24 09:34:06','2026-07-24 09:34:06'),
(23,39,4,'2026-07-24',650000.00,NULL,NULL,'2026-07-24 09:36:03','2026-07-24 09:36:03'),
(24,36,3,'2026-07-24',1500000.00,'transfer',NULL,'2026-07-24 15:55:49','2026-07-24 15:55:49'),
(25,46,4,'2026-07-27',1665000.00,NULL,NULL,'2026-07-27 12:27:02','2026-07-27 12:27:02'),
(26,45,4,'2026-07-27',8000000.00,'Transfer',NULL,'2026-07-27 12:27:46','2026-07-27 12:27:46'),
(27,47,4,'2026-07-27',700000.00,'Transfer',NULL,'2026-07-27 12:30:46','2026-07-27 12:30:46'),
(28,48,4,'2026-07-27',3800000.00,'Transfer',NULL,'2026-07-27 13:22:44','2026-07-27 13:22:44'),
(29,23,3,'2026-07-27',600000.00,NULL,NULL,'2026-07-27 13:42:15','2026-07-27 13:42:15'),
(30,51,4,'2026-07-28',4000000.00,'Transfer',NULL,'2026-07-28 11:01:46','2026-07-28 11:01:46'),
(31,52,4,'2026-07-28',1920000.00,NULL,NULL,'2026-07-28 11:02:00','2026-07-28 11:02:00'),
(32,31,4,'2026-07-29',11322000.00,'Transfer',NULL,'2026-07-29 13:31:45','2026-07-29 13:31:45'),
(33,35,4,'2026-07-29',1082000.00,NULL,NULL,'2026-07-29 14:46:45','2026-07-29 14:46:45'),
(34,56,4,'2026-07-31',3080000.00,'Transfer',NULL,'2026-07-31 13:54:46','2026-07-31 13:54:46'),
(35,55,4,'2026-07-31',3252300.00,NULL,NULL,'2026-07-31 13:55:48','2026-07-31 13:55:48'),
(36,53,4,'2026-07-31',750000.00,NULL,NULL,'2026-07-31 13:56:08','2026-07-31 13:56:08'),
(37,57,4,'2026-08-03',2832600.00,NULL,NULL,'2026-08-03 10:03:31','2026-08-03 10:03:31'),
(38,60,4,'2026-08-03',2000775.00,NULL,NULL,'2026-08-03 10:04:28','2026-08-03 10:04:28'),
(39,50,4,'2026-08-03',571000.00,NULL,NULL,'2026-08-03 10:23:49','2026-08-03 10:23:49'),
(40,42,4,'2026-08-03',571000.00,NULL,NULL,'2026-08-03 10:24:22','2026-08-03 10:24:22'),
(41,41,4,'2026-08-03',571000.00,NULL,NULL,'2026-08-03 10:24:45','2026-08-03 10:24:45'),
(44,72,3,'2026-08-03',943500.00,'transfer',NULL,'2026-08-03 16:22:15','2026-08-03 16:22:15'),
(45,71,3,'2026-08-03',725000.00,NULL,NULL,'2026-08-03 16:22:35','2026-08-03 16:22:35'),
(46,40,3,'2026-08-03',1919795.00,NULL,NULL,'2026-08-03 16:23:20','2026-08-03 16:23:20'),
(47,75,3,'2026-08-04',500000.00,'transfer',NULL,'2026-08-04 12:33:04','2026-08-04 12:33:04'),
(48,74,3,'2026-08-04',650000.00,'transfer',NULL,'2026-08-04 15:05:15','2026-08-04 15:05:15'),
(49,67,3,'2026-08-04',567500.00,NULL,NULL,'2026-08-04 16:17:57','2026-08-04 16:17:57'),
(50,63,3,'2026-08-04',2808000.00,'transfer',NULL,'2026-08-04 16:18:39','2026-08-04 16:18:39'),
(51,80,4,'2026-08-05',2570000.00,NULL,NULL,'2026-08-05 09:30:03','2026-08-05 09:30:03'),
(52,79,4,'2026-08-05',558000.00,NULL,NULL,'2026-08-05 09:30:23','2026-08-05 09:30:23'),
(53,81,3,'2026-08-05',375000.00,NULL,NULL,'2026-08-05 12:16:11','2026-08-05 12:16:11'),
(54,84,3,'2026-08-05',650000.00,NULL,NULL,'2026-08-05 12:19:44','2026-08-05 12:19:44'),
(55,87,4,'2026-08-05',600000.00,NULL,NULL,'2026-08-05 13:33:01','2026-08-05 13:33:01'),
(56,88,4,'2026-08-05',1400000.00,NULL,NULL,'2026-08-05 13:33:16','2026-08-05 13:33:16'),
(57,83,4,'2026-08-05',3600000.00,NULL,NULL,'2026-08-05 15:58:17','2026-08-05 15:58:17'),
(58,91,3,'2026-08-05',1243550.00,NULL,NULL,'2026-08-05 16:31:47','2026-08-05 16:31:47');
/*!40000 ALTER TABLE `customer_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'CUST-0001','RS Medika Sentosa','dr. Andi','021-5551001',NULL,NULL,'01.234.567.8-091.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'CUST-0002','Klinik Sehat Bersama','Ibu Rina','021-5552002',NULL,NULL,'02.345.678.9-091.000',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'CUST-0003','Apotek Kimia Farmasi','Bpk. Joko','0812-1111-2222',NULL,NULL,'',7,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'CUST-0004','Puskesmas Serpong','Ibu Sari','021-5553003',NULL,NULL,'',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'CUST-0005','joko',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 00:01:34','2026-07-13 00:01:34'),
(6,'CUST-0006','PT Amanah Husada Pamulang',NULL,NULL,NULL,'Jl Raya Siliwangi 1A Pondok Benda Pamulang Kota Tangerang Selatan Banten','66.376.297.9-411.000',30,1,'2026-07-13 12:57:55','2026-07-13 12:57:55'),
(7,'CUST-0007','PT Allaya Mandiri Sejahtera',NULL,NULL,NULL,'Ruko Mardi Grass Citra Raya KF 02, 02 Mekar Bakti Panongan Kab Tangerang Banten 15757\r\nTangerang Banten','902616440452000',0,1,'2026-07-13 13:10:48','2026-07-13 13:10:48'),
(8,'CUST-0008','RSIA Vitalaya',NULL,NULL,NULL,'Jl. Siliwangi No.50, Pd. Benda, Kec. Pamulang, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-13 14:09:33','2026-07-13 14:09:33'),
(9,'CUST-0009','RS Citra Insani',NULL,NULL,NULL,'Jl. Permata Lb. Wangi Jl. Raya Parung No.242, Pamegarsari, Kec. Parung, Kabupaten Bogor, Jawa Barat','O23803026403000',30,1,'2026-07-13 14:10:42','2026-07-13 14:11:06'),
(10,'CUST-0010','RS BHAYANGKARA',NULL,NULL,NULL,'Jl. Ciputat Raya No.40, RT.1/RW.9, Pd. Pinang, Kec. Kebayoran Lama, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12310','1237767013000',30,1,'2026-07-13 14:12:57','2026-07-13 14:12:57'),
(11,'CUST-0011','PT Nauli Sejahtera Medika',NULL,NULL,NULL,'Ruko golden Road Jl Pahlawan Seribu BSD City (Sektor VII.C) C32,22 Lengkong Wetan Serpong Tangerang Selatan Banten','86.947.018.7-452.000',0,1,'2026-07-13 14:16:43','2026-07-13 14:16:43'),
(12,'CUST-0012','Permata Alkes',NULL,NULL,NULL,'Komplek Permata Cimahi Jalan Mutiara 1 Nomor 19 Blok C1 RT 06 RW 12 tanimulya Kecamatan ngamprah Bandung',NULL,0,1,'2026-07-13 15:59:32','2026-07-13 15:59:32'),
(13,'CUST-0013','Rumah Sakit Ibu dan Anak Dhia',NULL,'081282103297',NULL,'Jl. Cendrawasih Raya No.90, Sawah Lama, Kec. Ciputat, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-14 12:28:09','2026-07-14 12:28:09'),
(14,'CUST-0014','Sarana Megamedilab Sejahtera',NULL,NULL,NULL,'Perumahan TAman Cimanggu Blok V-I No 32 RT 001 RW 012 Kedung Waringin TAnah Sereal Bogor Jawa barat','0665006243404000',0,1,'2026-07-15 15:26:41','2026-07-15 15:26:41'),
(15,'CUST-0015','Ibu ayu',NULL,NULL,NULL,'Jalan jatinegara barat no 195',NULL,0,1,'2026-07-16 09:25:23','2026-07-16 09:25:23'),
(16,'CUST-0016','Amiau klinik maria dr rossy',NULL,NULL,NULL,'Pontianak kalimantan barat',NULL,0,1,'2026-07-16 10:21:31','2026-07-16 10:21:31'),
(17,'CUST-0017','Pak Azeh hamzah',NULL,NULL,NULL,'Perum mulialand blok c3 no 485 ds karang wangi kec depok kab cirebon',NULL,0,1,'2026-07-16 11:54:14','2026-07-16 11:54:14'),
(18,'CUST-0018','Yulian Dini','KLINIK FASTMED',NULL,NULL,'belakang lottemart fatmawati, ruko golden fatmawati jalan rs fatmawati raya rt 8 rw 6 gandaria selatan cilandak kota administrasi jakarta selatan',NULL,0,1,'2026-07-16 12:40:05','2026-07-16 12:40:41'),
(19,'CUST-0019','PT Mutiara Mitra Kasih','Pak daniel',NULL,NULL,'Komp sanggarmas Lestari Tarajusari, Banjaran Kab. Bandung Jawa Barat','99.333.974.6-445.000',0,1,'2026-07-16 16:17:17','2026-07-16 16:17:17'),
(20,'CUST-0020','Rahadian faisal',NULL,'081324261341',NULL,'Cirebon jawa barat',NULL,0,1,'2026-07-17 12:43:07','2026-07-17 12:43:07'),
(21,'CUST-0021','Pak Latief',NULL,NULL,NULL,'Bekasi',NULL,0,1,'2026-07-18 11:06:41','2026-07-18 11:06:41'),
(22,'CUST-0022','Klinik devina medika','Rabiatul',NULL,NULL,'Blok awa jl surya dharma rt 04 rw 09 jatiasih bekasi',NULL,0,1,'2026-07-18 12:13:15','2026-07-18 12:13:38'),
(23,'CUST-0023','Akp dr haykel mansyur,mars',NULL,NULL,NULL,'Cimanggis depok jawa barat',NULL,0,1,'2026-07-18 13:42:22','2026-07-18 13:42:22'),
(24,'CUST-0024','PT Abi Tama Medika',NULL,NULL,NULL,'Komp. Puri serang hijau blok I7 no 1 rt 004 rw 013 banjarsari cipocok jaya kota serang banten','0537794463401000',0,1,'2026-07-18 17:07:57','2026-07-18 17:07:57'),
(25,'CUST-0025','Rumah sakit permata hati','Karmila','088594654492',NULL,'Jl raya serang rt 2 rw 5 sukadamai kab tangerang cikupa banten',NULL,0,1,'2026-07-19 10:14:17','2026-07-19 10:14:17'),
(26,'CUST-0026','Pak Maulana',NULL,'081310971800',NULL,'Depok',NULL,0,1,'2026-07-20 13:19:27','2026-07-20 13:19:27'),
(27,'CUST-0027','PT Telaga Medika Solusindo',NULL,NULL,NULL,'Komp. Ruko Jungle Walk Blok B No 16 Wanakerta, Sindang Jaya Tangerang',NULL,0,1,'2026-07-20 13:29:12','2026-07-20 13:29:12'),
(28,'CUST-0028','Rony Wijaya',NULL,NULL,NULL,'Jalan Mawar III No 12B RT 005 RW 005 Bintaro Pesanggrahan Kota ADM Jakarta Selatan','90.873.749.7-066.000',0,1,'2026-07-21 13:16:28','2026-07-21 13:16:28'),
(29,'CUST-0029','Klinik Dr Ranny',NULL,NULL,NULL,'Jl. Buaran raya No.40, RT.3/RW.1, Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-21 14:39:24','2026-07-21 14:39:24'),
(30,'CUST-0030','PT Mikhael Anugrah Medikal Makasar',NULL,NULL,NULL,'Jl. Goldel Hills Blk. A No.2, Tamalanrea, Kec. Tamalanrea, Kota Makassar, Sulawesi Selatan','02.349.095.6-801.000',0,1,'2026-07-21 14:53:24','2026-07-21 14:53:24'),
(31,'CUST-0031','Pak setya wahyu',NULL,NULL,NULL,'Gunung sindur',NULL,0,1,'2026-07-23 14:58:50','2026-07-23 14:58:50'),
(32,'CUST-0032','Pak Idham',NULL,NULL,NULL,'Bintaro Tangerang Selatan',NULL,0,1,'2026-07-23 16:15:10','2026-07-23 16:15:10'),
(33,'CUST-0033','Dwi Budiono',NULL,NULL,NULL,'Perumahan griya dramaga asri G no 2 rt.003 rw.008 cibanteng ciampea','80.329.481.8-434.000',0,1,'2026-07-24 09:18:44','2026-07-24 09:18:44'),
(34,'CUST-0034','Pak supriyanto',NULL,NULL,NULL,'Jakarta timur',NULL,0,1,'2026-07-24 09:35:01','2026-07-24 09:35:01'),
(35,'CUST-0035','Tokopedia','Waryantini','081213481708',NULL,'Kab BAndung',NULL,0,1,'2026-07-24 15:57:27','2026-07-24 15:57:27'),
(36,'CUST-0036','Miftahul Huda',NULL,'081363631001',NULL,'Kota PAdang Sumatera BArat',NULL,0,1,'2026-07-24 16:12:41','2026-07-24 16:12:41'),
(37,'CUST-0037','PT Tirta Medical Indonesia',NULL,NULL,NULL,'Jl. Setiabudi Pasar I LK VI no. 212 tanjung sari medan selayang kota medan sumatera utara','02.430.553.4-121.000',0,1,'2026-07-26 06:59:16','2026-07-26 06:59:16'),
(38,'CUST-0038','Endira era',NULL,NULL,NULL,'Puri permata Nirwana Blok F no 5 Argomulyo Sedayu Bantul DIY',NULL,0,1,'2026-07-27 12:29:45','2026-07-27 12:29:45'),
(39,'CUST-0039','Bapak Masnan',NULL,'081943701999',NULL,'Cirebon Jawa Barat',NULL,0,1,'2026-07-27 15:24:04','2026-07-27 15:24:04'),
(40,'CUST-0040','PT Tunas Mulia',NULL,NULL,NULL,'Depok',NULL,0,1,'2026-07-28 10:21:06','2026-07-28 10:21:06'),
(41,'CUST-0041','PT Mikhael Anugrah Medikal',NULL,NULL,NULL,'Jl Benda Perum Bukit Marwah Land Blok B No 2 Watulondo, Puuwatu Kota Kendari Sulawesi Tenggara','81.039.192.0-811.000',0,1,'2026-07-30 14:02:28','2026-07-30 14:02:28'),
(42,'CUST-0042','PT Alam Bhakti',NULL,NULL,NULL,'Depok',NULL,0,1,'2026-07-31 10:37:41','2026-07-31 10:37:41'),
(43,'CUST-0043','Klinik Himmah Husada Karya Utama',NULL,NULL,NULL,'Jalan Sunan Kalijaga No. 235, Cijoro Pasir, Rangkasbitung, Muara Ciujung Tim., Kec. Rangkasbitung, Kabupaten Lebak, Banten 42314',NULL,0,1,'2026-08-03 08:51:20','2026-08-03 08:51:20'),
(44,'CUST-0044','Klinik medistira 2',NULL,NULL,NULL,'Jl. Mercedes Benz No.257, Cicadas, Kec. Gn. Putri, Kabupaten Bogor, Jawa Barat 16964',NULL,0,1,'2026-08-03 08:52:18','2026-08-03 08:52:18'),
(45,'CUST-0045','Klinik Makmal',NULL,NULL,NULL,'Sentra Salemba Mas Blok P Lt. 1 Jl. Salemba Raya No. 34-36, Jakarta Pusat, RT.5/RW.6, Kenari, Kec. Senen, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10430',NULL,0,1,'2026-08-03 08:53:00','2026-08-03 08:53:00'),
(46,'CUST-0046','Klinik DK Bintaro',NULL,NULL,NULL,'Jl. Kesehatan Raya Jl. Sektor 1 No.5E, RT.8/RW.11, Bintaro, Kec. Pesanggrahan, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta',NULL,0,1,'2026-08-03 14:20:32','2026-08-03 14:20:32'),
(47,'CUST-0047','BWCC Bintaro',NULL,NULL,NULL,'Jl. Senayan Utama No.12-14, Pd. Pucung, Kec. Pd. Aren, Kota Tangerang Selatan, Banten 15229',NULL,0,1,'2026-08-04 09:16:37','2026-08-04 09:16:37'),
(48,'CUST-0048','PT Bhayanaka Tama sakti',NULL,NULL,NULL,'Jl. Jankes AD no.72C RT.2/8, RT.4/RW.1, Munjul, Kec. Cipayung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta',NULL,0,1,'2026-08-04 09:56:34','2026-08-04 09:56:34'),
(49,'CUST-0049','Klinik Djakirah',NULL,NULL,NULL,'Jl. Pesantren No.RK 1, RT.003/RW.003, Jurang Manggu Tim., Kec. Pd. Aren, Kota Tangerang Selatan, Banten 15222',NULL,0,1,'2026-08-04 18:45:50','2026-08-04 18:45:50'),
(50,'CUST-0050','Permata Alkes',NULL,NULL,NULL,'Jl. Mutiara I No.19 Blk C1, RT.06/RW.12, Tanimulya, Kec. Ngamprah, Bandung, Jawa Barat 40552',NULL,0,1,'2026-08-04 19:42:00','2026-08-04 19:42:00'),
(51,'CUST-0051','Pak Rahadian',NULL,NULL,NULL,'Bintara Bekasi',NULL,0,1,'2026-08-05 11:04:17','2026-08-05 11:04:17'),
(52,'CUST-0052','Bapak Supriyanto',NULL,NULL,NULL,'Jakarta Timur',NULL,0,1,'2026-08-05 12:18:40','2026-08-05 12:18:40'),
(53,'CUST-0053','Pak Irfan',NULL,NULL,NULL,'Keranggan Jakarta TImur',NULL,0,1,'2026-08-05 13:00:46','2026-08-05 13:00:46'),
(54,'CUST-0054','Pak Yamin',NULL,NULL,NULL,'Depok',NULL,0,1,'2026-08-05 13:23:50','2026-08-05 13:23:50'),
(55,'CUST-0055','Shopee',NULL,NULL,NULL,NULL,NULL,0,1,'2026-08-05 16:24:04','2026-08-05 16:24:04');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipt_items`
--

DROP TABLE IF EXISTS `goods_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipt_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` bigint(20) unsigned NOT NULL,
  `purchase_order_item_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `goods_receipt_items_goods_receipt_id_foreign` (`goods_receipt_id`),
  KEY `goods_receipt_items_purchase_order_item_id_foreign` (`purchase_order_item_id`),
  KEY `goods_receipt_items_product_id_foreign` (`product_id`),
  CONSTRAINT `goods_receipt_items_goods_receipt_id_foreign` FOREIGN KEY (`goods_receipt_id`) REFERENCES `goods_receipts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipt_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `goods_receipt_items_purchase_order_item_id_foreign` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `purchase_order_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipt_items`
--

LOCK TABLES `goods_receipt_items` WRITE;
/*!40000 ALTER TABLE `goods_receipt_items` DISABLE KEYS */;
INSERT INTO `goods_receipt_items` VALUES
(1,1,1,41,2.00,'2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,2,12,53,1.00,'2026-07-14 12:23:50','2026-07-14 12:23:50'),
(3,3,13,58,29.00,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(4,3,14,55,6.00,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(5,4,15,57,21.00,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(6,4,16,54,28.00,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(7,5,17,63,12.00,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(8,5,18,64,4.00,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(9,6,19,61,1.00,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(10,6,20,62,1.00,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(11,7,21,59,5.00,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(12,7,22,60,1.00,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(13,8,31,69,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(14,8,32,71,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(15,8,33,67,1.00,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(16,9,34,75,2.00,'2026-07-14 15:59:02','2026-07-14 15:59:02'),
(17,10,37,78,1.00,'2026-07-15 15:28:14','2026-07-15 15:28:14'),
(18,11,38,79,1.00,'2026-07-15 16:09:25','2026-07-15 16:09:25'),
(19,12,39,41,1.00,'2026-07-16 12:51:44','2026-07-16 12:51:44'),
(20,13,48,73,1.00,'2026-07-16 15:13:27','2026-07-16 15:13:27'),
(21,13,49,67,1.00,'2026-07-16 15:13:27','2026-07-16 15:13:27'),
(22,14,40,74,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(23,14,41,68,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(24,14,42,70,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(25,14,43,66,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(26,14,44,72,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(27,14,45,73,1.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(28,14,46,67,3.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(29,14,47,65,2.00,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(30,15,64,86,4.00,'2026-07-21 13:19:51','2026-07-21 13:19:51'),
(31,15,65,85,1.00,'2026-07-21 13:19:51','2026-07-21 13:19:51'),
(32,15,66,87,3.00,'2026-07-21 13:19:51','2026-07-21 13:19:51'),
(33,15,67,88,1.00,'2026-07-21 13:19:51','2026-07-21 13:19:51'),
(34,16,58,58,25.00,'2026-07-21 13:34:17','2026-07-21 13:34:17'),
(35,16,59,56,5.00,'2026-07-21 13:34:17','2026-07-21 13:34:17'),
(36,17,60,82,1.00,'2026-07-21 13:39:41','2026-07-21 13:39:41'),
(37,17,61,83,1.00,'2026-07-21 13:39:41','2026-07-21 13:39:41'),
(38,18,68,89,4.00,'2026-07-21 14:50:52','2026-07-21 14:50:52'),
(39,19,62,84,1.00,'2026-07-21 15:22:44','2026-07-21 15:22:44'),
(40,19,63,82,2.00,'2026-07-21 15:22:44','2026-07-21 15:22:44'),
(41,20,69,90,2.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(42,20,70,91,2.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(43,20,71,92,1.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(44,20,72,93,1.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(45,20,73,95,2.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(46,20,74,82,1.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(47,20,75,94,3.00,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(48,21,76,96,1.00,'2026-07-21 15:55:37','2026-07-21 15:55:37'),
(49,22,57,80,1.00,'2026-07-21 15:57:05','2026-07-21 15:57:05'),
(50,23,77,89,1.00,'2026-07-23 09:19:25','2026-07-23 09:19:25'),
(51,24,82,98,1.00,'2026-07-23 10:59:45','2026-07-23 10:59:45'),
(52,24,83,97,1.00,'2026-07-23 10:59:45','2026-07-23 10:59:45'),
(53,24,84,86,1.00,'2026-07-23 10:59:45','2026-07-23 10:59:45'),
(54,24,85,96,1.00,'2026-07-23 10:59:45','2026-07-23 10:59:45'),
(55,25,81,89,1.00,'2026-07-23 14:56:19','2026-07-23 14:56:19'),
(56,26,87,56,2.00,'2026-07-23 16:20:18','2026-07-23 16:20:18'),
(57,27,88,99,1.00,'2026-07-23 16:24:24','2026-07-23 16:24:24'),
(58,28,89,48,1.00,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(59,28,90,52,1.00,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(60,28,91,49,2.00,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(61,28,92,50,1.00,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(62,28,93,51,1.00,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(63,29,96,53,2.00,'2026-07-24 15:33:33','2026-07-24 15:33:33'),
(64,29,97,75,3.00,'2026-07-24 15:33:33','2026-07-24 15:33:33'),
(65,29,98,59,5.00,'2026-07-24 15:33:33','2026-07-24 15:33:33'),
(66,30,99,100,1.00,'2026-07-25 11:04:21','2026-07-25 11:04:21'),
(67,30,100,101,1.00,'2026-07-25 11:04:21','2026-07-25 11:04:21'),
(68,31,101,102,1.00,'2026-07-25 11:16:29','2026-07-25 11:16:29'),
(69,31,102,103,1.00,'2026-07-25 11:16:29','2026-07-25 11:16:29'),
(70,31,103,70,2.00,'2026-07-25 11:16:29','2026-07-25 11:16:29'),
(71,32,104,89,2.00,'2026-07-25 11:42:01','2026-07-25 11:42:01'),
(72,33,105,105,50.00,'2026-07-26 06:56:54','2026-07-26 06:56:54'),
(73,33,106,104,100.00,'2026-07-26 06:56:54','2026-07-26 06:56:54'),
(74,34,107,89,1.00,'2026-07-27 12:33:08','2026-07-27 12:33:08'),
(75,35,94,68,1.00,'2026-07-27 13:59:10','2026-07-27 13:59:10'),
(76,35,95,66,2.00,'2026-07-27 13:59:10','2026-07-27 13:59:10'),
(77,36,120,89,1.00,'2026-07-28 10:19:01','2026-07-28 10:19:01'),
(78,37,113,108,1.00,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(79,37,114,106,1.00,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(80,37,115,86,3.00,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(81,37,116,87,3.00,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(82,37,117,107,1.00,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(83,38,121,111,1.00,'2026-07-28 10:28:25','2026-07-28 10:28:25'),
(84,39,118,109,1.00,'2026-07-28 16:15:00','2026-07-28 16:15:00'),
(85,39,119,110,1.00,'2026-07-28 16:15:00','2026-07-28 16:15:00'),
(86,40,138,113,3.00,'2026-07-29 09:05:29','2026-07-29 09:05:29'),
(87,41,135,58,25.00,'2026-07-30 13:37:15','2026-07-30 13:37:15'),
(88,41,136,56,5.00,'2026-07-30 13:37:16','2026-07-30 13:37:16'),
(89,41,137,112,5.00,'2026-07-30 13:37:16','2026-07-30 13:37:16'),
(90,42,139,121,5.00,'2026-07-30 13:59:35','2026-07-30 13:59:35'),
(91,42,140,122,5.00,'2026-07-30 13:59:35','2026-07-30 13:59:35'),
(92,42,141,123,5.00,'2026-07-30 13:59:35','2026-07-30 13:59:35'),
(93,42,142,124,2.00,'2026-07-30 13:59:35','2026-07-30 13:59:35'),
(94,43,155,125,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(95,43,156,126,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(96,43,157,106,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(97,43,158,127,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(98,43,159,128,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(99,43,160,86,1.00,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(100,44,162,87,1.00,'2026-07-31 10:25:28','2026-07-31 10:25:28'),
(101,45,166,127,2.00,'2026-07-31 13:50:35','2026-07-31 13:50:35'),
(102,45,167,128,1.00,'2026-07-31 13:50:35','2026-07-31 13:50:35'),
(103,45,168,125,1.00,'2026-07-31 13:50:35','2026-07-31 13:50:35'),
(104,46,143,61,2.00,'2026-07-31 13:57:15','2026-07-31 13:57:15'),
(105,46,144,62,2.00,'2026-07-31 13:57:15','2026-07-31 13:57:15'),
(106,47,169,61,1.00,'2026-07-31 22:23:37','2026-07-31 22:23:37'),
(107,47,170,62,1.00,'2026-07-31 22:23:37','2026-07-31 22:23:37'),
(108,48,171,75,1.00,'2026-07-31 22:27:17','2026-07-31 22:27:17'),
(109,49,178,84,1.00,'2026-08-03 13:30:55','2026-08-03 13:30:55'),
(110,50,179,134,5.00,'2026-08-03 13:49:12','2026-08-03 13:49:12'),
(111,51,180,56,1.00,'2026-08-03 14:42:32','2026-08-03 14:42:32'),
(112,52,185,135,1.00,'2026-08-03 15:09:33','2026-08-03 15:09:33'),
(113,53,191,72,2.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(114,53,192,71,1.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(115,53,193,67,1.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(116,53,194,103,1.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(117,53,195,102,1.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(118,53,196,136,3.00,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(119,54,197,89,3.00,'2026-08-03 15:33:26','2026-08-03 15:33:26'),
(120,55,202,137,1.00,'2026-08-03 16:28:27','2026-08-03 16:28:27'),
(121,56,198,92,2.00,'2026-08-03 16:34:22','2026-08-03 16:34:22'),
(122,56,199,84,1.00,'2026-08-03 16:34:22','2026-08-03 16:34:22'),
(123,56,200,90,2.00,'2026-08-03 16:34:22','2026-08-03 16:34:22'),
(124,56,201,83,1.00,'2026-08-03 16:34:23','2026-08-03 16:34:23'),
(125,57,203,89,2.00,'2026-08-03 23:04:02','2026-08-03 23:04:02'),
(126,58,223,153,1.00,'2026-08-04 13:04:02','2026-08-04 13:04:02'),
(127,59,227,154,2.00,'2026-08-04 15:39:37','2026-08-04 15:39:37'),
(128,60,228,141,2.00,'2026-08-04 15:50:35','2026-08-04 15:50:35'),
(129,60,229,142,1.00,'2026-08-04 15:50:35','2026-08-04 15:50:35'),
(130,60,230,98,1.00,'2026-08-04 15:50:35','2026-08-04 15:50:35'),
(131,60,231,128,2.00,'2026-08-04 15:50:35','2026-08-04 15:50:35'),
(132,61,215,152,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(133,61,216,145,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(134,61,217,146,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(135,61,218,147,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(136,61,219,148,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(137,61,220,149,1.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(138,61,221,150,2.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(139,61,222,151,2.00,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(140,62,233,131,1.00,'2026-08-04 16:00:19','2026-08-04 16:00:19'),
(141,62,234,67,1.00,'2026-08-04 16:00:19','2026-08-04 16:00:19'),
(142,62,235,102,1.00,'2026-08-04 16:00:19','2026-08-04 16:00:19'),
(143,63,236,67,2.00,'2026-08-04 16:01:32','2026-08-04 16:01:32'),
(144,64,237,81,17.00,'2026-08-04 16:12:41','2026-08-04 16:12:41'),
(145,64,238,138,2.00,'2026-08-04 16:12:41','2026-08-04 16:12:41'),
(146,64,239,83,1.00,'2026-08-04 16:12:41','2026-08-04 16:12:41'),
(147,65,241,155,1.00,'2026-08-04 16:40:56','2026-08-04 16:40:56'),
(148,66,242,129,500.00,'2026-08-04 18:44:38','2026-08-04 18:44:38'),
(149,67,244,143,2.00,'2026-08-05 09:35:02','2026-08-05 09:35:02'),
(150,68,245,156,1.00,'2026-08-05 11:09:32','2026-08-05 11:09:32'),
(151,69,246,98,2.00,'2026-08-05 11:15:57','2026-08-05 11:15:57'),
(152,70,248,144,1.00,'2026-08-05 14:28:58','2026-08-05 14:28:58'),
(153,71,250,150,1.00,'2026-08-05 14:36:03','2026-08-05 14:36:03'),
(154,72,251,126,1.00,'2026-08-05 16:31:24','2026-08-05 16:31:24');
/*!40000 ALTER TABLE `goods_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipts`
--

DROP TABLE IF EXISTS `goods_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gr_number` varchar(255) NOT NULL,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `goods_receipts_gr_number_unique` (`gr_number`),
  KEY `goods_receipts_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `goods_receipts_warehouse_id_foreign` (`warehouse_id`),
  KEY `goods_receipts_user_id_foreign` (`user_id`),
  CONSTRAINT `goods_receipts_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `goods_receipts_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipts`
--

LOCK TABLES `goods_receipts` WRITE;
/*!40000 ALTER TABLE `goods_receipts` DISABLE KEYS */;
INSERT INTO `goods_receipts` VALUES
(1,'GR/2607/00001',1,1,3,'2026-07-14',NULL,'2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,'GR/2607/00002',3,1,3,'2026-07-14',NULL,'2026-07-14 12:23:50','2026-07-14 12:23:50'),
(3,'GR/2607/00003',4,1,3,'2026-07-14',NULL,'2026-07-14 13:19:52','2026-07-14 13:19:52'),
(4,'GR/2607/00004',5,1,3,'2026-07-14',NULL,'2026-07-14 13:29:39','2026-07-14 13:29:39'),
(5,'GR/2607/00005',6,1,3,'2026-07-14',NULL,'2026-07-14 13:40:20','2026-07-14 13:40:20'),
(6,'GR/2607/00006',7,1,3,'2026-07-14',NULL,'2026-07-14 13:45:32','2026-07-14 13:45:32'),
(7,'GR/2607/00007',8,1,3,'2026-07-14',NULL,'2026-07-14 13:54:44','2026-07-14 13:54:44'),
(8,'GR/2607/00008',10,1,3,'2026-07-14',NULL,'2026-07-14 14:59:13','2026-07-14 14:59:13'),
(9,'GR/2607/00009',11,1,3,'2026-07-14',NULL,'2026-07-14 15:59:02','2026-07-14 15:59:02'),
(10,'GR/2607/00010',13,1,3,'2026-07-15',NULL,'2026-07-15 15:28:14','2026-07-15 15:28:14'),
(11,'GR/2607/00011',14,1,3,'2026-07-15',NULL,'2026-07-15 16:09:25','2026-07-15 16:09:25'),
(12,'GR/2607/00012',15,1,3,'2026-07-16',NULL,'2026-07-16 12:51:44','2026-07-16 12:51:44'),
(13,'GR/2607/00013',16,1,3,'2026-07-16',NULL,'2026-07-16 15:13:27','2026-07-16 15:13:27'),
(14,'GR/2607/00014',9,1,3,'2026-07-16',NULL,'2026-07-16 15:26:00','2026-07-16 15:26:00'),
(15,'GR/2607/00015',22,1,3,'2026-07-21',NULL,'2026-07-21 13:19:51','2026-07-21 13:19:51'),
(16,'GR/2607/00016',19,1,4,'2026-07-21',NULL,'2026-07-21 13:34:17','2026-07-21 13:34:17'),
(17,'GR/2607/00017',20,1,3,'2026-07-21',NULL,'2026-07-21 13:39:41','2026-07-21 13:39:41'),
(18,'GR/2607/00018',23,1,3,'2026-07-21',NULL,'2026-07-21 14:50:52','2026-07-21 14:50:52'),
(19,'GR/2607/00019',21,1,3,'2026-07-21',NULL,'2026-07-21 15:22:44','2026-07-21 15:22:44'),
(20,'GR/2607/00020',24,1,3,'2026-07-21',NULL,'2026-07-21 15:39:13','2026-07-21 15:39:13'),
(21,'GR/2607/00021',25,1,3,'2026-07-21',NULL,'2026-07-21 15:55:37','2026-07-21 15:55:37'),
(22,'GR/2607/00022',18,1,3,'2026-07-21',NULL,'2026-07-21 15:57:05','2026-07-21 15:57:05'),
(23,'GR/2607/00023',26,1,4,'2026-07-23',NULL,'2026-07-23 09:19:25','2026-07-23 09:19:25'),
(24,'GR/2607/00024',29,1,4,'2026-07-23',NULL,'2026-07-23 10:59:45','2026-07-23 10:59:45'),
(25,'GR/2607/00025',28,1,4,'2026-07-23',NULL,'2026-07-23 14:56:19','2026-07-23 14:56:19'),
(26,'GR/2607/00026',30,1,3,'2026-07-23',NULL,'2026-07-23 16:20:18','2026-07-23 16:20:18'),
(27,'GR/2607/00027',31,1,3,'2026-07-23',NULL,'2026-07-23 16:24:24','2026-07-23 16:24:24'),
(28,'GR/2607/00028',32,1,3,'2026-07-23',NULL,'2026-07-23 16:34:51','2026-07-23 16:34:51'),
(29,'GR/2607/00029',27,1,3,'2026-07-24',NULL,'2026-07-24 15:33:33','2026-07-24 15:33:33'),
(30,'GR/2607/00030',34,1,4,'2026-07-25',NULL,'2026-07-25 11:04:21','2026-07-25 11:04:21'),
(31,'GR/2607/00031',35,1,4,'2026-07-25',NULL,'2026-07-25 11:16:29','2026-07-25 11:16:29'),
(32,'GR/2607/00032',36,1,3,'2026-07-25',NULL,'2026-07-25 11:42:01','2026-07-25 11:42:01'),
(33,'GR/2607/00033',37,1,4,'2026-07-26',NULL,'2026-07-26 06:56:53','2026-07-26 06:56:53'),
(34,'GR/2607/00034',38,1,4,'2026-07-27',NULL,'2026-07-27 12:33:08','2026-07-27 12:33:08'),
(35,'GR/2607/00035',33,1,3,'2026-07-27',NULL,'2026-07-27 13:59:10','2026-07-27 13:59:10'),
(36,'GR/2607/00036',41,1,4,'2026-07-28',NULL,'2026-07-28 10:19:01','2026-07-28 10:19:01'),
(37,'GR/2607/00037',39,1,4,'2026-07-28',NULL,'2026-07-28 10:25:15','2026-07-28 10:25:15'),
(38,'GR/2607/00038',42,1,4,'2026-07-28',NULL,'2026-07-28 10:28:25','2026-07-28 10:28:25'),
(39,'GR/2607/00039',40,1,3,'2026-07-28',NULL,'2026-07-28 16:15:00','2026-07-28 16:15:00'),
(40,'GR/2607/00040',48,1,4,'2026-07-29',NULL,'2026-07-29 09:05:29','2026-07-29 09:05:29'),
(41,'GR/2607/00041',43,1,4,'2026-07-30',NULL,'2026-07-30 13:37:15','2026-07-30 13:37:15'),
(42,'GR/2607/00042',49,1,3,'2026-07-30',NULL,'2026-07-30 13:59:35','2026-07-30 13:59:35'),
(43,'GR/2607/00043',51,1,4,'2026-07-31',NULL,'2026-07-31 09:54:43','2026-07-31 09:54:43'),
(44,'GR/2607/00044',52,1,4,'2026-07-31',NULL,'2026-07-31 10:25:28','2026-07-31 10:25:28'),
(45,'GR/2607/00045',53,1,4,'2026-07-31',NULL,'2026-07-31 13:50:35','2026-07-31 13:50:35'),
(46,'GR/2607/00046',50,1,4,'2026-07-31',NULL,'2026-07-31 13:57:15','2026-07-31 13:57:15'),
(47,'GR/2607/00047',54,1,4,'2026-07-31',NULL,'2026-07-31 22:23:37','2026-07-31 22:23:37'),
(48,'GR/2607/00048',55,1,4,'2026-07-31',NULL,'2026-07-31 22:27:17','2026-07-31 22:27:17'),
(49,'GR/2608/00049',56,1,3,'2026-08-03',NULL,'2026-08-03 13:30:55','2026-08-03 13:30:55'),
(50,'GR/2608/00050',59,1,3,'2026-08-03',NULL,'2026-08-03 13:49:12','2026-08-03 13:49:12'),
(51,'GR/2608/00051',60,1,3,'2026-08-03',NULL,'2026-08-03 14:42:32','2026-08-03 14:42:32'),
(52,'GR/2608/00052',62,1,3,'2026-08-03',NULL,'2026-08-03 15:09:33','2026-08-03 15:09:33'),
(53,'GR/2608/00053',63,1,3,'2026-08-03',NULL,'2026-08-03 15:17:18','2026-08-03 15:17:18'),
(54,'GR/2608/00054',64,1,3,'2026-08-03',NULL,'2026-08-03 15:33:26','2026-08-03 15:33:26'),
(55,'GR/2608/00055',65,1,3,'2026-08-03',NULL,'2026-08-03 16:28:26','2026-08-03 16:28:27'),
(56,'GR/2608/00056',61,1,3,'2026-08-03',NULL,'2026-08-03 16:34:22','2026-08-03 16:34:22'),
(57,'GR/2608/00057',66,1,4,'2026-08-03',NULL,'2026-08-03 23:04:02','2026-08-03 23:04:02'),
(58,'GR/2608/00058',70,1,3,'2026-08-04',NULL,'2026-08-04 13:04:01','2026-08-04 13:04:01'),
(59,'GR/2608/00059',71,1,3,'2026-08-04',NULL,'2026-08-04 15:39:37','2026-08-04 15:39:37'),
(60,'GR/2608/00060',68,1,3,'2026-08-04',NULL,'2026-08-04 15:50:35','2026-08-04 15:50:35'),
(61,'GR/2608/00061',69,1,3,'2026-08-04',NULL,'2026-08-04 15:51:24','2026-08-04 15:51:24'),
(62,'GR/2608/00062',57,1,3,'2026-08-04',NULL,'2026-08-04 16:00:19','2026-08-04 16:00:19'),
(63,'GR/2608/00063',58,1,3,'2026-08-04',NULL,'2026-08-04 16:01:32','2026-08-04 16:01:32'),
(64,'GR/2608/00064',67,1,3,'2026-08-04',NULL,'2026-08-04 16:12:41','2026-08-04 16:12:41'),
(65,'GR/2608/00065',73,1,4,'2026-08-04',NULL,'2026-08-04 16:40:56','2026-08-04 16:40:56'),
(66,'GR/2608/00066',74,1,4,'2026-08-04',NULL,'2026-08-04 18:44:38','2026-08-04 18:44:38'),
(67,'GR/2608/00067',72,1,4,'2026-08-05',NULL,'2026-08-05 09:35:02','2026-08-05 09:35:02'),
(68,'GR/2608/00068',75,1,3,'2026-08-05',NULL,'2026-08-05 11:09:32','2026-08-05 11:09:32'),
(69,'GR/2608/00069',76,1,3,'2026-08-05',NULL,'2026-08-05 11:15:57','2026-08-05 11:15:57'),
(70,'GR/2608/00070',78,1,3,'2026-08-05',NULL,'2026-08-05 14:28:58','2026-08-05 14:28:58'),
(71,'GR/2608/00071',79,1,3,'2026-08-05',NULL,'2026-08-05 14:36:03','2026-08-05 14:36:03'),
(72,'GR/2608/00072',77,1,3,'2026-08-05',NULL,'2026-08-05 16:31:24','2026-08-05 16:31:24');
/*!40000 ALTER TABLE `goods_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'unpaid',
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_sales_order_id_foreign` (`sales_order_id`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'INV/2607/00001',1,3,'2026-07-14','2026-07-14','paid',2600000.00,2600000.00,NULL,'2026-07-14 11:22:05','2026-07-16 14:57:43'),
(2,'INV/2607/00002',2,3,'2026-07-14','2026-08-13','unpaid',2000000.00,0.00,NULL,'2026-07-14 12:29:30','2026-07-14 12:29:30'),
(3,'INV/2607/00003',3,3,'2026-07-15','2026-08-14','unpaid',5172874.17,0.00,NULL,'2026-07-15 10:59:22','2026-07-15 10:59:22'),
(4,'INV/2607/00004',4,3,'2026-07-15','2026-07-15','paid',11500000.00,11500000.00,NULL,'2026-07-15 15:29:28','2026-07-15 16:37:09'),
(5,'INV/2607/00005',5,3,'2026-07-15','2026-08-14','unpaid',635000.00,0.00,NULL,'2026-07-15 16:13:58','2026-07-15 16:13:58'),
(6,'INV/2607/00006',6,4,'2026-07-16','2026-07-16','paid',550000.00,550000.00,NULL,'2026-07-16 09:26:33','2026-07-16 10:08:47'),
(7,'INV/2607/00007',7,4,'2026-07-16','2026-07-16','paid',530125.00,530125.00,NULL,'2026-07-16 10:22:48','2026-07-16 10:23:13'),
(8,'INV/2607/00008',8,4,'2026-07-16','2026-07-16','paid',900000.00,900000.00,NULL,'2026-07-16 11:55:48','2026-07-16 13:00:56'),
(9,'INV/2607/00009',10,3,'2026-07-16','2026-07-16','paid',1000000.00,1000000.00,NULL,'2026-07-16 12:55:39','2026-07-16 14:59:01'),
(10,'INV/2607/00010',9,3,'2026-07-16','2026-07-16','paid',2923500.00,2923500.00,NULL,'2026-07-16 12:58:32','2026-07-16 13:01:10'),
(11,'INV/2607/00011',11,3,'2026-07-16','2026-08-15','unpaid',8345388.48,0.00,NULL,'2026-07-16 15:32:21','2026-07-16 15:32:21'),
(12,'INV/2607/00012',12,3,'2026-07-16','2026-08-15','unpaid',5049871.74,0.00,NULL,'2026-07-16 15:36:31','2026-07-16 15:36:31'),
(13,'INV/2607/00013',13,3,'2026-07-16','2026-08-15','unpaid',8021131.95,0.00,NULL,'2026-07-16 15:42:48','2026-07-16 15:42:48'),
(14,'INV/2607/00014',14,3,'2026-07-16','2026-08-15','unpaid',2157690.15,0.00,NULL,'2026-07-16 15:45:49','2026-07-16 15:45:49'),
(15,'INV/2607/00015',15,4,'2026-07-16','2026-07-16','paid',6510000.00,6510000.00,NULL,'2026-07-16 16:19:56','2026-07-16 16:45:52'),
(16,'INV/2607/00016',16,4,'2026-07-17','2026-07-17','paid',1143250.00,1143250.00,NULL,'2026-07-17 12:44:59','2026-07-17 12:45:10'),
(17,'INV/2607/00017',17,4,'2026-07-18','2026-07-18','paid',650000.00,650000.00,NULL,'2026-07-18 11:07:35','2026-07-18 11:53:08'),
(18,'INV/2607/00018',18,4,'2026-07-15','2026-07-18','paid',549000.00,549000.00,NULL,'2026-07-18 12:15:30','2026-07-18 12:15:44'),
(19,'INV/2607/00019',19,4,'2026-07-18','2026-07-18','paid',571000.00,571000.00,NULL,'2026-07-18 13:44:19','2026-07-18 13:44:26'),
(20,'INV/2607/00020',21,4,'2026-07-18','2026-07-18','paid',943500.00,943500.00,NULL,'2026-07-18 17:09:53','2026-07-19 10:09:17'),
(21,'INV/2607/00021',22,4,'2026-07-19','2026-07-19','paid',601250.00,601250.00,NULL,'2026-07-19 10:15:18','2026-07-20 13:17:03'),
(22,'INV/2607/00022',23,4,'2026-07-19','2026-07-19','paid',567500.00,567500.00,NULL,'2026-07-19 10:32:46','2026-07-20 13:17:50'),
(23,'INV/2607/00023',24,3,'2026-07-20','2026-07-20','paid',600000.00,600000.00,NULL,'2026-07-20 13:20:22','2026-07-27 13:42:15'),
(24,'INV/2607/00024',25,4,'2026-07-20','2026-07-21','paid',1100000.00,1100000.00,NULL,'2026-07-20 18:37:09','2026-07-22 14:07:25'),
(25,'INV/2607/00025',26,3,'2026-07-21','2026-07-21','paid',2420000.00,2420000.00,NULL,'2026-07-21 13:23:05','2026-07-21 14:51:52'),
(26,'INV/2607/00026',27,3,'2026-07-21','2026-08-20','unpaid',4162500.00,0.00,NULL,'2026-07-21 14:43:10','2026-07-21 14:43:10'),
(27,'INV/2607/00027',28,3,'2026-07-21','2026-07-21','paid',21645000.00,21645000.00,NULL,'2026-07-21 14:54:31','2026-07-23 16:12:13'),
(28,'INV/2607/00028',29,3,'2026-07-21','2026-08-20','unpaid',41385906.00,0.00,NULL,'2026-07-21 15:49:48','2026-07-21 15:49:48'),
(29,'INV/2607/00029',30,3,'2026-07-21','2026-08-20','unpaid',1580000.00,0.00,NULL,'2026-07-21 15:58:38','2026-07-21 15:58:38'),
(30,'INV/2607/00030',31,4,'2026-07-22','2026-07-22','paid',2607500.00,2607500.00,NULL,'2026-07-22 14:09:54','2026-07-23 09:18:50'),
(31,'INV/2607/00031',32,4,'2026-07-23','2026-07-23','paid',11322000.00,11322000.00,NULL,'2026-07-23 09:28:31','2026-07-29 13:31:45'),
(32,'INV/2607/00032',34,4,'2026-07-23','2026-07-23','paid',3250000.00,3250000.00,NULL,'2026-07-23 10:17:10','2026-07-23 16:00:45'),
(33,'INV/2607/00033',33,4,'2026-07-23','2026-08-22','unpaid',860250.00,0.00,NULL,'2026-07-23 11:00:04','2026-07-23 11:00:04'),
(34,'INV/2607/00034',35,4,'2026-07-23','2026-07-23','paid',656676.00,656676.00,NULL,'2026-07-23 12:38:54','2026-07-23 16:00:23'),
(35,'INV/2607/00035',36,4,'2026-07-23','2026-07-24','paid',1082000.00,1082000.00,NULL,'2026-07-23 15:01:13','2026-07-29 14:46:45'),
(36,'INV/2607/00036',37,3,'2026-07-23','2026-07-24','paid',1500000.00,1500000.00,NULL,'2026-07-23 16:16:57','2026-07-24 15:55:49'),
(37,'INV/2607/00037',38,3,'2026-07-23','2026-08-22','unpaid',25122075.00,0.00,NULL,'2026-07-23 16:43:28','2026-07-23 16:43:28'),
(38,'INV/2607/00038',39,4,'2026-07-24','2026-07-24','paid',1665000.00,1665000.00,NULL,'2026-07-24 09:19:31','2026-07-24 09:34:06'),
(39,'INV/2607/00039',40,4,'2026-07-24','2026-07-24','paid',650000.00,650000.00,NULL,'2026-07-24 09:35:59','2026-07-24 09:36:03'),
(40,'INV/2607/00040',41,4,'2026-07-24','2026-07-25','paid',1919795.00,1919795.00,NULL,'2026-07-24 15:39:23','2026-08-03 16:23:20'),
(41,'INV/2607/00041',42,3,'2026-07-24','2026-07-24','paid',571000.00,571000.00,NULL,'2026-07-24 15:58:12','2026-08-03 10:24:45'),
(42,'INV/2607/00042',43,3,'2026-07-24','2026-07-24','paid',571000.00,571000.00,NULL,'2026-07-24 16:14:08','2026-08-03 10:24:22'),
(43,'INV/2607/00043',44,4,'2026-07-25','2026-08-24','unpaid',2093893.73,0.00,NULL,'2026-07-25 11:08:03','2026-07-25 11:24:02'),
(44,'INV/2607/00044',45,4,'2026-07-25','2026-08-24','unpaid',4315863.98,0.00,NULL,'2026-07-25 11:21:37','2026-07-25 11:21:37'),
(45,'INV/2607/00045',46,3,'2026-07-25','2026-07-25','paid',8000000.00,8000000.00,NULL,'2026-07-25 11:44:58','2026-07-27 12:27:46'),
(46,'INV/2607/00046',47,4,'2026-07-26','2026-07-26','paid',1665000.00,1665000.00,NULL,'2026-07-26 07:00:58','2026-07-27 12:27:02'),
(47,'INV/2607/00047',48,4,'2026-07-27','2026-07-27','paid',700000.00,700000.00,NULL,'2026-07-27 12:30:38','2026-07-27 12:30:46'),
(48,'INV/2607/00048',49,4,'2026-07-27','2026-07-27','paid',3800000.00,3800000.00,NULL,'2026-07-27 12:34:07','2026-07-27 13:22:44'),
(49,'INV/2607/00049',50,3,'2026-07-27','2026-08-26','unpaid',2540632.38,0.00,NULL,'2026-07-27 14:05:39','2026-07-27 14:05:39'),
(50,'INV/2607/00050',51,3,'2026-07-27','2026-07-27','paid',571000.00,571000.00,NULL,'2026-07-27 15:24:44','2026-08-03 10:23:49'),
(51,'INV/2607/00051',53,4,'2026-07-28','2026-07-28','paid',4000000.00,4000000.00,NULL,'2026-07-28 10:21:58','2026-07-28 11:01:46'),
(52,'INV/2607/00052',52,4,'2026-07-28','2026-07-28','paid',1920000.00,1920000.00,NULL,'2026-07-28 10:25:43','2026-07-28 11:02:00'),
(53,'INV/2607/00053',54,4,'2026-07-28','2026-07-28','paid',750000.00,750000.00,NULL,'2026-07-28 10:30:14','2026-07-31 13:56:08'),
(54,'INV/2607/00054',55,4,'2026-07-29','2026-08-28','unpaid',9990000.00,0.00,NULL,'2026-07-29 09:07:32','2026-07-29 09:07:32'),
(55,'INV/2607/00055',56,3,'2026-07-30','2026-07-30','paid',3252300.00,3252300.00,NULL,'2026-07-30 14:06:54','2026-07-31 13:55:48'),
(56,'INV/2607/00056',57,4,'2026-07-31','2026-07-31','paid',3080000.00,3080000.00,NULL,'2026-07-31 10:26:18','2026-07-31 13:54:46'),
(57,'INV/2607/00057',59,4,'2026-07-31','2026-07-31','paid',2832600.00,2832600.00,NULL,'2026-07-31 14:15:03','2026-08-03 10:03:31'),
(58,'INV/2607/00058',60,4,'2026-07-31','2026-07-31','unpaid',0.00,0.00,NULL,'2026-07-31 21:54:59','2026-07-31 22:24:30'),
(59,'INV/2607/00059',61,4,'2026-07-31','2026-08-30','unpaid',3810000.00,0.00,NULL,'2026-07-31 22:30:02','2026-07-31 22:30:02'),
(60,'INV/2608/00060',62,4,'2026-08-03','2026-08-03','paid',2000775.00,2000775.00,NULL,'2026-08-03 09:01:53','2026-08-03 10:04:28'),
(61,'INV/2608/00061',63,4,'2026-08-03','2026-08-03','unpaid',4356750.00,0.00,NULL,'2026-08-03 09:05:06','2026-08-03 09:05:06'),
(62,'INV/2608/00062',64,4,'2026-08-03','2026-08-03','unpaid',6571200.00,0.00,NULL,'2026-08-03 09:08:34','2026-08-03 09:08:34'),
(63,'INV/2608/00063',65,4,'2026-08-03','2026-08-03','paid',2808000.00,2808000.00,NULL,'2026-08-03 09:13:47','2026-08-04 16:18:39'),
(64,'INV/2608/00064',66,4,'2026-08-03','2026-08-03','unpaid',0.00,0.00,NULL,'2026-08-03 09:20:48','2026-08-03 09:20:48'),
(65,'INV/2608/00065',67,4,'2026-08-03','2026-08-03','unpaid',0.00,0.00,NULL,'2026-08-03 09:21:49','2026-08-03 09:21:49'),
(67,'INV/2608/00067',70,3,'2026-08-03','2026-08-03','paid',567500.00,567500.00,NULL,'2026-08-03 13:44:24','2026-08-04 16:17:57'),
(69,'INV/2608/00069',71,3,'2026-08-03','2026-09-02','unpaid',1220000.00,0.00,NULL,'2026-08-03 14:23:49','2026-08-03 14:23:49'),
(70,'INV/2608/00070',72,3,'2026-08-03','2026-08-17','unpaid',3740700.00,0.00,NULL,'2026-08-03 14:37:28','2026-08-03 14:37:28'),
(71,'INV/2608/00071',73,3,'2026-08-03','2026-08-03','paid',725000.00,725000.00,NULL,'2026-08-03 14:50:30','2026-08-03 16:22:35'),
(72,'INV/2608/00072',74,3,'2026-08-03','2026-08-03','paid',943500.00,943500.00,NULL,'2026-08-03 15:21:10','2026-08-03 16:22:15'),
(73,'INV/2608/00073',75,3,'2026-08-03','2026-09-02','unpaid',4930000.00,0.00,NULL,'2026-08-03 16:29:09','2026-08-03 16:29:09'),
(74,'INV/2608/00074',76,4,'2026-08-04','2026-08-04','paid',650000.00,650000.00,NULL,'2026-08-04 09:20:57','2026-08-04 15:05:15'),
(75,'INV/2608/00075',77,4,'2026-08-04','2026-08-04','paid',500000.00,500000.00,NULL,'2026-08-04 09:57:20','2026-08-04 12:33:04'),
(76,'INV/2608/00076',78,3,'2026-08-04','2026-09-03','unpaid',750000.00,0.00,NULL,'2026-08-04 13:10:31','2026-08-04 13:10:31'),
(77,'INV/2608/00077',79,3,'2026-08-04','2026-09-03','unpaid',14242815.15,0.00,NULL,'2026-08-04 13:19:26','2026-08-04 13:19:26'),
(78,'INV/2608/00078',80,3,'2026-08-04','2026-08-04','unpaid',2513750.00,0.00,NULL,'2026-08-04 15:12:01','2026-08-04 15:12:01'),
(79,'INV/2608/00079',82,4,'2026-08-04','2026-08-04','paid',558000.00,558000.00,NULL,'2026-08-04 18:47:04','2026-08-05 09:30:23'),
(80,'INV/2608/00080',83,4,'2026-08-04','2026-08-04','paid',2570000.00,2570000.00,NULL,'2026-08-04 19:45:27','2026-08-05 09:30:03'),
(81,'INV/2608/00081',84,4,'2026-08-05','2026-08-05','paid',375000.00,375000.00,NULL,'2026-08-05 09:32:21','2026-08-05 12:16:11'),
(82,'INV/2608/00082',81,3,'2026-08-05','2026-09-03','unpaid',7556436.00,0.00,NULL,'2026-08-05 11:17:11','2026-08-05 11:17:11'),
(83,'INV/2608/00083',85,3,'2026-08-05','2026-08-05','paid',3600000.00,3600000.00,NULL,'2026-08-05 12:14:24','2026-08-05 15:58:17'),
(84,'INV/2608/00084',86,3,'2026-08-05','2026-08-05','paid',650000.00,650000.00,NULL,'2026-08-05 12:19:39','2026-08-05 12:19:44'),
(85,'INV/2608/00085',87,3,'2026-08-05','2026-08-05','unpaid',804100.00,0.00,NULL,'2026-08-05 12:23:02','2026-08-05 12:23:02'),
(86,'INV/2608/00086',88,3,'2026-08-05','2026-09-04','unpaid',26879982.00,0.00,NULL,'2026-08-05 12:36:54','2026-08-05 12:36:54'),
(87,'INV/2608/00087',89,3,'2026-08-05','2026-08-05','paid',600000.00,600000.00,NULL,'2026-08-05 13:02:10','2026-08-05 13:33:01'),
(88,'INV/2608/00088',90,3,'2026-08-05','2026-08-05','paid',1400000.00,1400000.00,NULL,'2026-08-05 13:24:49','2026-08-05 13:33:16'),
(89,'INV/2608/00089',91,3,'2026-08-05','2026-08-19','unpaid',4850700.00,0.00,NULL,'2026-08-05 14:36:16','2026-08-05 14:36:16'),
(90,'INV/2608/00090',92,3,'2026-08-05','2026-09-03','unpaid',6975778.35,0.00,NULL,'2026-08-05 14:49:01','2026-08-05 14:49:01'),
(91,'INV/2608/00091',93,3,'2026-08-05','2026-08-05','paid',1243550.00,1243550.00,NULL,'2026-08-05 16:31:40','2026-08-05 16:31:47');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_07_10_142631_create_activity_log_table',1),
(5,'2026_07_10_142631_create_permission_tables',1),
(6,'2026_07_11_000001_create_categories_table',1),
(7,'2026_07_11_000002_create_units_table',1),
(8,'2026_07_11_000003_create_warehouses_table',1),
(9,'2026_07_11_000004_create_products_table',1),
(10,'2026_07_11_000005_create_customers_table',1),
(11,'2026_07_11_000006_create_suppliers_table',1),
(12,'2026_07_11_000007_create_settings_table',1),
(13,'2026_07_12_000001_create_stock_movements_table',1),
(14,'2026_07_12_000002_create_purchase_orders_table',1),
(15,'2026_07_12_000003_create_purchase_order_items_table',1),
(16,'2026_07_12_000004_create_goods_receipts_table',1),
(17,'2026_07_12_000005_create_supplier_payments_table',1),
(18,'2026_07_12_000006_create_sales_orders_table',1),
(19,'2026_07_12_000007_create_sales_order_items_table',1),
(20,'2026_07_12_000008_create_invoices_table',1),
(21,'2026_07_12_000009_create_customer_payments_table',1),
(22,'2026_07_13_000001_create_tax_invoices_table',1),
(23,'2026_07_13_000002_create_quotations_table',1),
(24,'2026_07_13_000003_add_due_date_to_purchase_orders_table',2),
(25,'2026_07_13_000004_add_due_date_to_sales_orders_table',2),
(26,'2026_07_13_000005_add_invoice_fields_to_supplier_payments_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1),
(1,'App\\Models\\User',3),
(1,'App\\Models\\User',4),
(2,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'products.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(2,'products.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(3,'products.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(4,'products.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(5,'categories.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(6,'categories.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(7,'categories.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(8,'categories.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(9,'units.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(10,'units.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'units.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'units.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'customers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'customers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'customers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'customers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'suppliers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'suppliers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'suppliers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'suppliers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'sales-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'sales-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'sales-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'sales-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'purchase-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(30,'purchase-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(31,'purchase-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(32,'purchase-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(33,'tax-invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(34,'tax-invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(35,'tax-invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(36,'tax-invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(37,'quotations.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(38,'quotations.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(39,'quotations.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(40,'quotations.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(41,'reports.operational','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(42,'reports.finance','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(43,'settings.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(44,'users.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(45,'transactions.void','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `cost_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sell_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `min_stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_unit_id_foreign` (`unit_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(41,'PRD-0041','Lyse M-52DIFF Mindray',3,NULL,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 10:50:32','2026-08-05 16:31:33'),
(48,'PRD-0047','Arumamed Dliuent 5-Diff',3,2,2200000.00,0.00,0.00,0.00,NULL,'size 20L',1,'2026-07-14 11:44:14','2026-07-23 16:43:13'),
(49,'PRD-0049','Arumamed LD Lyse 5-Diff',3,8,5000000.00,0.00,1.00,0.00,NULL,'SIZE 1L',1,'2026-07-14 11:55:23','2026-07-23 16:43:13'),
(50,'PRD-0050','Arumamed LH Lyse 5-Diff',3,8,2600000.00,0.00,0.00,0.00,NULL,'size 200ml',1,'2026-07-14 11:56:27','2026-07-23 16:43:13'),
(51,'PRD-0051','Arumamed Probe Cleaser',3,2,750000.00,0.00,0.00,0.00,NULL,'SIZE 50ML',1,'2026-07-14 11:58:02','2026-07-23 16:43:13'),
(52,'PRD-0052','Arumamed Hematology  Control Normal 5-Diff',3,7,2400000.00,0.00,0.00,0.00,NULL,'size 3ml',1,'2026-07-14 11:59:09','2026-07-23 16:43:13'),
(53,'PRD-0053','Vitamin D SD Biosensor',NULL,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 12:21:38','2026-07-24 15:39:20'),
(54,'PRD-0054','Lyse Lifotronic',3,8,0.00,0.00,9.00,0.00,NULL,NULL,1,'2026-07-14 13:07:27','2026-08-05 13:35:50'),
(55,'PRD-0055','Lyse Mindray M10',3,8,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:07:50','2026-07-31 14:14:45'),
(56,'PRD-0056','Lyse Mindray M30',3,8,0.00,0.00,6.00,0.00,NULL,NULL,1,'2026-07-14 13:08:09','2026-08-05 13:24:45'),
(57,'PRD-0057','Diluent Lifotronic',3,2,0.00,0.00,10.00,0.00,NULL,NULL,1,'2026-07-14 13:08:23','2026-08-05 13:35:50'),
(58,'PRD-0058','Diluent Mindray',3,2,0.00,0.00,34.00,0.00,NULL,NULL,1,'2026-07-14 13:08:33','2026-08-05 13:24:45'),
(59,'PRD-0059','TSH-II FIA (SD)',3,2,0.00,0.00,5.00,0.00,NULL,NULL,1,'2026-07-14 13:08:48','2026-07-24 15:33:33'),
(60,'PRD-0060','HS-CRP (SD)',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 13:09:35','2026-07-22 14:09:46'),
(61,'PRD-0061','Diluent Labnovation',3,2,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-14 13:10:10','2026-07-31 22:29:45'),
(62,'PRD-0062','Lyse Labnovation',3,8,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-14 13:10:34','2026-07-31 22:29:45'),
(63,'PRD-0063','Vacutube EDTA',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:12:00','2026-08-05 11:16:57'),
(64,'PRD-0064','Vacutube Plain (Tabung Merah)',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 13:12:11','2026-08-05 11:16:57'),
(65,'PRD-0065','Cuvette Segment',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:36:14','2026-07-16 15:31:59'),
(66,'PRD-0066','Thermal Paper Cobas C111',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:36:51','2026-07-27 14:05:35'),
(67,'PRD-0067','Gluc Cobas C111',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 14:37:24','2026-08-05 14:48:52'),
(68,'PRD-0068','Cleaner Cobas C111',NULL,8,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:38:02','2026-07-27 14:05:35'),
(69,'PRD-0069','Cleaner Basic Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:38:45','2026-07-16 15:42:36'),
(70,'PRD-0070','Creap Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:39:09','2026-07-25 11:21:29'),
(71,'PRD-0071','HDL C4 Cobas C111',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:39:34','2026-08-04 13:19:20'),
(72,'PRD-0072','Triglyceride',3,2,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-14 14:40:07','2026-08-03 15:17:18'),
(73,'PRD-0073','Ureal Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:40:23','2026-08-04 13:19:20'),
(74,'PRD-0074','Cholestrol Cobas C111',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-14 14:40:50','2026-07-16 15:45:44'),
(75,'PRD-0075','HBA1C SD Biosensor',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-14 15:55:34','2026-08-03 15:21:04'),
(76,'PRD-0076','Standart F TB-Feron FIA',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-15 15:01:06','2026-07-15 15:01:06'),
(77,'PRD-0077','Stadart E TB Feron Tubes',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-15 15:01:43','2026-07-15 15:01:43'),
(78,'PRD-0078','Board Spare Part Cobas C111',NULL,3,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-15 15:27:21','2026-07-15 15:29:21'),
(79,'PRD-0079','HIV Allcheck',NULL,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-15 16:06:15','2026-07-15 16:13:50'),
(80,'PRD-0080','Control 3D normal sysmex',3,7,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-20 11:35:08','2026-07-21 15:58:32'),
(81,'PRD-0081','Control 3D normal mindray',3,7,0.00,0.00,13.00,0.00,NULL,NULL,1,'2026-07-20 11:36:09','2026-08-05 16:31:33'),
(82,'PRD-0082','Sgot/ast mindray bs200',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 08:49:48','2026-07-21 15:49:28'),
(83,'PRD-0083','Total cholestrol mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 08:50:10','2026-08-05 12:36:48'),
(84,'PRD-0084','Creatinine mindray bs200',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 11:07:04','2026-08-05 12:36:48'),
(85,'PRD-0085','Urea glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 11:17:24','2026-07-21 14:43:03'),
(86,'PRD-0086','Creatinine glory',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-21 11:17:46','2026-07-31 10:26:13'),
(87,'PRD-0087','Sgpt altl glory',3,NULL,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 11:18:25','2026-07-31 10:26:13'),
(88,'PRD-0088','Control kimia normal glory',3,NULL,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 11:21:46','2026-07-21 13:22:55'),
(89,'PRD-0089','Tubex TF',NULL,2,0.00,0.00,4.00,0.00,NULL,NULL,1,'2026-07-21 14:45:12','2026-08-05 16:31:33'),
(90,'PRD-0090','Gluc Mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 15:16:39','2026-08-05 16:31:33'),
(91,'PRD-0091','HDL Mindray',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-21 15:16:57','2026-07-21 15:49:28'),
(92,'PRD-0092','Urea Mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 15:18:07','2026-08-05 12:36:48'),
(93,'PRD-0093','ALT Mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 15:18:43','2026-07-21 15:49:28'),
(94,'PRD-0094','Triglyceride Mindray',3,2,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-07-21 15:19:48','2026-07-21 15:49:28'),
(95,'PRD-0095','Uric Acid Mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-21 15:32:32','2026-08-05 12:36:48'),
(96,'PRD-0096','HDL Glory',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-21 15:53:48','2026-07-23 10:59:45'),
(97,'PRD-0097','Hiv card merk glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-23 09:49:04','2026-07-23 11:00:00'),
(98,'PRD-0098','Hbsag card merk glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-23 09:49:26','2026-08-05 11:16:57'),
(99,'PRD-0099','NS1 SD Biosensor',NULL,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-23 16:23:06','2026-07-23 16:24:24'),
(100,'PRD-0100','Bilirubin total cobas c111',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-25 11:01:38','2026-07-25 11:07:58'),
(101,'PRD-0101','Bilirubin Direct cobas c111',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-25 11:02:28','2026-07-25 11:07:58'),
(102,'PRD-0102','Altl cobas c111',3,2,0.00,0.00,1.75,0.00,NULL,NULL,1,'2026-07-25 11:14:29','2026-08-04 16:00:19'),
(103,'PRD-0103','Astl cobas c111',3,2,0.00,0.00,1.50,0.00,NULL,NULL,1,'2026-07-25 11:14:44','2026-08-03 15:17:18'),
(104,'PRD-0104','MCU Urea',3,NULL,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-26 06:50:34','2026-07-26 07:00:53'),
(105,'PRD-0105','MCU Triglyceride',NULL,NULL,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-26 06:51:05','2026-07-26 07:00:53'),
(106,'PRD-0106','AST/SGOT Glory',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-07-27 18:10:56','2026-07-31 10:26:13'),
(107,'PRD-0107','Urea Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-27 18:11:28','2026-07-31 10:26:13'),
(108,'PRD-0108','Albumin Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-27 18:12:50','2026-07-28 10:30:06'),
(109,'PRD-0109','Bilirubine direct mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-28 09:34:57','2026-07-29 09:07:28'),
(110,'PRD-0110','Bilirubine Total mindray',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-28 09:36:28','2026-07-29 09:07:28'),
(111,'PRD-0111','NS1 Arkan Medical',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-28 10:27:07','2026-07-28 10:30:06'),
(112,'PRD-0112','Probe Cleanser mindray',3,2,0.00,0.00,4.00,0.00,NULL,NULL,1,'2026-07-28 14:45:29','2026-08-04 15:11:57'),
(113,'PRD-0113','CD 80 2 Liter mindray',3,8,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 09:04:23','2026-08-05 12:36:48'),
(114,'PRD-0114','CRP SD Biosensor',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:53:57','2026-07-29 22:53:57'),
(115,'PRD-0115','Troponin I',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:55:41','2026-07-29 22:55:41'),
(116,'PRD-0116','CKMB',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:56:00','2026-07-29 22:56:00'),
(117,'PRD-0117','T3 sd biosensor',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:56:24','2026-07-29 22:56:24'),
(118,'PRD-0118','T4 Sd biosensor',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:56:48','2026-07-29 22:56:48'),
(119,'PRD-0119','FT4',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 22:57:05','2026-07-29 22:57:05'),
(120,'PRD-0120','D Dimer sd biosensor',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-29 23:02:09','2026-07-29 23:02:09'),
(121,'PRD-0121','Autocheck Blood Glucose strip 25 T',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-30 13:53:08','2026-07-30 14:06:44'),
(122,'PRD-0122','Autocheck Total Cholestrol strip 10 T',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-30 13:53:50','2026-07-30 14:06:44'),
(123,'PRD-0123','Autocheck Uric Acid Strip 25T',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-30 13:54:30','2026-07-30 14:06:44'),
(124,'PRD-0124','RightSign HBAB Casette',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-30 13:55:12','2026-07-30 14:06:44'),
(125,'PRD-0125','Triglyceride Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-31 09:13:57','2026-08-03 14:23:39'),
(126,'PRD-0126','Cholestrol Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-31 09:14:32','2026-08-05 16:31:33'),
(127,'PRD-0127','Glucose Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-31 09:15:18','2026-08-05 16:31:33'),
(128,'PRD-0128','Asam urat glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-07-31 09:16:36','2026-08-05 14:36:13'),
(129,'PRD-0129','Pasien hematology',5,3,0.00,0.00,469.00,0.00,NULL,NULL,1,'2026-08-03 09:00:16','2026-08-04 18:46:54'),
(130,'PRD-0130','Pasien kimia',NULL,3,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-03 09:11:57','2026-08-03 09:13:36'),
(131,'PRD-0131','C-Reactive Protein IV CRP 4',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-03 09:32:52','2026-08-05 14:48:52'),
(132,'PRD-0132','test produk',3,1,1000.00,1000.00,10.00,0.00,NULL,NULL,1,'2026-08-03 13:30:13','2026-08-03 14:09:19'),
(133,'PRD-0133','test produk 2',3,4,1000.00,1000.00,10.00,0.00,NULL,NULL,1,'2026-08-03 13:42:18','2026-08-03 14:09:19'),
(134,'PRD-0134','Probe Cleanser',3,8,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-08-03 13:47:17','2026-08-03 16:21:55'),
(135,'PRD-0135','Ise Deproteinezer',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-03 15:06:37','2026-08-04 13:19:20'),
(136,'PRD-0136','LDL Choestrol Cobas C111',NULL,2,0.00,0.00,2.00,0.00,NULL,NULL,1,'2026-08-03 15:12:46','2026-08-04 13:19:20'),
(137,'PRD-0137','Dengue IGG/IGM Allcheck',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-03 16:25:44','2026-08-03 16:29:03'),
(138,'PRD-0138','Control 5 Diff normal mindray',3,7,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-08-04 09:07:05','2026-08-05 12:36:48'),
(139,'PRD-0139','Mikropipette ukuran 100-1000 merk transferepette',3,3,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 09:13:16','2026-08-04 09:13:16'),
(140,'PRD-0140','Mikropipette ukuran 500 merk Accucare',3,3,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 09:14:42','2026-08-04 09:14:42'),
(141,'PRD-0141','Tabung EDTA 0,5 ml',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:19:24','2026-08-05 11:16:57'),
(142,'PRD-0142','Stik Urine Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:21:31','2026-08-05 11:16:57'),
(143,'PRD-0143','HBSAG Card Glory',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:22:33','2026-08-05 16:31:33'),
(144,'PRD-0144','Kayu Rak TAbung Reaksi',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:46:23','2026-08-05 14:36:13'),
(145,'PRD-0145','TAbung LED',3,1,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:47:00','2026-08-05 14:36:13'),
(146,'PRD-0146','Yelow Tip GP RAk',3,1,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:48:21','2026-08-05 14:36:13'),
(147,'PRD-0147','Mikropipette 100-1000UL Dragon Lab',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:49:01','2026-08-05 14:36:13'),
(148,'PRD-0148','Plat Widal 8 Hole Acrylic',3,1,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:49:39','2026-08-05 14:36:13'),
(149,'PRD-0149','Blue Tips',3,5,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:50:03','2026-08-05 11:16:57'),
(150,'PRD-0150','Object Glass',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:50:55','2026-08-05 14:36:13'),
(151,'PRD-0151','Kartu Golongan Darah',3,5,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 12:51:15','2026-08-05 11:16:57'),
(152,'PRD-0152','Tabung Reaksi',3,1,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-08-04 12:52:36','2026-08-04 15:51:24'),
(153,'PRD-0153','Rapid Tes Narkoba 6P Free+',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 13:02:05','2026-08-04 13:09:49'),
(154,'PRD-0154','DeckGlass 18x18',3,2,0.00,0.00,1.00,0.00,NULL,NULL,1,'2026-08-04 15:38:24','2026-08-05 11:16:57'),
(155,'PRD-0155','Centrifiug corona',3,2,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-04 16:39:46','2026-08-05 14:36:13'),
(156,'PRD-0156','Faeces Container',3,5,0.00,0.00,0.00,0.00,NULL,NULL,1,'2026-08-05 11:06:56','2026-08-05 11:16:57');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `qty_received` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cost_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_items_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `purchase_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `purchase_order_items_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES
(1,1,41,2.00,2.00,800000.00,0.00,1600000.00,'2026-07-14 11:17:09','2026-07-14 11:17:28'),
(12,3,53,1.00,1.00,2000000.00,500000.00,1500000.00,'2026-07-14 12:22:38','2026-07-14 12:23:50'),
(13,4,58,29.00,29.00,500000.00,0.00,14500000.00,'2026-07-14 13:18:56','2026-07-14 13:19:52'),
(14,4,55,6.00,6.00,630000.00,0.00,3780000.00,'2026-07-14 13:18:56','2026-07-14 13:19:52'),
(15,5,57,21.00,21.00,267000.00,0.00,5607000.00,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(16,5,54,28.00,28.00,300000.00,0.00,8400000.00,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(17,6,63,12.00,12.00,60000.00,0.00,720000.00,'2026-07-14 13:37:23','2026-07-14 13:40:20'),
(18,6,64,4.00,4.00,60000.00,0.00,240000.00,'2026-07-14 13:37:23','2026-07-14 13:40:20'),
(19,7,61,1.00,1.00,840000.00,0.00,840000.00,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(20,7,62,1.00,1.00,528000.00,0.00,528000.00,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(21,8,59,5.00,5.00,972973.00,243243.00,4621622.00,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(22,8,60,1.00,1.00,1760000.00,440000.00,1320000.00,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(31,10,69,1.00,1.00,540000.00,27000.00,513000.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(32,10,71,1.00,1.00,1629000.00,81450.00,1547550.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(33,10,67,1.00,1.00,518000.00,25900.00,492100.00,'2026-07-14 14:58:51','2026-07-14 14:59:13'),
(34,11,75,2.00,2.00,1000000.00,500000.00,1500000.00,'2026-07-14 15:58:13','2026-07-14 15:59:02'),
(35,12,77,1.00,0.00,2100000.00,525000.00,1575000.00,'2026-07-15 15:03:35','2026-07-15 15:03:35'),
(36,12,76,1.00,0.00,2550000.00,637500.00,1912500.00,'2026-07-15 15:03:35','2026-07-15 15:03:35'),
(37,13,78,1.00,1.00,8500000.00,0.00,8500000.00,'2026-07-15 15:27:57','2026-07-15 15:28:14'),
(38,14,79,1.00,1.00,220000.00,0.00,220000.00,'2026-07-15 16:08:59','2026-07-15 16:09:25'),
(39,15,41,1.00,1.00,800000.00,0.00,800000.00,'2026-07-16 12:51:33','2026-07-16 12:51:44'),
(40,9,74,1.00,1.00,735000.00,36750.00,698250.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(41,9,68,1.00,1.00,1558000.00,77900.00,1480100.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(42,9,70,1.00,1.00,692000.00,34600.00,657400.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(43,9,66,1.00,1.00,152000.00,7600.00,144400.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(44,9,72,1.00,1.00,498000.00,24900.00,473100.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(45,9,73,1.00,1.00,870000.00,43500.00,826500.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(46,9,67,3.00,3.00,518000.00,77700.00,1476300.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(47,9,65,2.00,2.00,3056000.00,305600.00,5806400.00,'2026-07-16 14:46:01','2026-07-16 15:26:00'),
(48,16,73,1.00,1.00,350000.00,0.00,350000.00,'2026-07-16 15:12:13','2026-07-16 15:13:27'),
(49,16,67,1.00,1.00,350000.00,0.00,350000.00,'2026-07-16 15:12:13','2026-07-16 15:13:27'),
(50,2,48,1.00,0.00,2200000.00,880000.00,1320000.00,'2026-07-17 12:50:48','2026-07-17 12:50:48'),
(51,2,52,1.00,0.00,2400000.00,960000.00,1440000.00,'2026-07-17 12:50:48','2026-07-17 12:50:48'),
(52,2,49,1.00,0.00,5000000.00,2000000.00,3000000.00,'2026-07-17 12:50:48','2026-07-17 12:50:48'),
(53,2,50,1.00,0.00,2600000.00,1040000.00,1560000.00,'2026-07-17 12:50:48','2026-07-17 12:50:48'),
(54,2,51,1.00,0.00,750000.00,300000.00,450000.00,'2026-07-17 12:50:48','2026-07-17 12:50:48'),
(55,17,81,1.00,0.00,839000.00,0.00,839000.00,'2026-07-20 11:44:48','2026-07-20 11:44:48'),
(56,17,80,1.00,0.00,334000.00,0.00,334000.00,'2026-07-20 11:44:48','2026-07-20 11:44:48'),
(57,18,80,1.00,1.00,839000.00,0.00,839000.00,'2026-07-20 13:26:42','2026-07-21 15:57:05'),
(58,19,58,25.00,25.00,795000.00,7950000.00,11925000.00,'2026-07-20 13:37:52','2026-07-21 13:34:17'),
(59,19,56,5.00,5.00,928000.00,1856000.00,2784000.00,'2026-07-20 13:37:52','2026-07-21 13:34:17'),
(60,20,82,1.00,1.00,739000.00,295600.00,443400.00,'2026-07-21 08:52:24','2026-07-21 13:39:41'),
(61,20,83,1.00,1.00,699000.00,279600.00,419400.00,'2026-07-21 08:52:24','2026-07-21 13:39:41'),
(62,21,84,1.00,1.00,1001000.00,300300.00,700700.00,'2026-07-21 11:10:01','2026-07-21 15:22:44'),
(63,21,82,2.00,2.00,850000.00,510000.00,1190000.00,'2026-07-21 11:10:01','2026-07-21 15:22:44'),
(64,22,86,4.00,4.00,350000.00,560000.00,840000.00,'2026-07-21 11:27:02','2026-07-21 13:19:51'),
(65,22,85,1.00,1.00,500000.00,200000.00,300000.00,'2026-07-21 11:27:02','2026-07-21 13:19:51'),
(66,22,87,3.00,3.00,400000.00,480000.00,720000.00,'2026-07-21 11:27:02','2026-07-21 13:19:51'),
(67,22,88,1.00,1.00,500000.00,200000.00,300000.00,'2026-07-21 11:27:02','2026-07-21 13:19:51'),
(68,23,89,4.00,4.00,3000000.00,0.00,12000000.00,'2026-07-21 14:49:51','2026-07-21 14:50:52'),
(69,24,90,2.00,2.00,250000.00,0.00,500000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(70,24,91,2.00,2.00,250000.00,0.00,500000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(71,24,92,1.00,1.00,250000.00,0.00,250000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(72,24,93,1.00,1.00,250000.00,0.00,250000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(73,24,95,2.00,2.00,250000.00,0.00,500000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(74,24,82,1.00,1.00,250000.00,0.00,250000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(75,24,94,3.00,3.00,250000.00,0.00,750000.00,'2026-07-21 15:38:41','2026-07-21 15:39:13'),
(76,25,96,1.00,1.00,380000.00,152000.00,228000.00,'2026-07-21 15:55:30','2026-07-21 15:55:37'),
(77,26,89,1.00,1.00,3300000.00,0.00,3300000.00,'2026-07-21 16:10:00','2026-07-23 09:19:25'),
(81,28,89,1.00,1.00,3450000.00,0.00,3450000.00,'2026-07-23 09:24:59','2026-07-23 14:56:19'),
(82,29,98,1.00,1.00,270000.00,135000.00,135000.00,'2026-07-23 09:53:29','2026-07-23 10:59:45'),
(83,29,97,1.00,1.00,550000.00,275000.00,275000.00,'2026-07-23 09:53:29','2026-07-23 10:59:45'),
(84,29,86,1.00,1.00,350000.00,140000.00,210000.00,'2026-07-23 09:53:29','2026-07-23 10:59:45'),
(85,29,96,1.00,1.00,380000.00,152000.00,228000.00,'2026-07-23 09:53:29','2026-07-23 10:59:45'),
(87,30,56,2.00,2.00,501000.00,0.00,1002000.00,'2026-07-23 16:20:03','2026-07-23 16:20:18'),
(88,31,99,1.00,1.00,750000.00,0.00,750000.00,'2026-07-23 16:24:03','2026-07-23 16:24:24'),
(89,32,48,1.00,1.00,2200000.00,880000.00,1320000.00,'2026-07-23 16:34:06','2026-07-23 16:34:51'),
(90,32,52,1.00,1.00,2400000.00,960000.00,1440000.00,'2026-07-23 16:34:06','2026-07-23 16:34:51'),
(91,32,49,2.00,2.00,2500000.00,2000000.00,3000000.00,'2026-07-23 16:34:06','2026-07-23 16:34:51'),
(92,32,50,1.00,1.00,2600000.00,1040000.00,1560000.00,'2026-07-23 16:34:06','2026-07-23 16:34:51'),
(93,32,51,1.00,1.00,750000.00,300000.00,450000.00,'2026-07-23 16:34:06','2026-07-23 16:34:51'),
(94,33,68,1.00,1.00,1558000.00,77900.00,1480100.00,'2026-07-24 15:20:12','2026-07-27 13:59:10'),
(95,33,66,2.00,2.00,152000.00,15200.00,288800.00,'2026-07-24 15:20:12','2026-07-27 13:59:10'),
(96,27,53,2.00,2.00,2000000.00,1000000.00,3000000.00,'2026-07-24 15:33:11','2026-07-24 15:33:33'),
(97,27,75,3.00,3.00,1000000.00,750000.00,2250000.00,'2026-07-24 15:33:11','2026-07-24 15:33:33'),
(98,27,59,5.00,5.00,972973.00,243243.00,4621622.00,'2026-07-24 15:33:11','2026-07-24 15:33:33'),
(99,34,100,1.00,1.00,200000.00,0.00,200000.00,'2026-07-25 11:03:50','2026-07-25 11:04:21'),
(100,34,101,1.00,1.00,200000.00,0.00,200000.00,'2026-07-25 11:03:50','2026-07-25 11:04:21'),
(101,35,102,1.00,1.00,100000.00,0.00,100000.00,'2026-07-25 11:16:19','2026-07-25 11:16:29'),
(102,35,103,1.00,1.00,150000.00,0.00,150000.00,'2026-07-25 11:16:19','2026-07-25 11:16:29'),
(103,35,70,2.00,2.00,250000.00,0.00,500000.00,'2026-07-25 11:16:19','2026-07-25 11:16:29'),
(104,36,89,2.00,2.00,3400000.00,0.00,6800000.00,'2026-07-25 11:41:33','2026-07-25 11:42:01'),
(105,37,105,50.00,50.00,5000.00,0.00,250000.00,'2026-07-26 06:56:40','2026-07-26 06:56:54'),
(106,37,104,100.00,100.00,6000.00,0.00,600000.00,'2026-07-26 06:56:40','2026-07-26 06:56:54'),
(107,38,89,1.00,1.00,3000000.00,0.00,3000000.00,'2026-07-27 12:32:59','2026-07-27 12:33:08'),
(113,39,108,1.00,1.00,280000.00,112000.00,168000.00,'2026-07-27 18:22:57','2026-07-28 10:25:15'),
(114,39,106,1.00,1.00,400000.00,160000.00,240000.00,'2026-07-27 18:22:57','2026-07-28 10:25:15'),
(115,39,86,3.00,3.00,350000.00,420000.00,630000.00,'2026-07-27 18:22:57','2026-07-28 10:25:15'),
(116,39,87,3.00,3.00,400000.00,480000.00,720000.00,'2026-07-27 18:22:57','2026-07-28 10:25:15'),
(117,39,107,1.00,1.00,500000.00,200000.00,300000.00,'2026-07-27 18:22:57','2026-07-28 10:25:15'),
(118,40,109,1.00,1.00,2094000.00,628200.00,1465800.00,'2026-07-28 09:38:52','2026-07-28 16:15:00'),
(119,40,110,1.00,1.00,2094000.00,628200.00,1465800.00,'2026-07-28 09:38:52','2026-07-28 16:15:00'),
(120,41,89,1.00,1.00,3145000.00,0.00,3145000.00,'2026-07-28 10:18:32','2026-07-28 10:19:01'),
(121,42,111,1.00,1.00,200000.00,0.00,200000.00,'2026-07-28 10:28:17','2026-07-28 10:28:25'),
(124,44,58,25.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(125,44,56,5.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(126,45,58,25.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(127,45,56,5.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(128,46,58,25.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(129,46,56,5.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(130,47,58,25.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(131,47,56,5.00,0.00,0.00,0.00,0.00,'2026-07-28 14:44:54','2026-07-28 14:44:54'),
(135,43,58,25.00,25.00,795000.00,7950000.00,11925000.00,'2026-07-28 14:56:39','2026-07-30 13:37:15'),
(136,43,56,5.00,5.00,928000.00,1856000.00,2784000.00,'2026-07-28 14:56:39','2026-07-30 13:37:16'),
(137,43,112,5.00,5.00,146000.00,292000.00,438000.00,'2026-07-28 14:56:39','2026-07-30 13:37:16'),
(138,48,113,3.00,3.00,300000.00,0.00,900000.00,'2026-07-29 09:05:15','2026-07-29 09:05:29'),
(139,49,121,5.00,5.00,72072.00,0.00,360360.00,'2026-07-30 13:58:48','2026-07-30 13:59:35'),
(140,49,122,5.00,5.00,144144.00,0.00,720720.00,'2026-07-30 13:58:48','2026-07-30 13:59:35'),
(141,49,123,5.00,5.00,90090.00,0.00,450450.00,'2026-07-30 13:58:48','2026-07-30 13:59:35'),
(142,49,124,2.00,2.00,355856.00,0.00,711712.00,'2026-07-30 13:58:48','2026-07-30 13:59:35'),
(143,50,61,2.00,2.00,840000.00,0.00,1680000.00,'2026-07-31 08:39:58','2026-07-31 13:57:15'),
(144,50,62,2.00,2.00,528000.00,0.00,1056000.00,'2026-07-31 08:39:58','2026-07-31 13:57:15'),
(155,51,125,1.00,1.00,650000.00,260000.00,390000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(156,51,126,1.00,1.00,450000.00,180000.00,270000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(157,51,106,1.00,1.00,400000.00,160000.00,240000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(158,51,127,1.00,1.00,280000.00,112000.00,168000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(159,51,128,1.00,1.00,450000.00,180000.00,270000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(160,51,86,1.00,1.00,350000.00,140000.00,210000.00,'2026-07-31 09:53:52','2026-07-31 09:54:43'),
(162,52,87,1.00,1.00,400000.00,0.00,400000.00,'2026-07-31 10:25:13','2026-07-31 10:25:28'),
(166,53,127,2.00,2.00,280000.00,224000.00,336000.00,'2026-07-31 13:50:04','2026-07-31 13:50:35'),
(167,53,128,1.00,1.00,450000.00,180000.00,270000.00,'2026-07-31 13:50:04','2026-07-31 13:50:35'),
(168,53,125,1.00,1.00,650000.00,260000.00,390000.00,'2026-07-31 13:50:04','2026-07-31 13:50:35'),
(169,54,61,1.00,1.00,0.00,0.00,0.00,'2026-07-31 22:23:25','2026-07-31 22:23:37'),
(170,54,62,1.00,1.00,0.00,0.00,0.00,'2026-07-31 22:23:25','2026-07-31 22:23:37'),
(171,55,75,1.00,1.00,0.00,0.00,0.00,'2026-07-31 22:27:08','2026-07-31 22:27:17'),
(178,56,84,1.00,1.00,1151000.00,345300.00,805700.00,'2026-08-03 13:30:16','2026-08-03 13:30:55'),
(179,59,134,5.00,5.00,25000.00,0.00,125000.00,'2026-08-03 13:48:42','2026-08-03 13:49:12'),
(180,60,56,1.00,1.00,0.00,0.00,0.00,'2026-08-03 14:42:22','2026-08-03 14:42:32'),
(185,62,135,1.00,1.00,985000.00,29550.00,955450.00,'2026-08-03 15:08:45','2026-08-03 15:09:33'),
(191,63,72,2.00,2.00,300000.00,0.00,600000.00,'2026-08-03 15:16:50','2026-08-03 15:17:18'),
(192,63,71,1.00,1.00,700000.00,0.00,700000.00,'2026-08-03 15:16:50','2026-08-03 15:17:18'),
(193,63,67,1.00,1.00,300000.00,0.00,300000.00,'2026-08-03 15:16:50','2026-08-03 15:17:18'),
(194,63,103,1.00,1.00,350000.00,0.00,350000.00,'2026-08-03 15:16:50','2026-08-03 15:17:18'),
(195,63,102,1.00,1.00,350000.00,0.00,350000.00,'2026-08-03 15:16:50','2026-08-03 15:17:18'),
(196,63,136,3.00,3.00,700000.00,0.00,2100000.00,'2026-08-03 15:16:51','2026-08-03 15:17:18'),
(197,64,89,3.00,3.00,3200000.00,0.00,9600000.00,'2026-08-03 15:33:14','2026-08-03 15:33:26'),
(198,61,92,2.00,2.00,486000.00,291600.00,680400.00,'2026-08-03 16:19:48','2026-08-03 16:34:22'),
(199,61,84,1.00,1.00,1151000.00,345300.00,805700.00,'2026-08-03 16:19:48','2026-08-03 16:34:22'),
(200,61,90,2.00,2.00,486450.00,291870.00,681030.00,'2026-08-03 16:19:48','2026-08-03 16:34:22'),
(201,61,83,1.00,1.00,925000.00,277500.00,647500.00,'2026-08-03 16:19:48','2026-08-03 16:34:23'),
(202,65,137,1.00,1.00,539000.00,0.00,539000.00,'2026-08-03 16:28:14','2026-08-03 16:28:27'),
(203,66,89,2.00,2.00,3200000.00,0.00,6400000.00,'2026-08-03 23:03:50','2026-08-03 23:04:02'),
(215,69,152,1.00,1.00,25226.00,0.00,25226.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(216,69,145,1.00,1.00,31532.00,0.00,31532.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(217,69,146,1.00,1.00,94595.00,0.00,94595.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(218,69,147,1.00,1.00,495496.00,0.00,495496.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(219,69,148,1.00,1.00,49550.00,0.00,49550.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(220,69,149,1.00,1.00,36036.00,0.00,36036.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(221,69,150,2.00,2.00,19820.00,0.00,39640.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(222,69,151,2.00,2.00,18018.00,0.00,36036.00,'2026-08-04 12:57:14','2026-08-04 15:51:24'),
(223,70,153,1.00,1.00,459000.00,0.00,459000.00,'2026-08-04 13:03:49','2026-08-04 13:04:02'),
(227,71,154,2.00,2.00,20315.00,0.00,40630.00,'2026-08-04 15:39:19','2026-08-04 15:39:37'),
(228,68,141,2.00,2.00,110000.00,0.00,220000.00,'2026-08-04 15:50:21','2026-08-04 15:50:35'),
(229,68,142,1.00,1.00,170000.00,0.00,170000.00,'2026-08-04 15:50:21','2026-08-04 15:50:35'),
(230,68,98,1.00,1.00,290000.00,145000.00,145000.00,'2026-08-04 15:50:21','2026-08-04 15:50:35'),
(231,68,128,2.00,2.00,500000.00,400000.00,600000.00,'2026-08-04 15:50:21','2026-08-04 15:50:35'),
(233,57,131,1.00,1.00,1715000.00,85750.00,1629250.00,'2026-08-04 16:00:08','2026-08-04 16:00:19'),
(234,57,67,1.00,1.00,518000.00,25900.00,492100.00,'2026-08-04 16:00:08','2026-08-04 16:00:19'),
(235,57,102,1.00,1.00,791000.00,39550.00,751450.00,'2026-08-04 16:00:08','2026-08-04 16:00:19'),
(236,58,67,2.00,2.00,518000.00,51800.00,984200.00,'2026-08-04 16:01:23','2026-08-04 16:01:32'),
(237,67,81,17.00,17.00,384000.00,0.00,6528000.00,'2026-08-04 16:12:10','2026-08-04 16:12:41'),
(238,67,138,2.00,2.00,706000.00,0.00,1412000.00,'2026-08-04 16:12:10','2026-08-04 16:12:41'),
(239,67,83,1.00,1.00,925000.00,277500.00,647500.00,'2026-08-04 16:12:10','2026-08-04 16:12:41'),
(241,73,155,1.00,1.00,1330771.00,0.00,1330771.00,'2026-08-04 16:40:41','2026-08-04 16:40:56'),
(242,74,129,500.00,500.00,1.00,0.00,500.00,'2026-08-04 18:44:21','2026-08-04 18:44:38'),
(244,72,143,2.00,2.00,290000.00,290000.00,290000.00,'2026-08-05 09:34:48','2026-08-05 09:35:02'),
(245,75,156,1.00,1.00,318000.00,0.00,318000.00,'2026-08-05 11:09:18','2026-08-05 11:09:32'),
(246,76,98,2.00,2.00,1.00,0.00,2.00,'2026-08-05 11:15:44','2026-08-05 11:15:57'),
(248,78,144,1.00,1.00,300000.00,0.00,300000.00,'2026-08-05 14:28:46','2026-08-05 14:28:58'),
(250,79,150,1.00,1.00,10000.00,0.00,10000.00,'2026-08-05 14:35:55','2026-08-05 14:36:03'),
(251,77,126,1.00,1.00,500000.00,200000.00,300000.00,'2026-08-05 16:31:13','2026-08-05 16:31:24');
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `po_number` varchar(255) NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_orders_po_number_unique` (`po_number`),
  KEY `purchase_orders_supplier_id_foreign` (`supplier_id`),
  KEY `purchase_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES
(1,'PO/2607/00001',5,3,'2026-07-14','2026-07-14','received',0,11.00,1600000.00,0.00,1600000.00,0.00,1600000.00,1600000.00,NULL,'2026-07-14 11:17:09','2026-07-14 11:17:53'),
(2,'PO/2607/00002',16,3,'2026-07-14','2026-07-14','cancelled',1,11.00,7770000.00,0.00,7770000.00,854700.00,8624700.00,0.00,'KSO AR 580 HEMATOLOGGY ANALYSER','2026-07-14 12:11:04','2026-07-23 16:30:29'),
(3,'PO/2607/00003',7,3,'2026-07-14','2026-07-14','received',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,1665000.00,NULL,'2026-07-14 12:22:38','2026-07-23 12:58:35'),
(4,'PO/2607/00004',9,3,'2026-07-14','2026-07-14','received',0,11.00,18280000.00,0.00,18280000.00,0.00,18280000.00,18280000.00,NULL,'2026-07-14 13:18:56','2026-07-14 13:19:59'),
(5,'PO/2607/00005',10,3,'2026-07-14','2026-07-14','received',1,11.00,14007000.00,0.00,14007000.00,1540770.00,15547770.00,15547770.00,NULL,'2026-07-14 13:29:10','2026-07-14 13:29:39'),
(6,'PO/2607/00006',11,3,'2026-07-14','2026-07-14','received',1,11.00,960000.00,0.00,960000.00,105600.00,1065600.00,1065600.00,NULL,'2026-07-14 13:37:23','2026-07-14 13:40:21'),
(7,'PO/2607/00007',4,3,'2026-07-14','2026-07-14','received',1,11.00,1368000.00,0.00,1368000.00,150480.00,1518480.00,1518480.00,NULL,'2026-07-14 13:44:28','2026-07-14 13:45:32'),
(8,'PO/2607/00008',7,3,'2026-07-14','2026-07-14','received',1,11.00,5941622.00,0.00,5941622.00,653578.42,6595200.42,6595200.42,NULL,'2026-07-14 13:54:30','2026-07-14 13:54:44'),
(9,'PO/2607/00009',12,3,'2026-07-14','2026-07-16','received',1,11.00,11562450.00,0.00,11562450.00,1271869.50,12834319.50,12834319.50,NULL,'2026-07-14 14:50:30','2026-07-16 15:29:44'),
(10,'PO/2607/00010',12,3,'2026-07-14','2026-07-14','received',1,11.00,2552650.00,0.00,2552650.00,280791.50,2833441.50,2833441.50,NULL,'2026-07-14 14:58:51','2026-07-14 14:59:27'),
(11,'PO/2607/00011',7,3,'2026-07-14','2026-07-14','received',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,0.00,NULL,'2026-07-14 15:58:13','2026-07-14 15:59:02'),
(12,'PO/2607/00012',7,3,'2026-07-15','2026-07-17','cancelled',1,11.00,3487500.00,0.00,3487500.00,383625.00,3871125.00,0.00,NULL,'2026-07-15 15:03:35','2026-07-21 16:07:20'),
(13,'PO/2607/00013',13,3,'2026-07-15','2026-07-15','received',0,11.00,8500000.00,0.00,8500000.00,0.00,8500000.00,8500000.00,NULL,'2026-07-15 15:27:57','2026-07-15 16:36:51'),
(14,'PO/2607/00014',14,3,'2026-07-15','2026-07-15','received',0,11.00,220000.00,0.00,220000.00,0.00,220000.00,220000.00,NULL,'2026-07-15 16:08:59','2026-07-15 16:11:01'),
(15,'PO/2607/00015',5,3,'2026-07-16','2026-07-16','received',0,11.00,800000.00,0.00,800000.00,0.00,800000.00,800000.00,NULL,'2026-07-16 12:51:33','2026-07-16 12:52:23'),
(16,'PO/2607/00016',15,3,'2026-07-16','2026-07-16','received',0,11.00,700000.00,0.00,700000.00,0.00,700000.00,700000.00,NULL,'2026-07-16 15:12:13','2026-07-16 15:13:27'),
(17,'PO/2607/00017',17,4,'2026-07-20','2026-07-20','cancelled',1,11.00,1173000.00,0.00,1173000.00,129030.00,1302030.00,0.00,NULL,'2026-07-20 11:44:48','2026-07-20 13:23:35'),
(18,'PO/2607/00018',17,4,'2026-07-20','2026-07-20','received',1,11.00,839000.00,0.00,839000.00,92290.00,931290.00,931290.00,NULL,'2026-07-20 13:26:42','2026-07-21 15:57:05'),
(19,'PO/2607/00019',18,4,'2026-07-20','2026-07-20','received',1,11.00,14709000.00,0.00,14709000.00,1617990.00,16326990.00,16326990.00,NULL,'2026-07-20 13:37:52','2026-07-21 13:38:48'),
(20,'PO/2607/00020',18,4,'2026-07-21','2026-07-22','received',1,11.00,862800.00,0.00,862800.00,94908.00,957708.00,957708.00,NULL,'2026-07-21 08:52:24','2026-07-21 13:40:09'),
(21,'PO/2607/00021',17,4,'2026-07-21','2026-07-22','received',1,11.00,1890700.00,0.00,1890700.00,207977.00,2098677.00,2098677.00,NULL,'2026-07-21 11:10:01','2026-07-21 15:22:55'),
(22,'PO/2607/00022',19,4,'2026-07-21','2026-07-21','received',0,11.00,2160000.00,0.00,2160000.00,0.00,2160000.00,2160000.00,NULL,'2026-07-21 11:27:02','2026-07-21 13:22:32'),
(23,'PO/2607/00023',21,3,'2026-07-21','2026-07-21','received',0,11.00,12000000.00,0.00,12000000.00,0.00,12000000.00,12000000.00,NULL,'2026-07-21 14:49:51','2026-07-21 14:51:01'),
(24,'PO/2607/00024',22,3,'2026-07-21','2026-07-21','received',0,11.00,3000000.00,0.00,3000000.00,0.00,3000000.00,3000000.00,NULL,'2026-07-21 15:38:41','2026-07-21 16:05:48'),
(25,'PO/2607/00025',19,3,'2026-07-21','2026-07-21','received',0,11.00,228000.00,0.00,228000.00,0.00,228000.00,228000.00,NULL,'2026-07-21 15:55:30','2026-07-21 16:05:18'),
(26,'PO/2607/00026',23,4,'2026-07-21','2026-07-22','received',0,11.00,3300000.00,0.00,3300000.00,0.00,3300000.00,3300000.00,NULL,'2026-07-21 16:10:00','2026-07-23 09:19:25'),
(27,'PO/2607/00027',7,4,'2026-07-23','2026-07-24','received',1,11.00,9871622.00,0.00,9871622.00,1085878.42,10957500.42,0.00,NULL,'2026-07-23 09:23:40','2026-07-24 15:33:33'),
(28,'PO/2607/00028',23,4,'2026-07-23','2026-07-23','received',0,11.00,3450000.00,0.00,3450000.00,0.00,3450000.00,3450000.00,NULL,'2026-07-23 09:24:59','2026-07-23 14:56:28'),
(29,'PO/2607/00029',19,4,'2026-07-23','2026-07-23','received',0,11.00,848000.00,0.00,848000.00,0.00,848000.00,848000.00,NULL,'2026-07-23 09:53:29','2026-07-23 14:55:59'),
(30,'PO/2607/00030',22,3,'2026-07-23','2026-07-23','received',0,11.00,1002000.00,0.00,1002000.00,0.00,1002000.00,1002000.00,NULL,'2026-07-23 16:19:44','2026-07-23 16:20:27'),
(31,'PO/2607/00031',23,3,'2026-07-23','2026-07-23','received',0,11.00,750000.00,0.00,750000.00,0.00,750000.00,750000.00,NULL,'2026-07-23 16:24:03','2026-07-23 16:24:24'),
(32,'PO/2607/00032',16,3,'2026-07-23','2026-07-23','received',1,11.00,7770000.00,0.00,7770000.00,854700.00,8624700.00,8624700.00,NULL,'2026-07-23 16:34:06','2026-07-24 15:30:15'),
(33,'PO/2607/00033',12,4,'2026-07-24','2026-07-27','received',1,11.00,1768900.00,0.00,1768900.00,194579.00,1963479.00,1963479.00,NULL,'2026-07-24 15:20:12','2026-07-27 14:01:32'),
(34,'PO/2607/00034',22,4,'2026-07-25','2026-07-25','received',0,11.00,400000.00,0.00,400000.00,0.00,400000.00,400000.00,NULL,'2026-07-25 11:03:50','2026-07-25 11:04:21'),
(35,'PO/2607/00035',22,4,'2026-07-25','2026-07-25','received',0,11.00,750000.00,0.00,750000.00,0.00,750000.00,750000.00,NULL,'2026-07-25 11:16:19','2026-07-25 11:16:39'),
(36,'PO/2607/00036',26,3,'2026-07-25','2026-07-25','received',0,11.00,6800000.00,0.00,6800000.00,0.00,6800000.00,6800000.00,NULL,'2026-07-25 11:41:33','2026-07-25 11:42:01'),
(37,'PO/2607/00037',22,4,'2026-07-26','2026-07-26','received',0,11.00,850000.00,0.00,850000.00,0.00,850000.00,850000.00,NULL,'2026-07-26 06:56:40','2026-07-27 12:31:25'),
(38,'PO/2607/00038',21,4,'2026-07-27','2026-07-27','received',0,11.00,3000000.00,0.00,3000000.00,0.00,3000000.00,3000000.00,NULL,'2026-07-27 12:32:59','2026-07-27 12:33:13'),
(39,'PO/2607/00039',19,4,'2026-07-27','2026-07-28','received',0,11.00,2058000.00,0.00,2058000.00,0.00,2058000.00,2058000.00,NULL,'2026-07-27 18:15:27','2026-07-28 10:25:15'),
(40,'PO/2607/00040',17,4,'2026-07-28','2026-07-28','received',1,11.00,2931600.00,0.00,2931600.00,322476.00,3254076.00,3254076.00,NULL,'2026-07-28 09:38:52','2026-07-28 16:15:09'),
(41,'PO/2607/00041',21,4,'2026-07-28','2026-07-28','received',0,11.00,3145000.00,0.00,3145000.00,0.00,3145000.00,3145000.00,NULL,'2026-07-28 10:18:32','2026-07-28 10:19:01'),
(42,'PO/2607/00042',27,4,'2026-07-28','2026-07-28','received',0,11.00,200000.00,0.00,200000.00,0.00,200000.00,200000.00,NULL,'2026-07-28 10:28:17','2026-07-28 10:28:29'),
(43,'PO/2607/00043',18,4,'2026-07-28','2026-07-29','received',1,11.00,15147000.00,0.00,15147000.00,1666170.00,16813170.00,16813170.00,NULL,'2026-07-28 14:44:54','2026-07-30 13:37:29'),
(44,'PO/2607/00044',18,4,'2026-07-28','2026-07-29','cancelled',1,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-28 14:44:54','2026-07-28 14:46:16'),
(45,'PO/2607/00045',18,4,'2026-07-28','2026-07-29','cancelled',1,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-28 14:44:54','2026-07-28 14:46:08'),
(46,'PO/2607/00046',18,4,'2026-07-28','2026-07-29','cancelled',1,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-28 14:44:54','2026-07-28 14:45:59'),
(47,'PO/2607/00047',18,4,'2026-07-28','2026-07-29','cancelled',1,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-28 14:44:54','2026-07-28 14:45:48'),
(48,'PO/2607/00048',22,4,'2026-07-29','2026-07-29','received',0,11.00,900000.00,0.00,900000.00,0.00,900000.00,900000.00,NULL,'2026-07-29 09:05:15','2026-07-29 09:05:37'),
(49,'PO/2607/00049',28,3,'2026-07-30','2026-07-31','received',1,11.00,2243242.00,0.00,2243242.00,246756.62,2489998.62,2489998.62,NULL,'2026-07-30 13:58:48','2026-08-04 12:45:17'),
(50,'PO/2607/00050',4,4,'2026-07-31','2026-07-31','received',1,11.00,2736000.00,0.00,2736000.00,300960.00,3036960.00,3036960.00,NULL,'2026-07-31 08:39:58','2026-07-31 13:57:15'),
(51,'PO/2607/00051',19,4,'2026-07-31','2026-07-31','received',0,11.00,1548000.00,0.00,1548000.00,0.00,1548000.00,1548000.00,NULL,'2026-07-31 09:21:01','2026-07-31 13:51:30'),
(52,'PO/2607/00052',19,4,'2026-07-31','2026-07-31','received',0,11.00,400000.00,0.00,400000.00,0.00,400000.00,400000.00,NULL,'2026-07-31 10:07:00','2026-07-31 13:53:02'),
(53,'PO/2607/00053',19,4,'2026-07-31','2026-07-31','received',0,11.00,996000.00,0.00,996000.00,0.00,996000.00,996000.00,NULL,'2026-07-31 10:57:52','2026-07-31 13:53:47'),
(54,'PO/2607/00054',17,4,'2026-07-31','2026-07-31','received',0,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-31 22:23:25','2026-07-31 22:23:37'),
(55,'PO/2607/00055',7,4,'2026-07-31','2026-08-31','received',0,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-07-31 22:27:08','2026-07-31 22:27:17'),
(56,'PO/2608/00056',17,4,'2026-08-03','2026-08-03','received',1,11.00,805700.00,0.00,805700.00,88627.00,894327.00,894327.00,NULL,'2026-08-03 08:48:24','2026-08-04 08:43:48'),
(57,'PO/2608/00057',12,4,'2026-08-03','2026-08-04','received',1,11.00,2872800.00,0.00,2872800.00,316008.00,3188808.00,3188808.00,NULL,'2026-08-03 09:36:33','2026-08-04 16:03:39'),
(58,'PO/2608/00058',12,4,'2026-08-03','2026-08-03','received',1,11.00,984200.00,0.00,984200.00,108262.00,1092462.00,1092462.00,NULL,'2026-08-03 10:54:24','2026-08-04 16:02:49'),
(59,'PO/2608/00059',22,3,'2026-08-03','2026-08-03','received',0,11.00,125000.00,0.00,125000.00,0.00,125000.00,125000.00,NULL,'2026-08-03 13:48:42','2026-08-03 13:49:13'),
(60,'PO/2608/00060',22,3,'2026-08-03','2026-08-03','received',0,11.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,'2026-08-03 14:42:22','2026-08-03 14:42:32'),
(61,'PO/2608/00061',17,3,'2026-08-03','2026-08-03','received',1,11.00,2814630.00,0.00,2814630.00,309609.30,3124239.30,3124239.30,NULL,'2026-08-03 14:59:52','2026-08-03 16:34:37'),
(62,'PO/2608/00062',12,3,'2026-08-03','2026-08-03','received',1,11.00,955450.00,0.00,955450.00,105099.50,1060549.50,1060549.50,NULL,'2026-08-03 15:08:45','2026-08-03 15:09:33'),
(63,'PO/2608/00063',15,3,'2026-08-03','2026-08-03','received',0,11.00,4400000.00,0.00,4400000.00,0.00,4400000.00,4400000.00,NULL,'2026-08-03 15:12:17','2026-08-03 15:17:24'),
(64,'PO/2608/00064',21,3,'2026-08-03','2026-08-03','received',0,11.00,9600000.00,0.00,9600000.00,0.00,9600000.00,9600000.00,NULL,'2026-08-03 15:33:14','2026-08-03 15:33:35'),
(65,'PO/2608/00065',14,3,'2026-08-03','2026-08-03','received',0,11.00,539000.00,0.00,539000.00,0.00,539000.00,539000.00,NULL,'2026-08-03 16:28:14','2026-08-03 16:28:54'),
(66,'PO/2608/00066',21,4,'2026-08-03','2026-08-03','received',0,11.00,6400000.00,0.00,6400000.00,0.00,6400000.00,6400000.00,NULL,'2026-08-03 23:03:50','2026-08-03 23:04:15'),
(67,'PO/2608/00067',17,4,'2026-08-04','2026-08-04','received',1,11.00,8587500.00,0.00,8587500.00,944625.00,9532125.00,9532125.00,NULL,'2026-08-04 09:06:32','2026-08-04 16:12:41'),
(68,'PO/2608/00068',19,3,'2026-08-04','2026-08-04','received',0,11.00,1135000.00,0.00,1135000.00,0.00,1135000.00,1135000.00,NULL,'2026-08-04 12:38:45','2026-08-04 16:05:44'),
(69,'PO/2608/00069',28,3,'2026-08-04','2026-08-04','received',1,11.00,808111.00,0.00,808111.00,88892.21,897003.21,897003.21,NULL,'2026-08-04 12:57:14','2026-08-04 16:05:16'),
(70,'PO/2608/00070',27,3,'2026-08-04','2026-08-04','received',0,11.00,459000.00,0.00,459000.00,0.00,459000.00,459000.00,NULL,'2026-08-04 13:03:48','2026-08-04 13:04:38'),
(71,'PO/2608/00071',27,3,'2026-08-04','2026-08-04','received',0,11.00,40630.00,0.00,40630.00,0.00,40630.00,40630.00,NULL,'2026-08-04 15:39:19','2026-08-05 16:32:43'),
(72,'PO/2608/00072',19,3,'2026-08-04','2026-08-04','received',0,11.00,290000.00,0.00,290000.00,0.00,290000.00,290000.00,NULL,'2026-08-04 15:53:12','2026-08-05 09:35:52'),
(73,'PO/2608/00073',27,4,'2026-08-04','2026-08-04','received',0,11.00,1330771.00,0.00,1330771.00,0.00,1330771.00,1330771.00,NULL,'2026-08-04 16:40:41','2026-08-04 16:41:02'),
(74,'PO/2608/00074',22,4,'2026-08-04','2026-08-04','received',0,11.00,500.00,0.00,500.00,0.00,500.00,500.00,NULL,'2026-08-04 18:44:21','2026-08-05 16:32:56'),
(75,'PO/2608/00075',23,3,'2026-08-05','2026-08-05','received',0,11.00,318000.00,0.00,318000.00,0.00,318000.00,318000.00,NULL,'2026-08-05 11:09:18','2026-08-05 11:09:52'),
(76,'PO/2608/00076',15,3,'2026-08-05','2026-08-05','received',0,11.00,2.00,0.00,2.00,0.00,2.00,2.00,NULL,'2026-08-05 11:15:44','2026-08-05 11:16:05'),
(77,'PO/2608/00077',19,4,'2026-08-05','2026-08-05','received',0,11.00,300000.00,0.00,300000.00,0.00,300000.00,300000.00,NULL,'2026-08-05 13:47:32','2026-08-05 16:32:27'),
(78,'PO/2608/00078',28,3,'2026-08-05','2026-08-05','received',0,11.00,300000.00,0.00,300000.00,0.00,300000.00,0.00,NULL,'2026-08-05 14:28:46','2026-08-05 14:28:58'),
(79,'PO/2608/00079',22,3,'2026-08-05','2026-08-05','received',0,11.00,10000.00,0.00,10000.00,0.00,10000.00,10000.00,NULL,'2026-08-05 14:35:50','2026-08-05 16:32:03');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_items_quotation_id_foreign` (`quotation_id`),
  KEY `quotation_items_product_id_foreign` (`product_id`),
  CONSTRAINT `quotation_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `quotation_items_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
INSERT INTO `quotation_items` VALUES
(17,1,75,1.00,2200000.00,0.00,2200000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(18,1,53,1.00,4400000.00,0.00,4400000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(19,1,99,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(20,1,59,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(21,1,60,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(22,1,114,1.00,2200000.00,0.00,2200000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(23,1,116,1.00,4500000.00,0.00,4500000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(24,1,119,1.00,3500000.00,0.00,3500000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(25,1,115,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(26,1,117,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(27,1,118,1.00,4000000.00,0.00,4000000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(28,1,120,1.00,4400000.00,0.00,4400000.00,'2026-07-29 23:02:54','2026-07-29 23:02:54'),
(31,2,139,1.00,2800000.00,0.00,2800000.00,'2026-08-04 09:29:46','2026-08-04 09:29:46'),
(32,2,140,1.00,2800000.00,0.00,2800000.00,'2026-08-04 09:29:46','2026-08-04 09:29:46');
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `valid_until` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `terms` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `converted_sales_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotations_quotation_number_unique` (`quotation_number`),
  KEY `quotations_customer_id_foreign` (`customer_id`),
  KEY `quotations_user_id_foreign` (`user_id`),
  KEY `quotations_converted_sales_order_id_foreign` (`converted_sales_order_id`),
  CONSTRAINT `quotations_converted_sales_order_id_foreign` FOREIGN KEY (`converted_sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quotations_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `quotations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` VALUES
(1,'QT/2607/00001',10,4,'2026-07-29','2026-08-12','draft',1,11.00,45200000.00,0.00,45200000.00,4972000.00,50172000.00,'1. Harga belum termasuk PPN 11%\r\n2. Ready stok \r\n3. Harga per box isi 20 test\r\n4. Sistem cost per tes untuk pembayaran',NULL,NULL,'2026-07-29 22:52:47','2026-07-29 23:02:54'),
(2,'QT/2608/00002',47,4,'2026-08-04','2026-08-18','draft',1,11.00,5600000.00,0.00,5600000.00,616000.00,6216000.00,'1. Harga sudah termasuk PPN (bila dikenakan).\r\n2. Penawaran berlaku sampai tanggal yang tertera.\r\n3. Ready stok\r\n4. Disc 10%',NULL,NULL,'2026-08-04 09:18:42','2026-08-04 09:29:46');
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,1),
(1,2),
(2,1),
(2,2),
(3,1),
(3,2),
(4,1),
(5,1),
(5,2),
(6,1),
(6,2),
(7,1),
(7,2),
(8,1),
(9,1),
(9,2),
(10,1),
(10,2),
(11,1),
(11,2),
(12,1),
(13,1),
(13,2),
(14,1),
(14,2),
(15,1),
(15,2),
(16,1),
(17,1),
(17,2),
(18,1),
(18,2),
(19,1),
(19,2),
(20,1),
(21,1),
(21,2),
(22,1),
(22,2),
(23,1),
(23,2),
(24,1),
(25,1),
(25,2),
(26,1),
(26,2),
(27,1),
(27,2),
(28,1),
(29,1),
(29,2),
(30,1),
(30,2),
(31,1),
(31,2),
(32,1),
(33,1),
(33,2),
(34,1),
(34,2),
(35,1),
(36,1),
(37,1),
(37,2),
(38,1),
(38,2),
(39,1),
(39,2),
(40,1),
(41,1),
(41,2),
(42,1),
(43,1),
(44,1),
(45,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_items`
--

DROP TABLE IF EXISTS `sales_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount_reason` varchar(255) DEFAULT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_order_items_sales_order_id_foreign` (`sales_order_id`),
  KEY `sales_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sales_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `sales_order_items_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_items`
--

LOCK TABLES `sales_order_items` WRITE;
/*!40000 ALTER TABLE `sales_order_items` DISABLE KEYS */;
INSERT INTO `sales_order_items` VALUES
(1,1,41,2.00,1300000.00,0.00,NULL,2600000.00,'2026-07-14 11:21:06','2026-07-14 11:21:06'),
(2,2,53,1.00,2000000.00,0.00,NULL,2000000.00,'2026-07-14 12:29:01','2026-07-14 12:29:01'),
(3,3,71,1.00,3205779.00,0.00,NULL,3205779.00,'2026-07-15 10:56:52','2026-07-15 10:56:52'),
(4,3,67,1.00,1454468.00,0.00,NULL,1454468.00,'2026-07-15 10:56:52','2026-07-15 10:56:52'),
(5,4,78,1.00,11500000.00,0.00,NULL,11500000.00,'2026-07-15 15:29:15','2026-07-15 15:29:15'),
(6,5,79,1.00,320000.00,0.00,NULL,320000.00,'2026-07-15 16:13:40','2026-07-15 16:13:40'),
(7,5,63,3.00,105000.00,0.00,NULL,315000.00,'2026-07-15 16:13:40','2026-07-15 16:13:40'),
(8,6,54,1.00,550000.00,0.00,NULL,550000.00,'2026-07-16 09:26:10','2026-07-16 09:26:10'),
(9,7,58,1.00,530125.00,0.00,NULL,530125.00,'2026-07-16 10:22:21','2026-07-16 10:22:21'),
(10,8,75,1.00,900000.00,0.00,NULL,900000.00,'2026-07-16 11:55:34','2026-07-16 11:55:34'),
(11,9,58,5.00,584700.00,0.00,NULL,2923500.00,'2026-07-16 12:43:00','2026-07-16 12:43:00'),
(12,10,41,1.00,1000000.00,0.00,NULL,1000000.00,'2026-07-16 12:55:21','2026-07-16 12:55:21'),
(13,11,65,2.00,3759184.00,0.00,NULL,7518368.00,'2026-07-16 15:18:02','2026-07-16 15:18:02'),
(14,12,66,1.00,186030.00,0.00,NULL,186030.00,'2026-07-16 15:35:44','2026-07-16 15:35:44'),
(15,12,67,3.00,1454468.00,0.00,NULL,4363404.00,'2026-07-16 15:35:44','2026-07-16 15:35:44'),
(17,13,68,1.00,1916798.00,0.00,NULL,1916798.00,'2026-07-16 15:42:22','2026-07-16 15:42:22'),
(18,13,69,1.00,664196.00,0.00,NULL,664196.00,'2026-07-16 15:42:22','2026-07-16 15:42:22'),
(19,13,70,1.00,1360362.00,0.00,NULL,1360362.00,'2026-07-16 15:42:22','2026-07-16 15:42:22'),
(20,13,72,1.00,978931.00,0.00,NULL,978931.00,'2026-07-16 15:42:22','2026-07-16 15:42:22'),
(21,13,73,1.00,2305958.00,0.00,NULL,2305958.00,'2026-07-16 15:42:22','2026-07-16 15:42:22'),
(22,14,74,1.00,1943865.00,0.00,NULL,1943865.00,'2026-07-16 15:45:41','2026-07-16 15:45:41'),
(23,15,58,10.00,550000.00,0.00,NULL,5500000.00,'2026-07-16 16:19:36','2026-07-16 16:19:36'),
(24,15,55,1.00,650000.00,0.00,NULL,650000.00,'2026-07-16 16:19:36','2026-07-16 16:19:36'),
(25,15,54,1.00,360000.00,0.00,NULL,360000.00,'2026-07-16 16:19:36','2026-07-16 16:19:36'),
(26,16,57,2.00,571625.00,0.00,NULL,1143250.00,'2026-07-17 12:44:46','2026-07-17 12:44:46'),
(27,17,54,1.00,650000.00,0.00,NULL,650000.00,'2026-07-18 11:07:19','2026-07-18 11:07:19'),
(28,18,54,1.00,549000.00,0.00,NULL,549000.00,'2026-07-18 12:14:53','2026-07-18 12:14:53'),
(29,19,58,1.00,571000.00,0.00,NULL,571000.00,'2026-07-18 13:44:04','2026-07-18 13:44:04'),
(30,20,75,1.00,1000000.00,150000.00,NULL,850000.00,'2026-07-18 17:09:31','2026-07-18 17:09:31'),
(31,21,75,1.00,1000000.00,150000.00,NULL,850000.00,'2026-07-18 17:09:32','2026-07-18 17:09:32'),
(32,22,58,1.00,601250.00,0.00,NULL,601250.00,'2026-07-19 10:15:07','2026-07-19 10:15:07'),
(33,23,54,1.00,567500.00,0.00,NULL,567500.00,'2026-07-19 10:32:26','2026-07-19 10:32:26'),
(34,24,58,1.00,600000.00,0.00,NULL,600000.00,'2026-07-20 13:20:09','2026-07-20 13:20:09'),
(35,25,57,1.00,550000.00,0.00,NULL,550000.00,'2026-07-20 18:36:54','2026-07-20 18:36:54'),
(36,25,54,1.00,550000.00,0.00,NULL,550000.00,'2026-07-20 18:36:54','2026-07-20 18:36:54'),
(37,26,87,3.00,320000.00,0.00,NULL,960000.00,'2026-07-21 13:18:51','2026-07-21 13:18:51'),
(38,26,86,3.00,320000.00,0.00,NULL,960000.00,'2026-07-21 13:18:51','2026-07-21 13:18:51'),
(39,26,88,1.00,500000.00,0.00,NULL,500000.00,'2026-07-21 13:18:51','2026-07-21 13:18:51'),
(40,27,58,2.00,1225000.00,0.00,NULL,2450000.00,'2026-07-21 14:42:41','2026-07-21 14:42:41'),
(41,27,85,1.00,760000.00,0.00,NULL,760000.00,'2026-07-21 14:42:41','2026-07-21 14:42:41'),
(42,27,86,1.00,540000.00,0.00,NULL,540000.00,'2026-07-21 14:42:41','2026-07-21 14:42:41'),
(44,29,90,1.00,2293600.00,0.00,NULL,2293600.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(45,29,91,1.00,10125000.00,0.00,NULL,10125000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(46,29,92,1.00,2310000.00,0.00,NULL,2310000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(47,29,93,1.00,2848000.00,0.00,NULL,2848000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(48,29,82,4.00,2848000.00,0.00,NULL,11392000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(49,29,94,1.00,3003000.00,0.00,NULL,3003000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(50,29,83,1.00,2079000.00,0.00,NULL,2079000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(51,29,84,1.00,1617000.00,0.00,NULL,1617000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(52,29,95,1.00,1617000.00,0.00,NULL,1617000.00,'2026-07-21 15:49:13','2026-07-21 15:49:13'),
(53,30,80,1.00,1200000.00,0.00,NULL,1200000.00,'2026-07-21 15:58:26','2026-07-21 15:58:26'),
(54,30,96,1.00,380000.00,0.00,NULL,380000.00,'2026-07-21 15:58:26','2026-07-21 15:58:26'),
(55,28,89,5.00,3900000.00,0.00,NULL,19500000.00,'2026-07-21 16:11:46','2026-07-21 16:11:46'),
(56,31,58,1.00,647500.00,0.00,NULL,647500.00,'2026-07-22 14:09:40','2026-07-22 14:09:40'),
(57,31,60,1.00,1960000.00,0.00,NULL,1960000.00,'2026-07-22 14:09:40','2026-07-22 14:09:40'),
(60,33,97,1.00,500000.00,0.00,NULL,500000.00,'2026-07-23 10:12:58','2026-07-23 10:12:58'),
(61,33,98,1.00,275000.00,0.00,NULL,275000.00,'2026-07-23 10:12:58','2026-07-23 10:12:58'),
(62,34,58,5.00,650000.00,0.00,NULL,3250000.00,'2026-07-23 10:16:56','2026-07-23 10:16:56'),
(63,35,58,1.00,591600.00,0.00,NULL,591600.00,'2026-07-23 12:38:46','2026-07-23 12:38:46'),
(64,36,58,2.00,541000.00,0.00,NULL,1082000.00,'2026-07-23 15:01:05','2026-07-23 15:01:05'),
(65,37,56,2.00,750000.00,0.00,NULL,1500000.00,'2026-07-23 16:16:45','2026-07-23 16:16:45'),
(66,38,51,1.00,3400000.00,0.00,NULL,3400000.00,'2026-07-23 16:42:45','2026-07-23 16:42:45'),
(67,38,48,1.00,5830000.00,0.00,NULL,5830000.00,'2026-07-23 16:42:45','2026-07-23 16:42:45'),
(68,38,49,1.00,7767500.00,0.00,NULL,7767500.00,'2026-07-23 16:42:45','2026-07-23 16:42:45'),
(69,38,50,1.00,5635000.00,0.00,NULL,5635000.00,'2026-07-23 16:42:45','2026-07-23 16:42:45'),
(70,38,52,1.00,0.00,0.00,NULL,0.00,'2026-07-23 16:42:45','2026-07-23 16:42:45'),
(71,39,58,1.00,1500000.00,0.00,NULL,1500000.00,'2026-07-24 09:19:21','2026-07-24 09:19:21'),
(72,40,58,1.00,650000.00,0.00,NULL,650000.00,'2026-07-24 09:35:47','2026-07-24 09:35:47'),
(73,41,53,1.00,1919795.00,0.00,NULL,1919795.00,'2026-07-24 15:39:13','2026-07-24 15:39:13'),
(74,42,58,1.00,571000.00,0.00,NULL,571000.00,'2026-07-24 15:58:05','2026-07-24 15:58:05'),
(75,43,58,1.00,571000.00,0.00,NULL,571000.00,'2026-07-24 16:13:55','2026-07-24 16:13:55'),
(78,32,89,1.00,3900000.00,0.00,NULL,3900000.00,'2026-07-25 10:04:18','2026-07-25 10:04:18'),
(79,32,59,5.00,1260000.00,0.00,NULL,6300000.00,'2026-07-25 10:04:18','2026-07-25 10:04:18'),
(87,45,102,0.25,1556589.00,0.00,NULL,389147.25,'2026-07-25 11:21:20','2026-07-25 11:21:20'),
(88,45,103,0.50,1556589.00,0.00,NULL,778294.50,'2026-07-25 11:21:20','2026-07-25 11:21:20'),
(89,45,70,2.00,1360362.00,0.00,NULL,2720724.00,'2026-07-25 11:21:20','2026-07-25 11:21:20'),
(90,44,101,1.00,507104.00,0.00,NULL,507104.00,'2026-07-25 11:24:02','2026-07-25 11:24:02'),
(91,44,100,0.75,1839049.00,0.00,NULL,1379286.75,'2026-07-25 11:24:02','2026-07-25 11:24:02'),
(92,46,58,3.00,650000.00,0.00,NULL,1950000.00,'2026-07-25 11:44:46','2026-07-25 11:44:46'),
(93,46,55,3.00,750000.00,0.00,NULL,2250000.00,'2026-07-25 11:44:46','2026-07-25 11:44:46'),
(94,46,89,1.00,3800000.00,0.00,NULL,3800000.00,'2026-07-25 11:44:46','2026-07-25 11:44:46'),
(95,47,105,50.00,10000.00,0.00,NULL,500000.00,'2026-07-26 07:00:48','2026-07-26 07:00:48'),
(96,47,104,100.00,10000.00,0.00,NULL,1000000.00,'2026-07-26 07:00:48','2026-07-26 07:00:48'),
(97,48,54,1.00,700000.00,0.00,NULL,700000.00,'2026-07-27 12:30:28','2026-07-27 12:30:28'),
(98,49,89,1.00,3800000.00,0.00,NULL,3800000.00,'2026-07-27 12:33:59','2026-07-27 12:33:59'),
(99,50,68,1.00,1916798.00,0.00,NULL,1916798.00,'2026-07-27 14:05:30','2026-07-27 14:05:30'),
(100,50,66,2.00,186030.00,0.00,NULL,372060.00,'2026-07-27 14:05:30','2026-07-27 14:05:30'),
(101,51,57,1.00,571000.00,0.00,NULL,571000.00,'2026-07-27 15:24:36','2026-07-27 15:24:36'),
(102,52,86,3.00,320000.00,0.00,NULL,960000.00,'2026-07-27 18:19:02','2026-07-27 18:19:02'),
(103,52,87,3.00,320000.00,0.00,NULL,960000.00,'2026-07-27 18:19:02','2026-07-27 18:19:02'),
(104,53,89,1.00,4000000.00,0.00,NULL,4000000.00,'2026-07-28 10:21:48','2026-07-28 10:21:48'),
(105,54,111,1.00,500000.00,0.00,NULL,500000.00,'2026-07-28 10:30:00','2026-07-28 10:30:00'),
(106,54,108,1.00,250000.00,0.00,NULL,250000.00,'2026-07-28 10:30:00','2026-07-28 10:30:00'),
(107,55,113,1.00,3000000.00,0.00,NULL,3000000.00,'2026-07-29 09:07:25','2026-07-29 09:07:25'),
(108,55,109,1.00,3000000.00,0.00,NULL,3000000.00,'2026-07-29 09:07:25','2026-07-29 09:07:25'),
(109,55,110,1.00,3000000.00,0.00,NULL,3000000.00,'2026-07-29 09:07:25','2026-07-29 09:07:25'),
(110,56,121,5.00,82000.00,0.00,NULL,410000.00,'2026-07-30 14:06:35','2026-07-30 14:06:35'),
(111,56,122,5.00,162000.00,0.00,NULL,810000.00,'2026-07-30 14:06:35','2026-07-30 14:06:35'),
(112,56,123,5.00,102000.00,0.00,NULL,510000.00,'2026-07-30 14:06:35','2026-07-30 14:06:35'),
(113,56,124,2.00,600000.00,0.00,NULL,1200000.00,'2026-07-30 14:06:35','2026-07-30 14:06:35'),
(123,58,125,1.00,720000.00,144000.00,NULL,576000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(124,58,126,1.00,500000.00,100000.00,NULL,400000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(125,58,107,1.00,550000.00,110000.00,NULL,440000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(126,58,106,1.00,440000.00,88000.00,NULL,352000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(127,58,87,1.00,440000.00,88000.00,NULL,352000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(128,58,127,1.00,310000.00,62000.00,NULL,248000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(129,58,128,1.00,500000.00,100000.00,NULL,400000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(130,58,86,1.00,390000.00,78000.00,NULL,312000.00,'2026-07-31 10:47:04','2026-07-31 10:47:04'),
(131,57,125,1.00,720000.00,144000.00,NULL,576000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(132,57,126,1.00,500000.00,100000.00,NULL,400000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(133,57,107,1.00,550000.00,110000.00,NULL,440000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(134,57,106,1.00,440000.00,88000.00,NULL,352000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(135,57,87,1.00,440000.00,88000.00,NULL,352000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(136,57,127,1.00,310000.00,62000.00,NULL,248000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(137,57,128,1.00,500000.00,100000.00,NULL,400000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(138,57,86,1.00,390000.00,78000.00,NULL,312000.00,'2026-07-31 10:53:35','2026-07-31 10:53:35'),
(139,59,56,2.00,700000.00,0.00,NULL,1400000.00,'2026-07-31 14:14:20','2026-07-31 14:14:20'),
(140,59,54,2.00,366300.00,0.00,NULL,732600.00,'2026-07-31 14:14:20','2026-07-31 14:14:20'),
(141,59,55,1.00,700000.00,0.00,NULL,700000.00,'2026-07-31 14:14:20','2026-07-31 14:14:20'),
(145,60,61,1.00,0.00,0.00,NULL,0.00,'2026-07-31 22:24:30','2026-07-31 22:24:30'),
(146,60,62,1.00,0.00,0.00,NULL,0.00,'2026-07-31 22:24:30','2026-07-31 22:24:30'),
(147,60,75,1.00,0.00,0.00,NULL,0.00,'2026-07-31 22:24:30','2026-07-31 22:24:30'),
(148,61,61,1.00,1500000.00,0.00,NULL,1500000.00,'2026-07-31 22:29:36','2026-07-31 22:29:36'),
(149,61,62,1.00,1200000.00,0.00,NULL,1200000.00,'2026-07-31 22:29:36','2026-07-31 22:29:36'),
(150,61,75,1.00,1110000.00,0.00,NULL,1110000.00,'2026-07-31 22:29:36','2026-07-31 22:29:36'),
(151,62,129,103.00,17500.00,0.00,NULL,1802500.00,'2026-08-03 09:01:42','2026-08-03 09:01:42'),
(152,63,129,157.00,25000.00,0.00,NULL,3925000.00,'2026-08-03 09:04:54','2026-08-03 09:04:54'),
(153,64,129,296.00,20000.00,0.00,NULL,5920000.00,'2026-08-03 09:08:18','2026-08-03 09:08:18'),
(154,65,129,100.00,18000.00,0.00,NULL,1800000.00,'2026-08-03 09:13:32','2026-08-03 09:13:32'),
(155,65,130,84.00,12000.00,0.00,NULL,1008000.00,'2026-08-03 09:13:32','2026-08-03 09:13:32'),
(156,66,58,1.00,0.00,0.00,NULL,0.00,'2026-08-03 09:20:39','2026-08-03 09:20:39'),
(157,66,54,1.00,0.00,0.00,NULL,0.00,'2026-08-03 09:20:39','2026-08-03 09:20:39'),
(158,67,57,1.00,0.00,0.00,NULL,0.00,'2026-08-03 09:21:34','2026-08-03 09:21:34'),
(159,67,54,1.00,0.00,0.00,NULL,0.00,'2026-08-03 09:21:34','2026-08-03 09:21:34'),
(165,70,57,1.00,567500.00,0.00,NULL,567500.00,'2026-08-03 13:44:07','2026-08-03 13:44:07'),
(166,71,125,1.00,720000.00,0.00,NULL,720000.00,'2026-08-03 14:23:05','2026-08-03 14:23:05'),
(167,71,128,1.00,500000.00,0.00,NULL,500000.00,'2026-08-03 14:23:05','2026-08-03 14:23:05'),
(178,72,58,1.00,1225000.00,0.00,NULL,1225000.00,'2026-08-03 14:36:59','2026-08-03 14:36:59'),
(179,72,56,1.00,1225000.00,0.00,NULL,1225000.00,'2026-08-03 14:36:59','2026-08-03 14:36:59'),
(180,72,134,2.00,250000.00,0.00,NULL,500000.00,'2026-08-03 14:36:59','2026-08-03 14:36:59'),
(181,72,127,1.00,420000.00,0.00,NULL,420000.00,'2026-08-03 14:36:59','2026-08-03 14:36:59'),
(184,74,75,1.00,1000000.00,150000.00,NULL,850000.00,'2026-08-03 15:20:59','2026-08-03 15:20:59'),
(185,73,58,1.00,625000.00,0.00,NULL,625000.00,'2026-08-03 16:21:55','2026-08-03 16:21:55'),
(186,73,134,2.00,50000.00,0.00,NULL,100000.00,'2026-08-03 16:21:55','2026-08-03 16:21:55'),
(188,75,89,1.00,4180000.00,0.00,NULL,4180000.00,'2026-08-03 16:26:16','2026-08-03 16:26:16'),
(189,75,137,1.00,750000.00,0.00,NULL,750000.00,'2026-08-03 16:26:16','2026-08-03 16:26:16'),
(190,76,58,1.00,650000.00,0.00,NULL,650000.00,'2026-08-04 09:20:40','2026-08-04 09:20:40'),
(191,77,54,1.00,500000.00,0.00,NULL,500000.00,'2026-08-04 09:57:12','2026-08-04 09:57:12'),
(192,78,153,1.00,750000.00,0.00,NULL,750000.00,'2026-08-04 13:09:44','2026-08-04 13:09:44'),
(193,79,67,2.00,1454468.00,0.00,NULL,2908936.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(194,79,71,1.00,3205779.00,0.00,NULL,3205779.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(195,79,136,1.00,1689428.00,0.00,NULL,1689428.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(196,79,73,1.00,2305958.00,0.00,NULL,2305958.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(197,79,135,1.00,1164675.00,0.00,NULL,1164675.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(198,79,102,1.00,1556589.00,0.00,NULL,1556589.00,'2026-08-04 13:19:14','2026-08-04 13:19:14'),
(199,80,57,1.00,567500.00,0.00,NULL,567500.00,'2026-08-04 15:11:51','2026-08-04 15:11:51'),
(200,80,54,1.00,567500.00,0.00,NULL,567500.00,'2026-08-04 15:11:51','2026-08-04 15:11:51'),
(201,80,112,1.00,161250.00,0.00,NULL,161250.00,'2026-08-04 15:11:51','2026-08-04 15:11:51'),
(202,80,58,1.00,567500.00,0.00,NULL,567500.00,'2026-08-04 15:11:51','2026-08-04 15:11:51'),
(203,80,56,1.00,650000.00,0.00,NULL,650000.00,'2026-08-04 15:11:51','2026-08-04 15:11:51'),
(214,82,129,31.00,18000.00,0.00,NULL,558000.00,'2026-08-04 18:46:47','2026-08-04 18:46:47'),
(215,83,57,2.00,420000.00,0.00,NULL,840000.00,'2026-08-04 19:45:20','2026-08-04 19:45:20'),
(216,83,58,2.00,650000.00,0.00,NULL,1300000.00,'2026-08-04 19:45:20','2026-08-04 19:45:20'),
(217,83,54,1.00,430000.00,0.00,NULL,430000.00,'2026-08-04 19:45:20','2026-08-04 19:45:20'),
(218,84,63,3.00,75000.00,0.00,NULL,225000.00,'2026-08-05 09:32:09','2026-08-05 09:32:09'),
(219,84,64,2.00,75000.00,0.00,NULL,150000.00,'2026-08-05 09:32:09','2026-08-05 09:32:09'),
(220,81,89,1.00,3900000.00,0.00,NULL,3900000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(221,81,154,1.00,95000.00,0.00,NULL,95000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(222,81,98,3.00,275000.00,0.00,NULL,825000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(223,81,150,2.00,28800.00,0.00,NULL,57600.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(224,81,63,5.00,120000.00,0.00,NULL,600000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(225,81,141,2.00,200000.00,0.00,NULL,400000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(226,81,64,1.00,150000.00,0.00,NULL,150000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(227,81,151,2.00,30000.00,0.00,NULL,60000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(228,81,142,1.00,210000.00,0.00,NULL,210000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(229,81,149,1.00,110000.00,0.00,NULL,110000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(230,81,156,1.00,400000.00,0.00,NULL,400000.00,'2026-08-05 11:10:55','2026-08-05 11:10:55'),
(233,86,81,1.00,650000.00,0.00,NULL,650000.00,'2026-08-05 12:19:28','2026-08-05 12:19:28'),
(234,87,81,1.00,525000.00,0.00,NULL,525000.00,'2026-08-05 12:22:55','2026-08-05 12:22:55'),
(235,87,128,1.00,279100.00,0.00,NULL,279100.00,'2026-08-05 12:22:55','2026-08-05 12:22:55'),
(236,88,84,2.00,1617000.00,0.00,NULL,3234000.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(237,88,95,1.00,1617000.00,0.00,NULL,1617000.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(238,88,113,2.00,3000000.00,0.00,NULL,6000000.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(239,88,92,2.00,2310000.00,0.00,NULL,4620000.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(240,88,90,2.00,2293600.00,0.00,NULL,4587200.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(241,88,83,2.00,2079000.00,0.00,NULL,4158000.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(242,88,138,1.00,0.00,0.00,NULL,0.00,'2026-08-05 12:36:24','2026-08-05 12:36:24'),
(243,89,81,1.00,600000.00,0.00,NULL,600000.00,'2026-08-05 13:02:01','2026-08-05 13:02:01'),
(244,90,58,1.00,650000.00,0.00,NULL,650000.00,'2026-08-05 13:24:41','2026-08-05 13:24:41'),
(245,90,56,1.00,750000.00,0.00,NULL,750000.00,'2026-08-05 13:24:41','2026-08-05 13:24:41'),
(248,85,57,2.00,550000.00,0.00,NULL,1100000.00,'2026-08-05 13:35:50','2026-08-05 13:35:50'),
(249,85,54,5.00,500000.00,0.00,NULL,2500000.00,'2026-08-05 13:35:50','2026-08-05 13:35:50'),
(277,91,145,1.00,60000.00,0.00,NULL,60000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(278,91,146,1.00,40000.00,0.00,NULL,40000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(279,91,147,1.00,1600000.00,0.00,NULL,1600000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(280,91,148,1.00,60000.00,0.00,NULL,60000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(281,91,150,1.00,50000.00,0.00,NULL,50000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(282,91,128,1.00,740000.00,0.00,NULL,740000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(283,91,155,1.00,1800000.00,0.00,NULL,1800000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(284,91,144,1.00,20000.00,0.00,NULL,20000.00,'2026-08-05 14:33:18','2026-08-05 14:33:18'),
(285,92,131,1.00,3375549.00,0.00,NULL,3375549.00,'2026-08-05 14:48:34','2026-08-05 14:48:34'),
(286,92,67,2.00,1454468.00,0.00,NULL,2908936.00,'2026-08-05 14:48:34','2026-08-05 14:48:34'),
(287,93,126,1.00,382550.00,0.00,NULL,382550.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(288,93,127,1.00,300000.00,0.00,NULL,300000.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(289,93,89,1.00,0.00,0.00,NULL,0.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(290,93,81,1.00,561000.00,0.00,NULL,561000.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(291,93,90,1.00,0.00,0.00,NULL,0.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(292,93,41,1.00,0.00,0.00,NULL,0.00,'2026-08-05 16:29:25','2026-08-05 16:29:25'),
(293,93,143,2.00,0.00,0.00,NULL,0.00,'2026-08-05 16:29:25','2026-08-05 16:29:25');
/*!40000 ALTER TABLE `sales_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_orders`
--

DROP TABLE IF EXISTS `sales_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `so_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock_deducted` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_orders_so_number_unique` (`so_number`),
  KEY `sales_orders_customer_id_foreign` (`customer_id`),
  KEY `sales_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `sales_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_orders`
--

LOCK TABLES `sales_orders` WRITE;
/*!40000 ALTER TABLE `sales_orders` DISABLE KEYS */;
INSERT INTO `sales_orders` VALUES
(1,'SO/2607/00001',11,3,'2026-07-14','2026-07-14','completed',0,11.00,2600000.00,0.00,2600000.00,0.00,2600000.00,1,NULL,'2026-07-14 11:21:06','2026-07-14 11:22:05'),
(2,'SO/2607/00002',13,3,'2026-07-14','2026-08-13','completed',0,11.00,2000000.00,0.00,2000000.00,0.00,2000000.00,1,NULL,'2026-07-14 12:29:01','2026-07-14 12:29:30'),
(3,'SO/2607/00003',6,3,'2026-07-15','2026-08-14','completed',1,11.00,4660247.00,0.00,4660247.00,512627.17,5172874.17,1,NULL,'2026-07-15 10:56:52','2026-07-15 10:59:22'),
(4,'SO/2607/00004',14,3,'2026-07-15','2026-07-15','completed',0,11.00,11500000.00,0.00,11500000.00,0.00,11500000.00,1,NULL,'2026-07-15 15:29:15','2026-07-15 15:29:28'),
(5,'SO/2607/00005',13,3,'2026-07-15','2026-08-14','completed',0,11.00,635000.00,0.00,635000.00,0.00,635000.00,1,NULL,'2026-07-15 16:13:40','2026-07-15 16:13:58'),
(6,'SO/2607/00006',15,4,'2026-07-16','2026-07-16','completed',0,11.00,550000.00,0.00,550000.00,0.00,550000.00,1,NULL,'2026-07-16 09:26:10','2026-07-16 09:26:33'),
(7,'SO/2607/00007',16,4,'2026-07-16','2026-07-16','completed',0,11.00,530125.00,0.00,530125.00,0.00,530125.00,1,NULL,'2026-07-16 10:22:21','2026-07-16 10:22:48'),
(8,'SO/2607/00008',17,4,'2026-07-16','2026-07-16','completed',0,11.00,900000.00,0.00,900000.00,0.00,900000.00,1,NULL,'2026-07-16 11:55:34','2026-07-16 11:55:48'),
(9,'SO/2607/00009',18,3,'2026-07-16','2026-07-16','completed',0,11.00,2923500.00,0.00,2923500.00,0.00,2923500.00,1,NULL,'2026-07-16 12:43:00','2026-07-16 12:58:32'),
(10,'SO/2607/00010',17,3,'2026-07-16','2026-07-16','completed',0,11.00,1000000.00,0.00,1000000.00,0.00,1000000.00,1,NULL,'2026-07-16 12:55:21','2026-07-16 12:55:39'),
(11,'SO/2607/00011',6,3,'2026-07-16','2026-08-15','completed',1,11.00,7518368.00,0.00,7518368.00,827020.48,8345388.48,1,NULL,'2026-07-16 15:18:02','2026-07-16 15:32:21'),
(12,'SO/2607/00012',6,3,'2026-07-16','2026-08-15','completed',1,11.00,4549434.00,0.00,4549434.00,500437.74,5049871.74,1,NULL,'2026-07-16 15:35:44','2026-07-16 15:36:31'),
(13,'SO/2607/00013',6,3,'2026-07-16','2026-08-15','completed',1,11.00,7226245.00,0.00,7226245.00,794886.95,8021131.95,1,NULL,'2026-07-16 15:39:44','2026-07-16 15:42:48'),
(14,'SO/2607/00014',6,3,'2026-07-16','2026-08-15','completed',1,11.00,1943865.00,0.00,1943865.00,213825.15,2157690.15,1,NULL,'2026-07-16 15:45:40','2026-07-16 15:45:49'),
(15,'SO/2607/00015',19,4,'2026-07-16','2026-07-16','completed',0,11.00,6510000.00,0.00,6510000.00,0.00,6510000.00,1,NULL,'2026-07-16 16:19:36','2026-07-16 16:19:56'),
(16,'SO/2607/00016',20,4,'2026-07-17','2026-07-17','completed',0,11.00,1143250.00,0.00,1143250.00,0.00,1143250.00,1,NULL,'2026-07-17 12:44:46','2026-07-17 12:44:59'),
(17,'SO/2607/00017',21,4,'2026-07-18','2026-07-18','completed',0,11.00,650000.00,0.00,650000.00,0.00,650000.00,1,NULL,'2026-07-18 11:07:19','2026-07-18 11:07:35'),
(18,'SO/2607/00018',22,4,'2026-07-15','2026-07-15','completed',0,11.00,549000.00,0.00,549000.00,0.00,549000.00,1,NULL,'2026-07-18 12:14:53','2026-07-18 12:15:30'),
(19,'SO/2607/00019',23,4,'2026-07-17','2026-07-17','completed',0,11.00,571000.00,0.00,571000.00,0.00,571000.00,1,NULL,'2026-07-18 13:44:04','2026-07-18 13:44:19'),
(20,'SO/2607/00020',24,4,'2026-07-18','2026-07-18','cancelled',1,11.00,850000.00,0.00,850000.00,93500.00,943500.00,0,NULL,'2026-07-18 17:09:31','2026-07-19 10:11:02'),
(21,'SO/2607/00021',24,4,'2026-07-18','2026-07-18','completed',1,11.00,850000.00,0.00,850000.00,93500.00,943500.00,1,NULL,'2026-07-18 17:09:32','2026-07-18 17:09:53'),
(22,'SO/2607/00022',25,4,'2026-07-19','2026-07-19','completed',0,11.00,601250.00,0.00,601250.00,0.00,601250.00,1,NULL,'2026-07-19 10:15:07','2026-07-19 10:15:18'),
(23,'SO/2607/00023',17,4,'2026-07-19','2026-07-19','completed',0,11.00,567500.00,0.00,567500.00,0.00,567500.00,1,NULL,'2026-07-19 10:32:26','2026-07-19 10:32:46'),
(24,'SO/2607/00024',26,3,'2026-07-20','2026-07-20','completed',0,11.00,600000.00,0.00,600000.00,0.00,600000.00,1,NULL,'2026-07-20 13:20:09','2026-07-20 13:20:22'),
(25,'SO/2607/00025',15,4,'2026-07-20','2026-07-21','completed',0,11.00,1100000.00,0.00,1100000.00,0.00,1100000.00,1,NULL,'2026-07-20 18:36:54','2026-07-20 18:37:09'),
(26,'SO/2607/00026',28,3,'2026-07-21','2026-07-21','completed',0,11.00,2420000.00,0.00,2420000.00,0.00,2420000.00,1,NULL,'2026-07-21 13:18:51','2026-07-21 13:23:05'),
(27,'SO/2607/00027',29,3,'2026-07-21','2026-08-20','completed',1,11.00,3750000.00,0.00,3750000.00,412500.00,4162500.00,1,NULL,'2026-07-21 14:42:41','2026-07-21 14:43:10'),
(28,'SO/2607/00028',30,3,'2026-07-21','2026-07-21','completed',1,11.00,19500000.00,0.00,19500000.00,2145000.00,21645000.00,1,NULL,'2026-07-21 14:54:18','2026-07-21 16:11:46'),
(29,'SO/2607/00029',10,3,'2026-07-21','2026-08-20','completed',1,11.00,37284600.00,0.00,37284600.00,4101306.00,41385906.00,1,NULL,'2026-07-21 15:49:13','2026-07-21 15:49:48'),
(30,'SO/2607/00030',13,3,'2026-07-21','2026-08-20','completed',0,11.00,1580000.00,0.00,1580000.00,0.00,1580000.00,1,NULL,'2026-07-21 15:58:26','2026-07-21 15:58:38'),
(31,'SO/2607/00031',21,4,'2026-07-22','2026-07-22','completed',0,11.00,2607500.00,0.00,2607500.00,0.00,2607500.00,1,NULL,'2026-07-22 14:09:40','2026-07-22 14:09:54'),
(32,'SO/2607/00032',8,4,'2026-07-23','2026-07-23','completed',1,11.00,10200000.00,0.00,10200000.00,1122000.00,11322000.00,1,NULL,'2026-07-23 09:28:17','2026-07-25 10:04:18'),
(33,'SO/2607/00033',9,4,'2026-07-23','2026-08-22','completed',1,11.00,775000.00,0.00,775000.00,85250.00,860250.00,1,NULL,'2026-07-23 10:12:58','2026-07-23 11:00:04'),
(34,'SO/2607/00034',15,4,'2026-07-23','2026-07-23','completed',0,11.00,3250000.00,0.00,3250000.00,0.00,3250000.00,1,NULL,'2026-07-23 10:16:56','2026-07-23 10:17:10'),
(35,'SO/2607/00035',7,4,'2026-07-23','2026-07-23','completed',1,11.00,591600.00,0.00,591600.00,65076.00,656676.00,1,NULL,'2026-07-23 12:38:46','2026-07-23 12:38:54'),
(36,'SO/2607/00036',31,4,'2026-07-23','2026-07-24','completed',0,11.00,1082000.00,0.00,1082000.00,0.00,1082000.00,1,NULL,'2026-07-23 15:01:05','2026-07-23 15:01:13'),
(37,'SO/2607/00037',32,3,'2026-07-23','2026-07-24','completed',0,11.00,1500000.00,0.00,1500000.00,0.00,1500000.00,1,NULL,'2026-07-23 16:16:45','2026-07-23 16:16:57'),
(38,'SO/2607/00038',10,3,'2026-07-23','2026-08-22','completed',1,11.00,22632500.00,0.00,22632500.00,2489575.00,25122075.00,1,NULL,'2026-07-23 16:42:45','2026-07-23 16:43:28'),
(39,'SO/2607/00039',33,4,'2026-07-24','2026-07-24','completed',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,1,NULL,'2026-07-24 09:19:21','2026-07-24 09:19:31'),
(40,'SO/2607/00040',34,4,'2026-07-24','2026-07-24','completed',0,11.00,650000.00,0.00,650000.00,0.00,650000.00,1,NULL,'2026-07-24 09:35:47','2026-07-24 09:35:59'),
(41,'SO/2607/00041',31,4,'2026-07-24','2026-07-25','completed',0,11.00,1919795.00,0.00,1919795.00,0.00,1919795.00,1,NULL,'2026-07-24 15:39:13','2026-07-24 15:39:23'),
(42,'SO/2607/00042',35,3,'2026-07-24','2026-07-24','completed',0,11.00,571000.00,0.00,571000.00,0.00,571000.00,1,NULL,'2026-07-24 15:58:05','2026-07-24 15:58:12'),
(43,'SO/2607/00043',36,3,'2026-07-24','2026-07-24','completed',0,11.00,571000.00,0.00,571000.00,0.00,571000.00,1,NULL,'2026-07-24 16:13:55','2026-07-24 16:14:08'),
(44,'SO/2607/00044',6,4,'2026-07-25','2026-08-24','completed',1,11.00,1886390.75,0.00,1886390.75,207502.98,2093893.73,1,NULL,'2026-07-25 11:06:17','2026-07-25 11:24:02'),
(45,'SO/2607/00045',6,4,'2026-07-25','2026-08-24','completed',1,11.00,3888165.75,0.00,3888165.75,427698.23,4315863.98,1,NULL,'2026-07-25 11:20:47','2026-07-25 11:21:37'),
(46,'SO/2607/00046',24,3,'2026-07-25','2026-07-25','completed',0,11.00,8000000.00,0.00,8000000.00,0.00,8000000.00,1,NULL,'2026-07-25 11:44:46','2026-07-25 11:44:58'),
(47,'SO/2607/00047',37,4,'2026-07-26','2026-07-26','completed',1,11.00,1500000.00,0.00,1500000.00,165000.00,1665000.00,1,NULL,'2026-07-26 07:00:48','2026-07-26 07:00:58'),
(48,'SO/2607/00048',38,4,'2026-07-27','2026-07-27','completed',0,11.00,700000.00,0.00,700000.00,0.00,700000.00,1,NULL,'2026-07-27 12:30:28','2026-07-27 12:30:38'),
(49,'SO/2607/00049',24,4,'2026-07-27','2026-07-27','completed',0,11.00,3800000.00,0.00,3800000.00,0.00,3800000.00,1,NULL,'2026-07-27 12:33:59','2026-07-27 12:34:07'),
(50,'SO/2607/00050',6,3,'2026-07-27','2026-08-26','completed',1,11.00,2288858.00,0.00,2288858.00,251774.38,2540632.38,1,NULL,'2026-07-27 14:05:30','2026-07-27 14:05:39'),
(51,'SO/2607/00051',39,3,'2026-07-27','2026-07-27','completed',0,11.00,571000.00,0.00,571000.00,0.00,571000.00,1,NULL,'2026-07-27 15:24:36','2026-07-27 15:24:44'),
(52,'SO/2607/00052',28,4,'2026-07-27','2026-07-27','completed',0,11.00,1920000.00,0.00,1920000.00,0.00,1920000.00,1,NULL,'2026-07-27 18:19:02','2026-07-28 10:25:43'),
(53,'SO/2607/00053',40,4,'2026-07-28','2026-07-28','completed',0,11.00,4000000.00,0.00,4000000.00,0.00,4000000.00,1,NULL,'2026-07-28 10:21:48','2026-07-28 10:21:58'),
(54,'SO/2607/00054',26,4,'2026-07-28','2026-07-28','completed',0,11.00,750000.00,0.00,750000.00,0.00,750000.00,1,NULL,'2026-07-28 10:30:00','2026-07-28 10:30:14'),
(55,'SO/2607/00055',10,4,'2026-07-29','2026-08-28','completed',1,11.00,9000000.00,0.00,9000000.00,990000.00,9990000.00,1,NULL,'2026-07-29 09:07:25','2026-07-29 09:07:32'),
(56,'SO/2607/00056',41,3,'2026-07-30','2026-07-30','completed',1,11.00,2930000.00,0.00,2930000.00,322300.00,3252300.00,1,NULL,'2026-07-30 14:06:35','2026-07-30 14:06:54'),
(57,'SO/2607/00057',40,4,'2026-07-31','2026-07-31','completed',0,11.00,3080000.00,0.00,3080000.00,0.00,3080000.00,1,NULL,'2026-07-31 10:04:50','2026-07-31 10:53:35'),
(58,'SO/2607/00058',42,4,'2026-07-31','2026-07-31','cancelled',0,11.00,3080000.00,0.00,3080000.00,0.00,3080000.00,0,NULL,'2026-07-31 10:47:04','2026-07-31 10:48:48'),
(59,'SO/2607/00059',19,4,'2026-07-31','2026-07-31','completed',0,11.00,2832600.00,0.00,2832600.00,0.00,2832600.00,1,NULL,'2026-07-31 14:14:20','2026-07-31 14:15:03'),
(60,'SO/2607/00060',13,4,'2026-07-31','2026-07-31','completed',0,11.00,0.00,0.00,0.00,0.00,0.00,1,NULL,'2026-07-31 21:54:42','2026-07-31 22:24:30'),
(61,'SO/2607/00061',13,4,'2026-07-31','2026-08-30','completed',0,11.00,3810000.00,0.00,3810000.00,0.00,3810000.00,1,NULL,'2026-07-31 22:29:36','2026-07-31 22:30:02'),
(62,'SO/2608/00062',44,4,'2026-08-03','2026-08-03','completed',1,11.00,1802500.00,0.00,1802500.00,198275.00,2000775.00,1,NULL,'2026-08-03 09:01:42','2026-08-03 09:01:53'),
(63,'SO/2608/00063',45,4,'2026-08-03','2026-08-03','completed',1,11.00,3925000.00,0.00,3925000.00,431750.00,4356750.00,1,NULL,'2026-08-03 09:04:54','2026-08-03 09:05:06'),
(64,'SO/2608/00064',8,4,'2026-08-03','2026-08-03','completed',1,11.00,5920000.00,0.00,5920000.00,651200.00,6571200.00,1,NULL,'2026-08-03 09:08:18','2026-08-03 09:08:34'),
(65,'SO/2608/00065',43,4,'2026-08-03','2026-08-03','completed',0,11.00,2808000.00,0.00,2808000.00,0.00,2808000.00,1,NULL,'2026-08-03 09:13:32','2026-08-03 09:13:47'),
(66,'SO/2608/00066',45,4,'2026-08-03','2026-08-03','completed',0,11.00,0.00,0.00,0.00,0.00,0.00,1,NULL,'2026-08-03 09:20:39','2026-08-03 09:20:48'),
(67,'SO/2608/00067',43,4,'2026-08-03','2026-08-03','completed',0,11.00,0.00,0.00,0.00,0.00,0.00,1,NULL,'2026-08-03 09:21:34','2026-08-03 09:21:49'),
(70,'SO/2608/00070',35,3,'2026-08-03','2026-08-03','completed',0,11.00,567500.00,0.00,567500.00,0.00,567500.00,1,NULL,'2026-08-03 13:44:07','2026-08-04 16:17:57'),
(71,'SO/2608/00071',46,3,'2026-08-03','2026-09-02','confirmed',0,11.00,1220000.00,0.00,1220000.00,0.00,1220000.00,1,NULL,'2026-08-03 14:23:05','2026-08-03 14:23:39'),
(72,'SO/2608/00072',29,3,'2026-08-03','2026-08-17','confirmed',1,11.00,3370000.00,0.00,3370000.00,370700.00,3740700.00,1,NULL,'2026-08-03 14:34:28','2026-08-03 14:37:22'),
(73,'SO/2608/00073',31,3,'2026-08-03','2026-08-03','completed',0,11.00,725000.00,0.00,725000.00,0.00,725000.00,1,NULL,'2026-08-03 14:49:56','2026-08-03 16:22:35'),
(74,'SO/2608/00074',24,3,'2026-08-03','2026-08-03','completed',1,11.00,850000.00,0.00,850000.00,93500.00,943500.00,1,NULL,'2026-08-03 15:20:59','2026-08-03 16:22:15'),
(75,'SO/2608/00075',13,3,'2026-08-03','2026-09-02','confirmed',0,11.00,4930000.00,0.00,4930000.00,0.00,4930000.00,1,NULL,'2026-08-03 16:25:12','2026-08-03 16:29:03'),
(76,'SO/2608/00076',32,4,'2026-08-04','2026-08-04','completed',0,11.00,650000.00,0.00,650000.00,0.00,650000.00,1,NULL,'2026-08-04 09:20:40','2026-08-04 15:05:15'),
(77,'SO/2608/00077',48,4,'2026-08-04','2026-08-04','completed',0,11.00,500000.00,0.00,500000.00,0.00,500000.00,1,NULL,'2026-08-04 09:57:12','2026-08-04 12:33:04'),
(78,'SO/2608/00078',13,3,'2026-08-04','2026-09-03','confirmed',0,11.00,750000.00,0.00,750000.00,0.00,750000.00,1,NULL,'2026-08-04 13:09:44','2026-08-04 13:09:49'),
(79,'SO/2608/00079',6,3,'2026-08-04','2026-09-03','confirmed',1,11.00,12831365.00,0.00,12831365.00,1411450.15,14242815.15,1,NULL,'2026-08-04 13:19:14','2026-08-04 13:19:20'),
(80,'SO/2608/00080',35,3,'2026-08-04','2026-08-04','confirmed',0,11.00,2513750.00,0.00,2513750.00,0.00,2513750.00,1,NULL,'2026-08-04 15:11:51','2026-08-04 15:11:57'),
(81,'SO/2608/00081',9,3,'2026-08-04','2026-09-03','confirmed',1,11.00,6807600.00,0.00,6807600.00,748836.00,7556436.00,1,NULL,'2026-08-04 15:48:37','2026-08-05 11:16:57'),
(82,'SO/2608/00082',49,4,'2026-08-04','2026-08-04','completed',0,11.00,558000.00,0.00,558000.00,0.00,558000.00,1,NULL,'2026-08-04 18:46:47','2026-08-05 09:30:23'),
(83,'SO/2608/00083',50,4,'2026-08-04','2026-08-04','completed',0,11.00,2570000.00,0.00,2570000.00,0.00,2570000.00,1,NULL,'2026-08-04 19:45:20','2026-08-05 09:30:03'),
(84,'SO/2608/00084',48,4,'2026-08-05','2026-08-05','completed',0,11.00,375000.00,0.00,375000.00,0.00,375000.00,1,NULL,'2026-08-05 09:32:09','2026-08-05 12:16:11'),
(85,'SO/2608/00085',15,3,'2026-08-05','2026-08-05','completed',0,11.00,3600000.00,0.00,3600000.00,0.00,3600000.00,1,NULL,'2026-08-05 12:13:57','2026-08-05 15:58:17'),
(86,'SO/2608/00086',52,3,'2026-08-05','2026-08-05','completed',0,11.00,650000.00,0.00,650000.00,0.00,650000.00,1,NULL,'2026-08-05 12:19:28','2026-08-05 12:19:44'),
(87,'SO/2608/00087',35,3,'2026-08-05','2026-08-05','confirmed',0,11.00,804100.00,0.00,804100.00,0.00,804100.00,1,NULL,'2026-08-05 12:22:55','2026-08-05 12:22:59'),
(88,'SO/2608/00088',10,3,'2026-08-05','2026-09-04','confirmed',1,11.00,24216200.00,0.00,24216200.00,2663782.00,26879982.00,1,NULL,'2026-08-05 12:36:24','2026-08-05 12:36:48'),
(89,'SO/2608/00089',53,3,'2026-08-05','2026-08-05','completed',0,11.00,600000.00,0.00,600000.00,0.00,600000.00,1,NULL,'2026-08-05 13:02:01','2026-08-05 13:33:01'),
(90,'SO/2608/00090',54,3,'2026-08-05','2026-08-05','completed',0,11.00,1400000.00,0.00,1400000.00,0.00,1400000.00,1,NULL,'2026-08-05 13:24:41','2026-08-05 13:33:16'),
(91,'SO/2608/00091',29,3,'2026-08-05','2026-08-19','confirmed',1,11.00,4370000.00,0.00,4370000.00,480700.00,4850700.00,1,NULL,'2026-08-05 14:15:37','2026-08-05 14:36:13'),
(92,'SO/2608/00092',6,3,'2026-08-05','2026-09-03','confirmed',1,11.00,6284485.00,0.00,6284485.00,691293.35,6975778.35,1,NULL,'2026-08-05 14:48:34','2026-08-05 14:48:52'),
(93,'SO/2608/00093',55,3,'2026-08-05','2026-08-05','completed',0,11.00,1243550.00,0.00,1243550.00,0.00,1243550.00,1,NULL,'2026-08-05 16:29:25','2026-08-05 16:31:47');
/*!40000 ALTER TABLE `sales_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('8T52REiLBstwrXATo4VBnc3N7u9KHx0gGMKnCfzf',3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiU0p6YWFZaGtXN2dhQlRZRUhKczVsa2t5dHVrSFlPRTdhdld5Y2xlUSI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MztzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MDoiaHR0cDovL2RsbS5tZWR6LWVhc3kuY29tL3B1cmNoYXNlLW9yZGVycyI7czo1OiJyb3V0ZSI7czoyMToicHVyY2hhc2Utb3JkZXJzLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1785922378),
('yrVEowXHCkzEE8aNYikj5he2ca8DfNTcyLxTOdie',4,'127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYWM5Q09vakhWd3ZHOUlSS3IwWU83T3JQbkJjMjFFNlR2dVJoenF2aCI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozNDoiaHR0cDovL2RsbS5tZWR6LWVhc3kuY29tL2Rhc2hib2FyZCI7czo1OiJyb3V0ZSI7czo5OiJkYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1785924750);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'company_name','PT DIMAS LOVE MEDIKA','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'company_npwp','1000 0000 0468 5165','2026-07-10 20:33:43','2026-07-13 12:14:50'),
(3,'company_nib','0108250170791','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'company_izin','01082501707910001','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'company_kbli','46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'company_address','Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'company_phone','021-38939414 / 0859-3319-1346','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'company_email','anggihdimas@gmail.com','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'company_pjt','Nia Love Fiana Puteri (D.III Farmasi)','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'ppn_rate','11','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'fp_transaction_code','04','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'fp_prefix','','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'fp_last_serial','11','2026-07-10 20:52:07','2026-07-10 20:52:08'),
(14,'fp_serial_year','26','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(35,'bank_name','Bank BCA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(36,'bank_account_no','8011111629','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(37,'bank_account_holder','PT DIMAS LOVE MEDIKA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(38,'director_name','M Anggih Dimas W','2026-07-13 12:13:43','2026-07-13 12:13:43');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('in','out','adjustment') NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `balance_after` decimal(18,2) NOT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `moved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_warehouse_id_foreign` (`warehouse_id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  KEY `stock_movements_product_id_moved_at_index` (`product_id`,`moved_at`),
  CONSTRAINT `stock_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=406 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES
(1,41,1,'in',2.00,4.00,'Penerimaan PO PO/2607/00001',1,'GR GR/2607/00001',3,'2026-07-14 11:17:28','2026-07-14 11:17:28','2026-07-14 11:17:28'),
(2,41,1,'out',-2.00,2.00,'Sales Order SO/2607/00001',1,'Penjualan SO SO/2607/00001',3,'2026-07-14 11:21:52','2026-07-14 11:21:52','2026-07-14 11:21:52'),
(3,53,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00003',2,'GR GR/2607/00002',3,'2026-07-14 12:23:51','2026-07-14 12:23:51','2026-07-14 12:23:51'),
(4,53,1,'out',-1.00,0.00,'Sales Order SO/2607/00002',2,'Penjualan SO SO/2607/00002',3,'2026-07-14 12:29:14','2026-07-14 12:29:14','2026-07-14 12:29:14'),
(5,58,1,'in',29.00,29.00,'Penerimaan PO PO/2607/00004',3,'GR GR/2607/00003',3,'2026-07-14 13:19:52','2026-07-14 13:19:52','2026-07-14 13:19:52'),
(6,55,1,'in',6.00,6.00,'Penerimaan PO PO/2607/00004',3,'GR GR/2607/00003',3,'2026-07-14 13:19:52','2026-07-14 13:19:52','2026-07-14 13:19:52'),
(7,57,1,'in',21.00,21.00,'Penerimaan PO PO/2607/00005',4,'GR GR/2607/00004',3,'2026-07-14 13:29:39','2026-07-14 13:29:39','2026-07-14 13:29:39'),
(8,54,1,'in',28.00,28.00,'Penerimaan PO PO/2607/00005',4,'GR GR/2607/00004',3,'2026-07-14 13:29:39','2026-07-14 13:29:39','2026-07-14 13:29:39'),
(9,63,1,'in',12.00,12.00,'Penerimaan PO PO/2607/00006',5,'GR GR/2607/00005',3,'2026-07-14 13:40:20','2026-07-14 13:40:20','2026-07-14 13:40:20'),
(10,64,1,'in',4.00,4.00,'Penerimaan PO PO/2607/00006',5,'GR GR/2607/00005',3,'2026-07-14 13:40:21','2026-07-14 13:40:21','2026-07-14 13:40:21'),
(11,61,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00007',6,'GR GR/2607/00006',3,'2026-07-14 13:45:32','2026-07-14 13:45:32','2026-07-14 13:45:32'),
(12,62,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00007',6,'GR GR/2607/00006',3,'2026-07-14 13:45:32','2026-07-14 13:45:32','2026-07-14 13:45:32'),
(13,59,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00008',7,'GR GR/2607/00007',3,'2026-07-14 13:54:44','2026-07-14 13:54:44','2026-07-14 13:54:44'),
(14,60,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00008',7,'GR GR/2607/00007',3,'2026-07-14 13:54:44','2026-07-14 13:54:44','2026-07-14 13:54:44'),
(15,69,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(16,71,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(17,67,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00010',8,'GR GR/2607/00008',3,'2026-07-14 14:59:13','2026-07-14 14:59:13','2026-07-14 14:59:13'),
(18,75,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00011',9,'GR GR/2607/00009',3,'2026-07-14 15:59:02','2026-07-14 15:59:02','2026-07-14 15:59:02'),
(19,71,1,'out',-1.00,0.00,'Sales Order SO/2607/00003',3,'Penjualan SO SO/2607/00003',3,'2026-07-15 10:59:13','2026-07-15 10:59:13','2026-07-15 10:59:13'),
(20,67,1,'out',-1.00,0.00,'Sales Order SO/2607/00003',3,'Penjualan SO SO/2607/00003',3,'2026-07-15 10:59:13','2026-07-15 10:59:13','2026-07-15 10:59:13'),
(21,78,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00013',10,'GR GR/2607/00010',3,'2026-07-15 15:28:14','2026-07-15 15:28:14','2026-07-15 15:28:14'),
(22,78,1,'out',-1.00,0.00,'Sales Order SO/2607/00004',4,'Penjualan SO SO/2607/00004',3,'2026-07-15 15:29:21','2026-07-15 15:29:21','2026-07-15 15:29:21'),
(23,79,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00014',11,'GR GR/2607/00011',3,'2026-07-15 16:09:25','2026-07-15 16:09:25','2026-07-15 16:09:25'),
(24,79,1,'out',-1.00,0.00,'Sales Order SO/2607/00005',5,'Penjualan SO SO/2607/00005',3,'2026-07-15 16:13:50','2026-07-15 16:13:50','2026-07-15 16:13:50'),
(25,63,1,'out',-3.00,9.00,'Sales Order SO/2607/00005',5,'Penjualan SO SO/2607/00005',3,'2026-07-15 16:13:50','2026-07-15 16:13:50','2026-07-15 16:13:50'),
(26,54,1,'out',-1.00,27.00,'Sales Order SO/2607/00006',6,'Penjualan SO SO/2607/00006',4,'2026-07-16 09:26:22','2026-07-16 09:26:22','2026-07-16 09:26:22'),
(27,58,1,'out',-1.00,28.00,'Sales Order SO/2607/00007',7,'Penjualan SO SO/2607/00007',4,'2026-07-16 10:22:40','2026-07-16 10:22:40','2026-07-16 10:22:40'),
(28,75,1,'out',-1.00,1.00,'Sales Order SO/2607/00008',8,'Penjualan SO SO/2607/00008',4,'2026-07-16 11:55:44','2026-07-16 11:55:44','2026-07-16 11:55:44'),
(29,58,1,'out',-5.00,23.00,'Sales Order SO/2607/00009',9,'Penjualan SO SO/2607/00009',3,'2026-07-16 12:43:19','2026-07-16 12:43:19','2026-07-16 12:43:19'),
(30,41,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00015',12,'GR GR/2607/00012',3,'2026-07-16 12:51:44','2026-07-16 12:51:44','2026-07-16 12:51:44'),
(31,41,1,'out',-1.00,2.00,'Sales Order SO/2607/00010',10,'Penjualan SO SO/2607/00010',3,'2026-07-16 12:55:25','2026-07-16 12:55:25','2026-07-16 12:55:25'),
(32,73,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00016',13,'GR GR/2607/00013',3,'2026-07-16 15:13:27','2026-07-16 15:13:27','2026-07-16 15:13:27'),
(33,67,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00016',13,'GR GR/2607/00013',3,'2026-07-16 15:13:27','2026-07-16 15:13:27','2026-07-16 15:13:27'),
(34,74,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(35,68,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(36,70,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(37,66,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(38,72,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(39,73,1,'in',1.00,2.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(40,67,1,'in',3.00,4.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(41,65,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00009',14,'GR GR/2607/00014',3,'2026-07-16 15:26:00','2026-07-16 15:26:00','2026-07-16 15:26:00'),
(42,65,1,'out',-2.00,0.00,'Sales Order SO/2607/00011',11,'Penjualan SO SO/2607/00011',3,'2026-07-16 15:31:59','2026-07-16 15:31:59','2026-07-16 15:31:59'),
(43,66,1,'out',-1.00,0.00,'Sales Order SO/2607/00012',12,'Penjualan SO SO/2607/00012',3,'2026-07-16 15:35:50','2026-07-16 15:35:50','2026-07-16 15:35:50'),
(44,67,1,'out',-3.00,1.00,'Sales Order SO/2607/00012',12,'Penjualan SO SO/2607/00012',3,'2026-07-16 15:35:50','2026-07-16 15:35:50','2026-07-16 15:35:50'),
(45,68,1,'out',-1.00,0.00,'Sales Order SO/2607/00013',13,'Penjualan SO SO/2607/00013',3,'2026-07-16 15:42:36','2026-07-16 15:42:36','2026-07-16 15:42:36'),
(46,69,1,'out',-1.00,0.00,'Sales Order SO/2607/00013',13,'Penjualan SO SO/2607/00013',3,'2026-07-16 15:42:36','2026-07-16 15:42:36','2026-07-16 15:42:36'),
(47,70,1,'out',-1.00,0.00,'Sales Order SO/2607/00013',13,'Penjualan SO SO/2607/00013',3,'2026-07-16 15:42:36','2026-07-16 15:42:36','2026-07-16 15:42:36'),
(48,72,1,'out',-1.00,0.00,'Sales Order SO/2607/00013',13,'Penjualan SO SO/2607/00013',3,'2026-07-16 15:42:36','2026-07-16 15:42:36','2026-07-16 15:42:36'),
(49,73,1,'out',-1.00,1.00,'Sales Order SO/2607/00013',13,'Penjualan SO SO/2607/00013',3,'2026-07-16 15:42:36','2026-07-16 15:42:36','2026-07-16 15:42:36'),
(50,74,1,'out',-1.00,0.00,'Sales Order SO/2607/00014',14,'Penjualan SO SO/2607/00014',3,'2026-07-16 15:45:44','2026-07-16 15:45:44','2026-07-16 15:45:44'),
(51,58,1,'out',-10.00,13.00,'Sales Order SO/2607/00015',15,'Penjualan SO SO/2607/00015',4,'2026-07-16 16:19:47','2026-07-16 16:19:47','2026-07-16 16:19:47'),
(52,55,1,'out',-1.00,5.00,'Sales Order SO/2607/00015',15,'Penjualan SO SO/2607/00015',4,'2026-07-16 16:19:47','2026-07-16 16:19:47','2026-07-16 16:19:47'),
(53,54,1,'out',-1.00,26.00,'Sales Order SO/2607/00015',15,'Penjualan SO SO/2607/00015',4,'2026-07-16 16:19:47','2026-07-16 16:19:47','2026-07-16 16:19:47'),
(54,57,1,'out',-2.00,19.00,'Sales Order SO/2607/00016',16,'Penjualan SO SO/2607/00016',4,'2026-07-17 12:44:54','2026-07-17 12:44:54','2026-07-17 12:44:54'),
(55,54,1,'out',-1.00,25.00,'Sales Order SO/2607/00017',17,'Penjualan SO SO/2607/00017',4,'2026-07-18 11:07:28','2026-07-18 11:07:28','2026-07-18 11:07:28'),
(56,54,1,'out',-1.00,24.00,'Sales Order SO/2607/00018',18,'Penjualan SO SO/2607/00018',4,'2026-07-18 12:15:01','2026-07-18 12:15:01','2026-07-18 12:15:01'),
(57,58,1,'out',-1.00,12.00,'Sales Order SO/2607/00019',19,'Penjualan SO SO/2607/00019',4,'2026-07-18 13:44:09','2026-07-18 13:44:09','2026-07-18 13:44:09'),
(58,75,1,'out',-1.00,0.00,'Sales Order SO/2607/00021',21,'Penjualan SO SO/2607/00021',4,'2026-07-18 17:09:42','2026-07-18 17:09:42','2026-07-18 17:09:42'),
(59,58,1,'out',-1.00,11.00,'Sales Order SO/2607/00022',22,'Penjualan SO SO/2607/00022',4,'2026-07-19 10:15:12','2026-07-19 10:15:12','2026-07-19 10:15:12'),
(60,54,1,'out',-1.00,23.00,'Sales Order SO/2607/00023',23,'Penjualan SO SO/2607/00023',4,'2026-07-19 10:32:40','2026-07-19 10:32:40','2026-07-19 10:32:40'),
(61,58,1,'out',-1.00,10.00,'Sales Order SO/2607/00024',24,'Penjualan SO SO/2607/00024',3,'2026-07-20 13:20:15','2026-07-20 13:20:15','2026-07-20 13:20:15'),
(62,57,1,'out',-1.00,18.00,'Sales Order SO/2607/00025',25,'Penjualan SO SO/2607/00025',4,'2026-07-20 18:37:01','2026-07-20 18:37:01','2026-07-20 18:37:01'),
(63,54,1,'out',-1.00,22.00,'Sales Order SO/2607/00025',25,'Penjualan SO SO/2607/00025',4,'2026-07-20 18:37:01','2026-07-20 18:37:01','2026-07-20 18:37:01'),
(64,86,1,'in',4.00,4.00,'Penerimaan PO PO/2607/00022',15,'GR GR/2607/00015',3,'2026-07-21 13:19:51','2026-07-21 13:19:51','2026-07-21 13:19:51'),
(65,85,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00022',15,'GR GR/2607/00015',3,'2026-07-21 13:19:51','2026-07-21 13:19:51','2026-07-21 13:19:51'),
(66,87,1,'in',3.00,3.00,'Penerimaan PO PO/2607/00022',15,'GR GR/2607/00015',3,'2026-07-21 13:19:51','2026-07-21 13:19:51','2026-07-21 13:19:51'),
(67,88,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00022',15,'GR GR/2607/00015',3,'2026-07-21 13:19:51','2026-07-21 13:19:51','2026-07-21 13:19:51'),
(68,87,1,'out',-3.00,0.00,'Sales Order SO/2607/00026',26,'Penjualan SO SO/2607/00026',3,'2026-07-21 13:22:55','2026-07-21 13:22:55','2026-07-21 13:22:55'),
(69,86,1,'out',-3.00,1.00,'Sales Order SO/2607/00026',26,'Penjualan SO SO/2607/00026',3,'2026-07-21 13:22:55','2026-07-21 13:22:55','2026-07-21 13:22:55'),
(70,88,1,'out',-1.00,0.00,'Sales Order SO/2607/00026',26,'Penjualan SO SO/2607/00026',3,'2026-07-21 13:22:55','2026-07-21 13:22:55','2026-07-21 13:22:55'),
(71,58,1,'in',25.00,35.00,'Penerimaan PO PO/2607/00019',16,'GR GR/2607/00016',4,'2026-07-21 13:34:17','2026-07-21 13:34:17','2026-07-21 13:34:17'),
(72,56,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00019',16,'GR GR/2607/00016',4,'2026-07-21 13:34:17','2026-07-21 13:34:17','2026-07-21 13:34:17'),
(73,82,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00020',17,'GR GR/2607/00017',3,'2026-07-21 13:39:41','2026-07-21 13:39:41','2026-07-21 13:39:41'),
(74,83,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00020',17,'GR GR/2607/00017',3,'2026-07-21 13:39:42','2026-07-21 13:39:42','2026-07-21 13:39:42'),
(75,58,1,'out',-2.00,33.00,'Sales Order SO/2607/00027',27,'Penjualan SO SO/2607/00027',3,'2026-07-21 14:43:03','2026-07-21 14:43:03','2026-07-21 14:43:03'),
(76,85,1,'out',-1.00,0.00,'Sales Order SO/2607/00027',27,'Penjualan SO SO/2607/00027',3,'2026-07-21 14:43:03','2026-07-21 14:43:03','2026-07-21 14:43:03'),
(77,86,1,'out',-1.00,0.00,'Sales Order SO/2607/00027',27,'Penjualan SO SO/2607/00027',3,'2026-07-21 14:43:03','2026-07-21 14:43:03','2026-07-21 14:43:03'),
(78,89,1,'in',4.00,4.00,'Penerimaan PO PO/2607/00023',18,'GR GR/2607/00018',3,'2026-07-21 14:50:52','2026-07-21 14:50:52','2026-07-21 14:50:52'),
(79,89,1,'out',-4.00,0.00,'Sales Order SO/2607/00028',28,'Penjualan SO SO/2607/00028',3,'2026-07-21 14:54:22','2026-07-21 14:54:22','2026-07-21 14:54:22'),
(80,84,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00021',19,'GR GR/2607/00019',3,'2026-07-21 15:22:44','2026-07-21 15:22:44','2026-07-21 15:22:44'),
(81,82,1,'in',2.00,3.00,'Penerimaan PO PO/2607/00021',19,'GR GR/2607/00019',3,'2026-07-21 15:22:44','2026-07-21 15:22:44','2026-07-21 15:22:44'),
(82,90,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(83,91,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(84,92,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(85,93,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(86,95,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(87,82,1,'in',1.00,4.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(88,94,1,'in',3.00,3.00,'Penerimaan PO PO/2607/00024',20,'GR GR/2607/00020',3,'2026-07-21 15:39:13','2026-07-21 15:39:13','2026-07-21 15:39:13'),
(89,90,1,'out',-1.00,1.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(90,91,1,'out',-1.00,1.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(91,92,1,'out',-1.00,0.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(92,93,1,'out',-1.00,0.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(93,82,1,'out',-4.00,0.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(94,94,1,'out',-1.00,2.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(95,83,1,'out',-1.00,0.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(96,84,1,'out',-1.00,0.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(97,95,1,'out',-1.00,1.00,'Sales Order SO/2607/00029',29,'Penjualan SO SO/2607/00029',3,'2026-07-21 15:49:28','2026-07-21 15:49:28','2026-07-21 15:49:28'),
(98,96,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00025',21,'GR GR/2607/00021',3,'2026-07-21 15:55:37','2026-07-21 15:55:37','2026-07-21 15:55:37'),
(99,80,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00018',22,'GR GR/2607/00022',3,'2026-07-21 15:57:05','2026-07-21 15:57:05','2026-07-21 15:57:05'),
(100,80,1,'out',-1.00,0.00,'Sales Order SO/2607/00030',30,'Penjualan SO SO/2607/00030',3,'2026-07-21 15:58:32','2026-07-21 15:58:32','2026-07-21 15:58:32'),
(101,96,1,'out',-1.00,0.00,'Sales Order SO/2607/00030',30,'Penjualan SO SO/2607/00030',3,'2026-07-21 15:58:32','2026-07-21 15:58:32','2026-07-21 15:58:32'),
(102,58,1,'out',-1.00,32.00,'Sales Order SO/2607/00031',31,'Penjualan SO SO/2607/00031',4,'2026-07-22 14:09:46','2026-07-22 14:09:46','2026-07-22 14:09:46'),
(103,60,1,'out',-1.00,0.00,'Sales Order SO/2607/00031',31,'Penjualan SO SO/2607/00031',4,'2026-07-22 14:09:46','2026-07-22 14:09:46','2026-07-22 14:09:46'),
(104,89,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00026',23,'GR GR/2607/00023',4,'2026-07-23 09:19:25','2026-07-23 09:19:25','2026-07-23 09:19:25'),
(105,89,1,'out',-1.00,0.00,'Sales Order SO/2607/00032',32,'Penjualan SO SO/2607/00032',4,'2026-07-23 09:28:23','2026-07-23 09:28:23','2026-07-23 09:28:23'),
(106,59,1,'out',-5.00,0.00,'Sales Order SO/2607/00032',32,'Penjualan SO SO/2607/00032',4,'2026-07-23 09:28:23','2026-07-23 09:28:23','2026-07-23 09:28:23'),
(107,58,1,'out',-5.00,27.00,'Sales Order SO/2607/00034',34,'Penjualan SO SO/2607/00034',4,'2026-07-23 10:17:06','2026-07-23 10:17:06','2026-07-23 10:17:06'),
(108,98,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00029',24,'GR GR/2607/00024',4,'2026-07-23 10:59:45','2026-07-23 10:59:45','2026-07-23 10:59:45'),
(109,97,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00029',24,'GR GR/2607/00024',4,'2026-07-23 10:59:45','2026-07-23 10:59:45','2026-07-23 10:59:45'),
(110,86,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00029',24,'GR GR/2607/00024',4,'2026-07-23 10:59:45','2026-07-23 10:59:45','2026-07-23 10:59:45'),
(111,96,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00029',24,'GR GR/2607/00024',4,'2026-07-23 10:59:45','2026-07-23 10:59:45','2026-07-23 10:59:45'),
(112,97,1,'out',-1.00,0.00,'Sales Order SO/2607/00033',33,'Penjualan SO SO/2607/00033',4,'2026-07-23 11:00:00','2026-07-23 11:00:00','2026-07-23 11:00:00'),
(113,98,1,'out',-1.00,0.00,'Sales Order SO/2607/00033',33,'Penjualan SO SO/2607/00033',4,'2026-07-23 11:00:00','2026-07-23 11:00:00','2026-07-23 11:00:00'),
(114,58,1,'out',-1.00,26.00,'Sales Order SO/2607/00035',35,'Penjualan SO SO/2607/00035',4,'2026-07-23 12:38:50','2026-07-23 12:38:50','2026-07-23 12:38:50'),
(115,89,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00028',25,'GR GR/2607/00025',4,'2026-07-23 14:56:19','2026-07-23 14:56:19','2026-07-23 14:56:19'),
(116,58,1,'out',-2.00,24.00,'Sales Order SO/2607/00036',36,'Penjualan SO SO/2607/00036',4,'2026-07-23 15:01:09','2026-07-23 15:01:09','2026-07-23 15:01:09'),
(117,56,1,'out',-2.00,3.00,'Sales Order SO/2607/00037',37,'Penjualan SO SO/2607/00037',3,'2026-07-23 16:16:50','2026-07-23 16:16:50','2026-07-23 16:16:50'),
(118,56,1,'in',2.00,5.00,'Penerimaan PO PO/2607/00030',26,'GR GR/2607/00026',3,'2026-07-23 16:20:19','2026-07-23 16:20:19','2026-07-23 16:20:19'),
(119,99,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00031',27,'GR GR/2607/00027',3,'2026-07-23 16:24:24','2026-07-23 16:24:24','2026-07-23 16:24:24'),
(120,48,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00032',28,'GR GR/2607/00028',3,'2026-07-23 16:34:51','2026-07-23 16:34:51','2026-07-23 16:34:51'),
(121,52,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00032',28,'GR GR/2607/00028',3,'2026-07-23 16:34:51','2026-07-23 16:34:51','2026-07-23 16:34:51'),
(122,49,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00032',28,'GR GR/2607/00028',3,'2026-07-23 16:34:51','2026-07-23 16:34:51','2026-07-23 16:34:51'),
(123,50,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00032',28,'GR GR/2607/00028',3,'2026-07-23 16:34:51','2026-07-23 16:34:51','2026-07-23 16:34:51'),
(124,51,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00032',28,'GR GR/2607/00028',3,'2026-07-23 16:34:51','2026-07-23 16:34:51','2026-07-23 16:34:51'),
(125,51,1,'out',-1.00,0.00,'Sales Order SO/2607/00038',38,'Penjualan SO SO/2607/00038',3,'2026-07-23 16:43:13','2026-07-23 16:43:13','2026-07-23 16:43:13'),
(126,48,1,'out',-1.00,0.00,'Sales Order SO/2607/00038',38,'Penjualan SO SO/2607/00038',3,'2026-07-23 16:43:13','2026-07-23 16:43:13','2026-07-23 16:43:13'),
(127,49,1,'out',-1.00,1.00,'Sales Order SO/2607/00038',38,'Penjualan SO SO/2607/00038',3,'2026-07-23 16:43:13','2026-07-23 16:43:13','2026-07-23 16:43:13'),
(128,50,1,'out',-1.00,0.00,'Sales Order SO/2607/00038',38,'Penjualan SO SO/2607/00038',3,'2026-07-23 16:43:13','2026-07-23 16:43:13','2026-07-23 16:43:13'),
(129,52,1,'out',-1.00,0.00,'Sales Order SO/2607/00038',38,'Penjualan SO SO/2607/00038',3,'2026-07-23 16:43:13','2026-07-23 16:43:13','2026-07-23 16:43:13'),
(130,58,1,'out',-1.00,23.00,'Sales Order SO/2607/00039',39,'Penjualan SO SO/2607/00039',4,'2026-07-24 09:19:27','2026-07-24 09:19:27','2026-07-24 09:19:27'),
(131,58,1,'out',-1.00,22.00,'Sales Order SO/2607/00040',40,'Penjualan SO SO/2607/00040',4,'2026-07-24 09:35:56','2026-07-24 09:35:56','2026-07-24 09:35:56'),
(132,53,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00027',29,'GR GR/2607/00029',3,'2026-07-24 15:33:33','2026-07-24 15:33:33','2026-07-24 15:33:33'),
(133,75,1,'in',3.00,3.00,'Penerimaan PO PO/2607/00027',29,'GR GR/2607/00029',3,'2026-07-24 15:33:33','2026-07-24 15:33:33','2026-07-24 15:33:33'),
(134,59,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00027',29,'GR GR/2607/00029',3,'2026-07-24 15:33:33','2026-07-24 15:33:33','2026-07-24 15:33:33'),
(135,53,1,'out',-1.00,1.00,'Sales Order SO/2607/00041',41,'Penjualan SO SO/2607/00041',4,'2026-07-24 15:39:20','2026-07-24 15:39:20','2026-07-24 15:39:20'),
(136,58,1,'out',-1.00,21.00,'Sales Order SO/2607/00042',42,'Penjualan SO SO/2607/00042',3,'2026-07-24 15:58:09','2026-07-24 15:58:09','2026-07-24 15:58:09'),
(137,58,1,'out',-1.00,20.00,'Sales Order SO/2607/00043',43,'Penjualan SO SO/2607/00043',3,'2026-07-24 16:14:04','2026-07-24 16:14:04','2026-07-24 16:14:04'),
(138,100,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00034',30,'GR GR/2607/00030',4,'2026-07-25 11:04:21','2026-07-25 11:04:21','2026-07-25 11:04:21'),
(139,101,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00034',30,'GR GR/2607/00030',4,'2026-07-25 11:04:21','2026-07-25 11:04:21','2026-07-25 11:04:21'),
(140,101,1,'out',-1.00,0.00,'Sales Order SO/2607/00044',44,'Penjualan SO SO/2607/00044',4,'2026-07-25 11:07:58','2026-07-25 11:07:58','2026-07-25 11:07:58'),
(141,100,1,'out',-1.00,0.00,'Sales Order SO/2607/00044',44,'Penjualan SO SO/2607/00044',4,'2026-07-25 11:07:58','2026-07-25 11:07:58','2026-07-25 11:07:58'),
(142,102,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00035',31,'GR GR/2607/00031',4,'2026-07-25 11:16:29','2026-07-25 11:16:29','2026-07-25 11:16:29'),
(143,103,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00035',31,'GR GR/2607/00031',4,'2026-07-25 11:16:29','2026-07-25 11:16:29','2026-07-25 11:16:29'),
(144,70,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00035',31,'GR GR/2607/00031',4,'2026-07-25 11:16:29','2026-07-25 11:16:29','2026-07-25 11:16:29'),
(145,102,1,'out',-0.25,0.75,'Sales Order SO/2607/00045',45,'Penjualan SO SO/2607/00045',4,'2026-07-25 11:21:29','2026-07-25 11:21:29','2026-07-25 11:21:29'),
(146,103,1,'out',-0.50,0.50,'Sales Order SO/2607/00045',45,'Penjualan SO SO/2607/00045',4,'2026-07-25 11:21:29','2026-07-25 11:21:29','2026-07-25 11:21:29'),
(147,70,1,'out',-2.00,0.00,'Sales Order SO/2607/00045',45,'Penjualan SO SO/2607/00045',4,'2026-07-25 11:21:29','2026-07-25 11:21:29','2026-07-25 11:21:29'),
(148,89,1,'in',2.00,3.00,'Penerimaan PO PO/2607/00036',32,'GR GR/2607/00032',3,'2026-07-25 11:42:01','2026-07-25 11:42:01','2026-07-25 11:42:01'),
(149,58,1,'out',-3.00,17.00,'Sales Order SO/2607/00046',46,'Penjualan SO SO/2607/00046',3,'2026-07-25 11:44:50','2026-07-25 11:44:50','2026-07-25 11:44:50'),
(150,55,1,'out',-3.00,2.00,'Sales Order SO/2607/00046',46,'Penjualan SO SO/2607/00046',3,'2026-07-25 11:44:50','2026-07-25 11:44:50','2026-07-25 11:44:50'),
(151,89,1,'out',-1.00,2.00,'Sales Order SO/2607/00046',46,'Penjualan SO SO/2607/00046',3,'2026-07-25 11:44:50','2026-07-25 11:44:50','2026-07-25 11:44:50'),
(152,105,1,'in',50.00,50.00,'Penerimaan PO PO/2607/00037',33,'GR GR/2607/00033',4,'2026-07-26 06:56:54','2026-07-26 06:56:54','2026-07-26 06:56:54'),
(153,104,1,'in',100.00,100.00,'Penerimaan PO PO/2607/00037',33,'GR GR/2607/00033',4,'2026-07-26 06:56:54','2026-07-26 06:56:54','2026-07-26 06:56:54'),
(154,105,1,'out',-50.00,0.00,'Sales Order SO/2607/00047',47,'Penjualan SO SO/2607/00047',4,'2026-07-26 07:00:53','2026-07-26 07:00:53','2026-07-26 07:00:53'),
(155,104,1,'out',-100.00,0.00,'Sales Order SO/2607/00047',47,'Penjualan SO SO/2607/00047',4,'2026-07-26 07:00:53','2026-07-26 07:00:53','2026-07-26 07:00:53'),
(156,54,1,'out',-1.00,21.00,'Sales Order SO/2607/00048',48,'Penjualan SO SO/2607/00048',4,'2026-07-27 12:30:33','2026-07-27 12:30:33','2026-07-27 12:30:33'),
(157,89,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00038',34,'GR GR/2607/00034',4,'2026-07-27 12:33:08','2026-07-27 12:33:08','2026-07-27 12:33:08'),
(158,89,1,'out',-1.00,2.00,'Sales Order SO/2607/00049',49,'Penjualan SO SO/2607/00049',4,'2026-07-27 12:34:02','2026-07-27 12:34:02','2026-07-27 12:34:02'),
(159,68,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00033',35,'GR GR/2607/00035',3,'2026-07-27 13:59:10','2026-07-27 13:59:10','2026-07-27 13:59:10'),
(160,66,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00033',35,'GR GR/2607/00035',3,'2026-07-27 13:59:10','2026-07-27 13:59:10','2026-07-27 13:59:10'),
(161,68,1,'out',-1.00,0.00,'Sales Order SO/2607/00050',50,'Penjualan SO SO/2607/00050',3,'2026-07-27 14:05:35','2026-07-27 14:05:35','2026-07-27 14:05:35'),
(162,66,1,'out',-2.00,0.00,'Sales Order SO/2607/00050',50,'Penjualan SO SO/2607/00050',3,'2026-07-27 14:05:35','2026-07-27 14:05:35','2026-07-27 14:05:35'),
(163,57,1,'out',-1.00,17.00,'Sales Order SO/2607/00051',51,'Penjualan SO SO/2607/00051',3,'2026-07-27 15:24:40','2026-07-27 15:24:40','2026-07-27 15:24:40'),
(164,89,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00041',36,'GR GR/2607/00036',4,'2026-07-28 10:19:01','2026-07-28 10:19:01','2026-07-28 10:19:01'),
(165,89,1,'out',-1.00,2.00,'Sales Order SO/2607/00053',53,'Penjualan SO SO/2607/00053',4,'2026-07-28 10:21:54','2026-07-28 10:21:54','2026-07-28 10:21:54'),
(166,108,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00039',37,'GR GR/2607/00037',4,'2026-07-28 10:25:15','2026-07-28 10:25:15','2026-07-28 10:25:15'),
(167,106,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00039',37,'GR GR/2607/00037',4,'2026-07-28 10:25:15','2026-07-28 10:25:15','2026-07-28 10:25:15'),
(168,86,1,'in',3.00,4.00,'Penerimaan PO PO/2607/00039',37,'GR GR/2607/00037',4,'2026-07-28 10:25:15','2026-07-28 10:25:15','2026-07-28 10:25:15'),
(169,87,1,'in',3.00,3.00,'Penerimaan PO PO/2607/00039',37,'GR GR/2607/00037',4,'2026-07-28 10:25:15','2026-07-28 10:25:15','2026-07-28 10:25:15'),
(170,107,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00039',37,'GR GR/2607/00037',4,'2026-07-28 10:25:15','2026-07-28 10:25:15','2026-07-28 10:25:15'),
(171,86,1,'out',-3.00,1.00,'Sales Order SO/2607/00052',52,'Penjualan SO SO/2607/00052',4,'2026-07-28 10:25:29','2026-07-28 10:25:29','2026-07-28 10:25:29'),
(172,87,1,'out',-3.00,0.00,'Sales Order SO/2607/00052',52,'Penjualan SO SO/2607/00052',4,'2026-07-28 10:25:29','2026-07-28 10:25:29','2026-07-28 10:25:29'),
(173,111,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00042',38,'GR GR/2607/00038',4,'2026-07-28 10:28:25','2026-07-28 10:28:25','2026-07-28 10:28:25'),
(174,111,1,'out',-1.00,0.00,'Sales Order SO/2607/00054',54,'Penjualan SO SO/2607/00054',4,'2026-07-28 10:30:06','2026-07-28 10:30:06','2026-07-28 10:30:06'),
(175,108,1,'out',-1.00,0.00,'Sales Order SO/2607/00054',54,'Penjualan SO SO/2607/00054',4,'2026-07-28 10:30:06','2026-07-28 10:30:06','2026-07-28 10:30:06'),
(176,109,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00040',39,'GR GR/2607/00039',3,'2026-07-28 16:15:00','2026-07-28 16:15:00','2026-07-28 16:15:00'),
(177,110,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00040',39,'GR GR/2607/00039',3,'2026-07-28 16:15:00','2026-07-28 16:15:00','2026-07-28 16:15:00'),
(178,113,1,'in',3.00,3.00,'Penerimaan PO PO/2607/00048',40,'GR GR/2607/00040',4,'2026-07-29 09:05:29','2026-07-29 09:05:29','2026-07-29 09:05:29'),
(179,113,1,'out',-1.00,2.00,'Sales Order SO/2607/00055',55,'Penjualan SO SO/2607/00055',4,'2026-07-29 09:07:28','2026-07-29 09:07:28','2026-07-29 09:07:28'),
(180,109,1,'out',-1.00,0.00,'Sales Order SO/2607/00055',55,'Penjualan SO SO/2607/00055',4,'2026-07-29 09:07:28','2026-07-29 09:07:28','2026-07-29 09:07:28'),
(181,110,1,'out',-1.00,0.00,'Sales Order SO/2607/00055',55,'Penjualan SO SO/2607/00055',4,'2026-07-29 09:07:28','2026-07-29 09:07:28','2026-07-29 09:07:28'),
(182,58,1,'in',25.00,42.00,'Penerimaan PO PO/2607/00043',41,'GR GR/2607/00041',4,'2026-07-30 13:37:16','2026-07-30 13:37:16','2026-07-30 13:37:16'),
(183,56,1,'in',5.00,10.00,'Penerimaan PO PO/2607/00043',41,'GR GR/2607/00041',4,'2026-07-30 13:37:16','2026-07-30 13:37:16','2026-07-30 13:37:16'),
(184,112,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00043',41,'GR GR/2607/00041',4,'2026-07-30 13:37:16','2026-07-30 13:37:16','2026-07-30 13:37:16'),
(185,121,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00049',42,'GR GR/2607/00042',3,'2026-07-30 13:59:35','2026-07-30 13:59:35','2026-07-30 13:59:35'),
(186,122,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00049',42,'GR GR/2607/00042',3,'2026-07-30 13:59:35','2026-07-30 13:59:35','2026-07-30 13:59:35'),
(187,123,1,'in',5.00,5.00,'Penerimaan PO PO/2607/00049',42,'GR GR/2607/00042',3,'2026-07-30 13:59:35','2026-07-30 13:59:35','2026-07-30 13:59:35'),
(188,124,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00049',42,'GR GR/2607/00042',3,'2026-07-30 13:59:35','2026-07-30 13:59:35','2026-07-30 13:59:35'),
(189,121,1,'out',-5.00,0.00,'Sales Order SO/2607/00056',56,'Penjualan SO SO/2607/00056',3,'2026-07-30 14:06:44','2026-07-30 14:06:44','2026-07-30 14:06:44'),
(190,122,1,'out',-5.00,0.00,'Sales Order SO/2607/00056',56,'Penjualan SO SO/2607/00056',3,'2026-07-30 14:06:44','2026-07-30 14:06:44','2026-07-30 14:06:44'),
(191,123,1,'out',-5.00,0.00,'Sales Order SO/2607/00056',56,'Penjualan SO SO/2607/00056',3,'2026-07-30 14:06:44','2026-07-30 14:06:44','2026-07-30 14:06:44'),
(192,124,1,'out',-2.00,0.00,'Sales Order SO/2607/00056',56,'Penjualan SO SO/2607/00056',3,'2026-07-30 14:06:44','2026-07-30 14:06:44','2026-07-30 14:06:44'),
(193,125,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(194,126,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(195,106,1,'in',1.00,2.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(196,127,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(197,128,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(198,86,1,'in',1.00,2.00,'Penerimaan PO PO/2607/00051',43,'GR GR/2607/00043',4,'2026-07-31 09:54:43','2026-07-31 09:54:43','2026-07-31 09:54:43'),
(203,87,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00052',44,'GR GR/2607/00044',4,'2026-07-31 10:25:28','2026-07-31 10:25:28','2026-07-31 10:25:28'),
(204,125,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(205,126,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(206,107,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(207,106,1,'out',-1.00,1.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(208,87,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(209,127,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(210,128,1,'out',-1.00,0.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(211,86,1,'out',-1.00,1.00,'Sales Order SO/2607/00057',57,'Penjualan SO SO/2607/00057',4,'2026-07-31 10:26:13','2026-07-31 10:26:13','2026-07-31 10:26:13'),
(212,127,1,'in',2.00,2.00,'Penerimaan PO PO/2607/00053',45,'GR GR/2607/00045',4,'2026-07-31 13:50:35','2026-07-31 13:50:35','2026-07-31 13:50:35'),
(213,128,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00053',45,'GR GR/2607/00045',4,'2026-07-31 13:50:35','2026-07-31 13:50:35','2026-07-31 13:50:35'),
(214,125,1,'in',1.00,1.00,'Penerimaan PO PO/2607/00053',45,'GR GR/2607/00045',4,'2026-07-31 13:50:35','2026-07-31 13:50:35','2026-07-31 13:50:35'),
(215,61,1,'in',2.00,3.00,'Penerimaan PO PO/2607/00050',46,'GR GR/2607/00046',4,'2026-07-31 13:57:15','2026-07-31 13:57:15','2026-07-31 13:57:15'),
(216,62,1,'in',2.00,3.00,'Penerimaan PO PO/2607/00050',46,'GR GR/2607/00046',4,'2026-07-31 13:57:15','2026-07-31 13:57:15','2026-07-31 13:57:15'),
(217,56,1,'out',-2.00,8.00,'Sales Order SO/2607/00059',59,'Penjualan SO SO/2607/00059',4,'2026-07-31 14:14:45','2026-07-31 14:14:45','2026-07-31 14:14:45'),
(218,54,1,'out',-2.00,19.00,'Sales Order SO/2607/00059',59,'Penjualan SO SO/2607/00059',4,'2026-07-31 14:14:45','2026-07-31 14:14:45','2026-07-31 14:14:45'),
(219,55,1,'out',-1.00,1.00,'Sales Order SO/2607/00059',59,'Penjualan SO SO/2607/00059',4,'2026-07-31 14:14:45','2026-07-31 14:14:45','2026-07-31 14:14:45'),
(220,61,1,'out',-1.00,2.00,'Sales Order SO/2607/00060',60,'Penjualan SO SO/2607/00060',4,'2026-07-31 21:54:55','2026-07-31 21:54:55','2026-07-31 21:54:55'),
(221,62,1,'out',-1.00,2.00,'Sales Order SO/2607/00060',60,'Penjualan SO SO/2607/00060',4,'2026-07-31 21:54:55','2026-07-31 21:54:55','2026-07-31 21:54:55'),
(222,75,1,'out',-1.00,2.00,'Sales Order SO/2607/00060',60,'Penjualan SO SO/2607/00060',4,'2026-07-31 21:54:55','2026-07-31 21:54:55','2026-07-31 21:54:55'),
(223,61,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00054',47,'GR GR/2607/00047',4,'2026-07-31 22:23:37','2026-07-31 22:23:37','2026-07-31 22:23:37'),
(224,62,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00054',47,'GR GR/2607/00047',4,'2026-07-31 22:23:37','2026-07-31 22:23:37','2026-07-31 22:23:37'),
(225,75,1,'in',1.00,3.00,'Penerimaan PO PO/2607/00055',48,'GR GR/2607/00048',4,'2026-07-31 22:27:17','2026-07-31 22:27:17','2026-07-31 22:27:17'),
(226,61,1,'out',-1.00,2.00,'Sales Order SO/2607/00061',61,'Penjualan SO SO/2607/00061',4,'2026-07-31 22:29:45','2026-07-31 22:29:45','2026-07-31 22:29:45'),
(227,62,1,'out',-1.00,2.00,'Sales Order SO/2607/00061',61,'Penjualan SO SO/2607/00061',4,'2026-07-31 22:29:45','2026-07-31 22:29:45','2026-07-31 22:29:45'),
(228,75,1,'out',-1.00,2.00,'Sales Order SO/2607/00061',61,'Penjualan SO SO/2607/00061',4,'2026-07-31 22:29:45','2026-07-31 22:29:45','2026-07-31 22:29:45'),
(229,129,1,'out',-103.00,553.00,'Sales Order SO/2608/00062',62,'Penjualan SO SO/2608/00062',4,'2026-08-03 09:01:49','2026-08-03 09:01:49','2026-08-03 09:01:49'),
(230,129,1,'out',-157.00,396.00,'Sales Order SO/2608/00063',63,'Penjualan SO SO/2608/00063',4,'2026-08-03 09:04:59','2026-08-03 09:04:59','2026-08-03 09:04:59'),
(231,129,1,'out',-296.00,100.00,'Sales Order SO/2608/00064',64,'Penjualan SO SO/2608/00064',4,'2026-08-03 09:08:31','2026-08-03 09:08:31','2026-08-03 09:08:31'),
(232,129,1,'out',-100.00,0.00,'Sales Order SO/2608/00065',65,'Penjualan SO SO/2608/00065',4,'2026-08-03 09:13:36','2026-08-03 09:13:36','2026-08-03 09:13:36'),
(233,130,1,'out',-84.00,0.00,'Sales Order SO/2608/00065',65,'Penjualan SO SO/2608/00065',4,'2026-08-03 09:13:36','2026-08-03 09:13:36','2026-08-03 09:13:36'),
(234,58,1,'out',-1.00,41.00,'Sales Order SO/2608/00066',66,'Penjualan SO SO/2608/00066',4,'2026-08-03 09:20:45','2026-08-03 09:20:45','2026-08-03 09:20:45'),
(235,54,1,'out',-1.00,18.00,'Sales Order SO/2608/00066',66,'Penjualan SO SO/2608/00066',4,'2026-08-03 09:20:45','2026-08-03 09:20:45','2026-08-03 09:20:45'),
(236,57,1,'out',-1.00,16.00,'Sales Order SO/2608/00067',67,'Penjualan SO SO/2608/00067',4,'2026-08-03 09:21:45','2026-08-03 09:21:45','2026-08-03 09:21:45'),
(237,54,1,'out',-1.00,17.00,'Sales Order SO/2608/00067',67,'Penjualan SO SO/2608/00067',4,'2026-08-03 09:21:45','2026-08-03 09:21:45','2026-08-03 09:21:45'),
(238,132,1,'out',-1.00,9.00,'Sales Order SO/2608/00068',68,'Penjualan SO SO/2608/00068',1,'2026-08-03 13:30:30','2026-08-03 13:30:30','2026-08-03 13:30:30'),
(239,84,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00056',49,'GR GR/2608/00049',3,'2026-08-03 13:30:55','2026-08-03 13:30:55','2026-08-03 13:30:55'),
(240,132,1,'in',1.00,10.00,'Edit SO SO/2608/00068',68,'Koreksi item: stok lama dikembalikan',1,'2026-08-03 13:42:43','2026-08-03 13:42:43','2026-08-03 13:42:43'),
(241,132,1,'out',-1.00,9.00,'Edit SO SO/2608/00068',68,'Koreksi item: stok baru dipotong',1,'2026-08-03 13:42:43','2026-08-03 13:42:43','2026-08-03 13:42:43'),
(242,133,1,'out',-5.00,5.00,'Edit SO SO/2608/00068',68,'Koreksi item: stok baru dipotong',1,'2026-08-03 13:42:43','2026-08-03 13:42:43','2026-08-03 13:42:43'),
(243,57,1,'out',-1.00,15.00,'Sales Order SO/2608/00070',70,'Penjualan SO SO/2608/00070',3,'2026-08-03 13:44:19','2026-08-03 13:44:19','2026-08-03 13:44:19'),
(244,134,1,'in',5.00,5.00,'Penerimaan PO PO/2608/00059',50,'GR GR/2608/00050',3,'2026-08-03 13:49:12','2026-08-03 13:49:13','2026-08-03 13:49:13'),
(245,57,1,'out',-1.00,14.00,'Sales Order SO/2608/00069',69,'Penjualan SO SO/2608/00069',3,'2026-08-03 13:49:30','2026-08-03 13:49:30','2026-08-03 13:49:30'),
(246,57,1,'in',1.00,15.00,'Hapus SO duplikat SO/2608/00069',69,'Koreksi: SO duplikat dihapus, stok dikembalikan',NULL,'2026-08-03 14:03:01','2026-08-03 14:03:01','2026-08-03 14:03:01'),
(247,132,1,'in',1.00,10.00,'Hapus data testing SO/2608/00068',68,'Koreksi: SO testing dihapus, stok dikembalikan',NULL,'2026-08-03 14:09:19','2026-08-03 14:09:19','2026-08-03 14:09:19'),
(248,133,1,'in',5.00,10.00,'Hapus data testing SO/2608/00068',68,'Koreksi: SO testing dihapus, stok dikembalikan',NULL,'2026-08-03 14:09:19','2026-08-03 14:09:19','2026-08-03 14:09:19'),
(249,125,1,'out',-1.00,0.00,'Sales Order SO/2608/00071',71,'Penjualan SO SO/2608/00071',3,'2026-08-03 14:23:39','2026-08-03 14:23:39','2026-08-03 14:23:39'),
(250,128,1,'out',-1.00,0.00,'Sales Order SO/2608/00071',71,'Penjualan SO SO/2608/00071',3,'2026-08-03 14:23:39','2026-08-03 14:23:39','2026-08-03 14:23:39'),
(263,58,1,'out',-1.00,40.00,'Sales Order SO/2608/00072',72,'Penjualan SO SO/2608/00072',3,'2026-08-03 14:37:22','2026-08-03 14:37:22','2026-08-03 14:37:22'),
(264,56,1,'out',-1.00,7.00,'Sales Order SO/2608/00072',72,'Penjualan SO SO/2608/00072',3,'2026-08-03 14:37:22','2026-08-03 14:37:22','2026-08-03 14:37:22'),
(265,134,1,'out',-2.00,3.00,'Sales Order SO/2608/00072',72,'Penjualan SO SO/2608/00072',3,'2026-08-03 14:37:22','2026-08-03 14:37:22','2026-08-03 14:37:22'),
(266,127,1,'out',-1.00,1.00,'Sales Order SO/2608/00072',72,'Penjualan SO SO/2608/00072',3,'2026-08-03 14:37:22','2026-08-03 14:37:22','2026-08-03 14:37:22'),
(267,56,1,'in',1.00,8.00,'Penerimaan PO PO/2608/00060',51,'GR GR/2608/00051',3,'2026-08-03 14:42:32','2026-08-03 14:42:32','2026-08-03 14:42:32'),
(268,58,1,'out',-1.00,39.00,'Sales Order SO/2608/00073',73,'Penjualan SO SO/2608/00073',3,'2026-08-03 14:50:25','2026-08-03 14:50:25','2026-08-03 14:50:25'),
(269,134,1,'out',-1.00,2.00,'Sales Order SO/2608/00073',73,'Penjualan SO SO/2608/00073',3,'2026-08-03 14:50:25','2026-08-03 14:50:25','2026-08-03 14:50:25'),
(270,135,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00062',52,'GR GR/2608/00052',3,'2026-08-03 15:09:33','2026-08-03 15:09:33','2026-08-03 15:09:33'),
(271,72,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(272,71,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(273,67,1,'in',1.00,2.00,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(274,103,1,'in',1.00,1.50,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(275,102,1,'in',1.00,1.75,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(276,136,1,'in',3.00,3.00,'Penerimaan PO PO/2608/00063',53,'GR GR/2608/00053',3,'2026-08-03 15:17:18','2026-08-03 15:17:18','2026-08-03 15:17:18'),
(277,75,1,'out',-1.00,1.00,'Sales Order SO/2608/00074',74,'Penjualan SO SO/2608/00074',3,'2026-08-03 15:21:04','2026-08-03 15:21:04','2026-08-03 15:21:04'),
(278,89,1,'in',3.00,5.00,'Penerimaan PO PO/2608/00064',54,'GR GR/2608/00054',3,'2026-08-03 15:33:26','2026-08-03 15:33:26','2026-08-03 15:33:26'),
(279,58,1,'in',1.00,40.00,'Edit SO SO/2608/00073',73,'Koreksi item: stok lama dikembalikan',3,'2026-08-03 16:21:55','2026-08-03 16:21:55','2026-08-03 16:21:55'),
(280,134,1,'in',1.00,3.00,'Edit SO SO/2608/00073',73,'Koreksi item: stok lama dikembalikan',3,'2026-08-03 16:21:55','2026-08-03 16:21:55','2026-08-03 16:21:55'),
(281,58,1,'out',-1.00,39.00,'Edit SO SO/2608/00073',73,'Koreksi item: stok baru dipotong',3,'2026-08-03 16:21:55','2026-08-03 16:21:55','2026-08-03 16:21:55'),
(282,134,1,'out',-2.00,1.00,'Edit SO SO/2608/00073',73,'Koreksi item: stok baru dipotong',3,'2026-08-03 16:21:55','2026-08-03 16:21:55','2026-08-03 16:21:55'),
(284,137,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00065',55,'GR GR/2608/00055',3,'2026-08-03 16:28:27','2026-08-03 16:28:27','2026-08-03 16:28:27'),
(285,89,1,'out',-1.00,4.00,'Sales Order SO/2608/00075',75,'Penjualan SO SO/2608/00075',3,'2026-08-03 16:29:03','2026-08-03 16:29:03','2026-08-03 16:29:03'),
(286,137,1,'out',-1.00,0.00,'Sales Order SO/2608/00075',75,'Penjualan SO SO/2608/00075',3,'2026-08-03 16:29:03','2026-08-03 16:29:03','2026-08-03 16:29:03'),
(287,92,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00061',56,'GR GR/2608/00056',3,'2026-08-03 16:34:22','2026-08-03 16:34:22','2026-08-03 16:34:22'),
(288,84,1,'in',1.00,2.00,'Penerimaan PO PO/2608/00061',56,'GR GR/2608/00056',3,'2026-08-03 16:34:22','2026-08-03 16:34:22','2026-08-03 16:34:22'),
(289,90,1,'in',2.00,3.00,'Penerimaan PO PO/2608/00061',56,'GR GR/2608/00056',3,'2026-08-03 16:34:23','2026-08-03 16:34:23','2026-08-03 16:34:23'),
(290,83,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00061',56,'GR GR/2608/00056',3,'2026-08-03 16:34:23','2026-08-03 16:34:23','2026-08-03 16:34:23'),
(291,89,1,'in',2.00,6.00,'Penerimaan PO PO/2608/00066',57,'GR GR/2608/00057',4,'2026-08-03 23:04:02','2026-08-03 23:04:02','2026-08-03 23:04:02'),
(292,58,1,'out',-1.00,38.00,'Sales Order SO/2608/00076',76,'Penjualan SO SO/2608/00076',4,'2026-08-04 09:20:51','2026-08-04 09:20:51','2026-08-04 09:20:51'),
(293,54,1,'out',-1.00,16.00,'Sales Order SO/2608/00077',77,'Penjualan SO SO/2608/00077',4,'2026-08-04 09:57:16','2026-08-04 09:57:16','2026-08-04 09:57:16'),
(294,153,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00070',58,'GR GR/2608/00058',3,'2026-08-04 13:04:02','2026-08-04 13:04:02','2026-08-04 13:04:02'),
(295,153,1,'out',-1.00,0.00,'Sales Order SO/2608/00078',78,'Penjualan SO SO/2608/00078',3,'2026-08-04 13:09:49','2026-08-04 13:09:49','2026-08-04 13:09:49'),
(296,67,1,'out',-2.00,0.00,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(297,71,1,'out',-1.00,0.00,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(298,136,1,'out',-1.00,2.00,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(299,73,1,'out',-1.00,0.00,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(300,135,1,'out',-1.00,0.00,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(301,102,1,'out',-1.00,0.75,'Sales Order SO/2608/00079',79,'Penjualan SO SO/2608/00079',3,'2026-08-04 13:19:20','2026-08-04 13:19:20','2026-08-04 13:19:20'),
(302,57,1,'out',-1.00,14.00,'Sales Order SO/2608/00080',80,'Penjualan SO SO/2608/00080',3,'2026-08-04 15:11:57','2026-08-04 15:11:57','2026-08-04 15:11:57'),
(303,54,1,'out',-1.00,15.00,'Sales Order SO/2608/00080',80,'Penjualan SO SO/2608/00080',3,'2026-08-04 15:11:57','2026-08-04 15:11:57','2026-08-04 15:11:57'),
(304,112,1,'out',-1.00,4.00,'Sales Order SO/2608/00080',80,'Penjualan SO SO/2608/00080',3,'2026-08-04 15:11:57','2026-08-04 15:11:57','2026-08-04 15:11:57'),
(305,58,1,'out',-1.00,37.00,'Sales Order SO/2608/00080',80,'Penjualan SO SO/2608/00080',3,'2026-08-04 15:11:57','2026-08-04 15:11:57','2026-08-04 15:11:57'),
(306,56,1,'out',-1.00,7.00,'Sales Order SO/2608/00080',80,'Penjualan SO SO/2608/00080',3,'2026-08-04 15:11:57','2026-08-04 15:11:57','2026-08-04 15:11:57'),
(307,154,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00071',59,'GR GR/2608/00059',3,'2026-08-04 15:39:37','2026-08-04 15:39:37','2026-08-04 15:39:37'),
(310,141,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00068',60,'GR GR/2608/00060',3,'2026-08-04 15:50:35','2026-08-04 15:50:35','2026-08-04 15:50:35'),
(311,142,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00068',60,'GR GR/2608/00060',3,'2026-08-04 15:50:35','2026-08-04 15:50:35','2026-08-04 15:50:35'),
(312,98,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00068',60,'GR GR/2608/00060',3,'2026-08-04 15:50:35','2026-08-04 15:50:35','2026-08-04 15:50:35'),
(313,128,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00068',60,'GR GR/2608/00060',3,'2026-08-04 15:50:35','2026-08-04 15:50:35','2026-08-04 15:50:35'),
(318,152,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(319,145,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(320,146,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(321,147,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(322,148,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(323,149,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(324,150,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(325,151,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00069',61,'GR GR/2608/00061',3,'2026-08-04 15:51:24','2026-08-04 15:51:24','2026-08-04 15:51:24'),
(328,131,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00057',62,'GR GR/2608/00062',3,'2026-08-04 16:00:19','2026-08-04 16:00:19','2026-08-04 16:00:19'),
(329,67,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00057',62,'GR GR/2608/00062',3,'2026-08-04 16:00:19','2026-08-04 16:00:19','2026-08-04 16:00:19'),
(330,102,1,'in',1.00,1.75,'Penerimaan PO PO/2608/00057',62,'GR GR/2608/00062',3,'2026-08-04 16:00:19','2026-08-04 16:00:19','2026-08-04 16:00:19'),
(331,67,1,'in',2.00,3.00,'Penerimaan PO PO/2608/00058',63,'GR GR/2608/00063',3,'2026-08-04 16:01:32','2026-08-04 16:01:32','2026-08-04 16:01:32'),
(332,81,1,'in',17.00,17.00,'Penerimaan PO PO/2608/00067',64,'GR GR/2608/00064',3,'2026-08-04 16:12:41','2026-08-04 16:12:41','2026-08-04 16:12:41'),
(333,138,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00067',64,'GR GR/2608/00064',3,'2026-08-04 16:12:41','2026-08-04 16:12:41','2026-08-04 16:12:41'),
(334,83,1,'in',1.00,2.00,'Penerimaan PO PO/2608/00067',64,'GR GR/2608/00064',3,'2026-08-04 16:12:41','2026-08-04 16:12:41','2026-08-04 16:12:41'),
(335,155,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00073',65,'GR GR/2608/00065',4,'2026-08-04 16:40:56','2026-08-04 16:40:56','2026-08-04 16:40:56'),
(336,129,1,'in',500.00,500.00,'Penerimaan PO PO/2608/00074',66,'GR GR/2608/00066',4,'2026-08-04 18:44:38','2026-08-04 18:44:38','2026-08-04 18:44:38'),
(337,129,1,'out',-31.00,469.00,'Sales Order SO/2608/00082',82,'Penjualan SO SO/2608/00082',4,'2026-08-04 18:46:54','2026-08-04 18:46:54','2026-08-04 18:46:54'),
(338,57,1,'out',-2.00,12.00,'Sales Order SO/2608/00083',83,'Penjualan SO SO/2608/00083',4,'2026-08-04 19:45:23','2026-08-04 19:45:23','2026-08-04 19:45:23'),
(339,58,1,'out',-2.00,35.00,'Sales Order SO/2608/00083',83,'Penjualan SO SO/2608/00083',4,'2026-08-04 19:45:23','2026-08-04 19:45:23','2026-08-04 19:45:23'),
(340,54,1,'out',-1.00,14.00,'Sales Order SO/2608/00083',83,'Penjualan SO SO/2608/00083',4,'2026-08-04 19:45:23','2026-08-04 19:45:23','2026-08-04 19:45:23'),
(341,63,1,'out',-3.00,6.00,'Sales Order SO/2608/00084',84,'Penjualan SO SO/2608/00084',4,'2026-08-05 09:32:17','2026-08-05 09:32:17','2026-08-05 09:32:17'),
(342,64,1,'out',-2.00,2.00,'Sales Order SO/2608/00084',84,'Penjualan SO SO/2608/00084',4,'2026-08-05 09:32:17','2026-08-05 09:32:17','2026-08-05 09:32:17'),
(343,143,1,'in',2.00,2.00,'Penerimaan PO PO/2608/00072',67,'GR GR/2608/00067',4,'2026-08-05 09:35:02','2026-08-05 09:35:02','2026-08-05 09:35:02'),
(344,156,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00075',68,'GR GR/2608/00068',3,'2026-08-05 11:09:32','2026-08-05 11:09:32','2026-08-05 11:09:32'),
(347,98,1,'in',2.00,3.00,'Penerimaan PO PO/2608/00076',69,'GR GR/2608/00069',3,'2026-08-05 11:15:57','2026-08-05 11:15:57','2026-08-05 11:15:57'),
(348,89,1,'out',-1.00,5.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(349,154,1,'out',-1.00,1.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(350,98,1,'out',-3.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(351,150,1,'out',-2.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(352,63,1,'out',-5.00,1.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(353,141,1,'out',-2.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(354,64,1,'out',-1.00,1.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(355,151,1,'out',-2.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(356,142,1,'out',-1.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(357,149,1,'out',-1.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(358,156,1,'out',-1.00,0.00,'Sales Order SO/2608/00081',81,'Penjualan SO SO/2608/00081',3,'2026-08-05 11:16:57','2026-08-05 11:16:57','2026-08-05 11:16:57'),
(359,57,1,'out',-2.00,10.00,'Sales Order SO/2608/00085',85,'Penjualan SO SO/2608/00085',3,'2026-08-05 12:14:05','2026-08-05 12:14:05','2026-08-05 12:14:05'),
(360,54,1,'out',-5.00,9.00,'Sales Order SO/2608/00085',85,'Penjualan SO SO/2608/00085',3,'2026-08-05 12:14:05','2026-08-05 12:14:05','2026-08-05 12:14:05'),
(361,81,1,'out',-1.00,16.00,'Sales Order SO/2608/00086',86,'Penjualan SO SO/2608/00086',3,'2026-08-05 12:19:31','2026-08-05 12:19:31','2026-08-05 12:19:31'),
(362,81,1,'out',-1.00,15.00,'Sales Order SO/2608/00087',87,'Penjualan SO SO/2608/00087',3,'2026-08-05 12:22:59','2026-08-05 12:22:59','2026-08-05 12:22:59'),
(363,128,1,'out',-1.00,1.00,'Sales Order SO/2608/00087',87,'Penjualan SO SO/2608/00087',3,'2026-08-05 12:22:59','2026-08-05 12:22:59','2026-08-05 12:22:59'),
(364,84,1,'out',-2.00,0.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(365,95,1,'out',-1.00,0.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(366,113,1,'out',-2.00,0.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(367,92,1,'out',-2.00,0.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(368,90,1,'out',-2.00,1.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(369,83,1,'out',-2.00,0.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(370,138,1,'out',-1.00,1.00,'Sales Order SO/2608/00088',88,'Penjualan SO SO/2608/00088',3,'2026-08-05 12:36:48','2026-08-05 12:36:48','2026-08-05 12:36:48'),
(371,81,1,'out',-1.00,14.00,'Sales Order SO/2608/00089',89,'Penjualan SO SO/2608/00089',3,'2026-08-05 13:02:06','2026-08-05 13:02:06','2026-08-05 13:02:06'),
(372,58,1,'out',-1.00,34.00,'Sales Order SO/2608/00090',90,'Penjualan SO SO/2608/00090',3,'2026-08-05 13:24:45','2026-08-05 13:24:45','2026-08-05 13:24:45'),
(373,56,1,'out',-1.00,6.00,'Sales Order SO/2608/00090',90,'Penjualan SO SO/2608/00090',3,'2026-08-05 13:24:45','2026-08-05 13:24:45','2026-08-05 13:24:45'),
(374,57,1,'in',2.00,12.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok lama dikembalikan',4,'2026-08-05 13:34:10','2026-08-05 13:34:10','2026-08-05 13:34:10'),
(375,54,1,'in',5.00,14.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok lama dikembalikan',4,'2026-08-05 13:34:10','2026-08-05 13:34:10','2026-08-05 13:34:10'),
(376,57,1,'out',-2.00,10.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok baru dipotong',4,'2026-08-05 13:34:10','2026-08-05 13:34:10','2026-08-05 13:34:10'),
(377,54,1,'out',-5.00,9.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok baru dipotong',4,'2026-08-05 13:34:10','2026-08-05 13:34:10','2026-08-05 13:34:10'),
(378,57,1,'in',2.00,12.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok lama dikembalikan',4,'2026-08-05 13:35:50','2026-08-05 13:35:50','2026-08-05 13:35:50'),
(379,54,1,'in',5.00,14.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok lama dikembalikan',4,'2026-08-05 13:35:50','2026-08-05 13:35:50','2026-08-05 13:35:50'),
(380,57,1,'out',-2.00,10.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok baru dipotong',4,'2026-08-05 13:35:50','2026-08-05 13:35:50','2026-08-05 13:35:50'),
(381,54,1,'out',-5.00,9.00,'Edit SO SO/2608/00085',85,'Koreksi item: stok baru dipotong',4,'2026-08-05 13:35:50','2026-08-05 13:35:50','2026-08-05 13:35:50'),
(382,144,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00078',70,'GR GR/2608/00070',3,'2026-08-05 14:28:58','2026-08-05 14:28:58','2026-08-05 14:28:58'),
(387,150,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00079',71,'GR GR/2608/00071',3,'2026-08-05 14:36:03','2026-08-05 14:36:03','2026-08-05 14:36:03'),
(388,145,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(389,146,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(390,147,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(391,148,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(392,150,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(393,128,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(394,155,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(395,144,1,'out',-1.00,0.00,'Sales Order SO/2608/00091',91,'Penjualan SO SO/2608/00091',3,'2026-08-05 14:36:13','2026-08-05 14:36:13','2026-08-05 14:36:13'),
(396,131,1,'out',-1.00,0.00,'Sales Order SO/2608/00092',92,'Penjualan SO SO/2608/00092',3,'2026-08-05 14:48:52','2026-08-05 14:48:52','2026-08-05 14:48:52'),
(397,67,1,'out',-2.00,1.00,'Sales Order SO/2608/00092',92,'Penjualan SO SO/2608/00092',3,'2026-08-05 14:48:52','2026-08-05 14:48:52','2026-08-05 14:48:52'),
(398,126,1,'in',1.00,1.00,'Penerimaan PO PO/2608/00077',72,'GR GR/2608/00072',3,'2026-08-05 16:31:24','2026-08-05 16:31:24','2026-08-05 16:31:24'),
(399,126,1,'out',-1.00,0.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(400,127,1,'out',-1.00,0.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(401,89,1,'out',-1.00,4.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(402,81,1,'out',-1.00,13.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(403,90,1,'out',-1.00,0.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(404,41,1,'out',-1.00,1.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33'),
(405,143,1,'out',-2.00,0.00,'Sales Order SO/2608/00093',93,'Penjualan SO SO/2608/00093',3,'2026-08-05 16:31:33','2026-08-05 16:31:33','2026-08-05 16:31:33');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payments`
--

DROP TABLE IF EXISTS `supplier_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_payments_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `supplier_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `supplier_payments_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payments`
--

LOCK TABLES `supplier_payments` WRITE;
/*!40000 ALTER TABLE `supplier_payments` DISABLE KEYS */;
INSERT INTO `supplier_payments` VALUES
(1,1,3,'2026-07-14',1600000.00,'transfer',NULL,NULL,NULL,'2026-07-14 11:17:53','2026-07-14 11:17:53'),
(2,4,3,'2026-07-14',18280000.00,NULL,NULL,NULL,NULL,'2026-07-14 13:19:59','2026-07-14 13:19:59'),
(3,5,3,'2026-07-14',15547770.00,'transfer',NULL,NULL,NULL,'2026-07-14 13:29:35','2026-07-14 13:29:35'),
(4,6,3,'2026-07-14',1065600.00,NULL,NULL,NULL,NULL,'2026-07-14 13:39:31','2026-07-14 13:39:31'),
(5,7,3,'2026-07-14',1518480.00,'transfer',NULL,NULL,NULL,'2026-07-14 13:44:48','2026-07-14 13:44:48'),
(6,8,3,'2026-07-14',6595200.42,NULL,NULL,NULL,NULL,'2026-07-14 13:54:41','2026-07-14 13:54:41'),
(7,10,3,'2026-07-14',2833441.50,'transfer',NULL,NULL,NULL,'2026-07-14 14:59:27','2026-07-14 14:59:27'),
(8,14,3,'2026-07-15',220000.00,'transfer',NULL,'SI.2026.07.00182','supplier-invoices/SWARQMXxq4B8mQog8nNEJ2RpzegPQWsaIQQO6QeZ.jpg','2026-07-15 16:11:01','2026-07-15 16:11:01'),
(9,13,3,'2026-07-15',8500000.00,'transfer',NULL,NULL,NULL,'2026-07-15 16:36:51','2026-07-15 16:36:51'),
(10,15,3,'2026-07-16',800000.00,NULL,NULL,NULL,'supplier-invoices/aeBc5DRgvVrTx99x8gmnnJCHuwNAe258Jg4vSYN3.jpg','2026-07-16 12:52:23','2026-07-16 12:52:23'),
(11,16,3,'2026-07-16',700000.00,'transfer',NULL,NULL,NULL,'2026-07-16 15:13:17','2026-07-16 15:13:17'),
(12,9,3,'2026-07-16',12834319.50,NULL,NULL,'FKTP.P-26/07/0825','supplier-invoices/LStEkukzZCD6GeDVgJTzyd6pnScFtzIhfxhsTG5x.pdf','2026-07-16 15:29:44','2026-07-16 15:29:44'),
(13,22,3,'2026-07-21',2160000.00,NULL,NULL,NULL,'supplier-invoices/yMgq0ugo4OdAoW7ROI5f3LkMVcMQ7Ap4yE8qSJwt.pdf','2026-07-21 13:22:32','2026-07-21 13:22:32'),
(14,19,3,'2026-07-21',16326990.00,NULL,NULL,NULL,'supplier-invoices/YniCZnExEJznOIB1O78NfBPmn5uWHG8jDDn7kiib.pdf','2026-07-21 13:38:48','2026-07-21 13:38:48'),
(15,20,3,'2026-07-21',957708.00,'transfer',NULL,NULL,'supplier-invoices/iau4TNuyGVPTtURRMs3BuncghlaDZHk5uwNXsrwS.pdf','2026-07-21 13:40:09','2026-07-21 13:40:09'),
(16,23,3,'2026-07-21',12000000.00,NULL,NULL,NULL,NULL,'2026-07-21 14:51:01','2026-07-21 14:51:01'),
(17,21,3,'2026-07-21',2098677.00,'transfer',NULL,NULL,NULL,'2026-07-21 15:22:55','2026-07-21 15:22:55'),
(18,18,3,'2026-07-21',931290.00,NULL,NULL,NULL,NULL,'2026-07-21 15:56:52','2026-07-21 15:56:52'),
(19,25,4,'2026-07-21',228000.00,NULL,NULL,NULL,NULL,'2026-07-21 16:05:18','2026-07-21 16:05:18'),
(20,24,4,'2026-07-21',3000000.00,NULL,NULL,NULL,NULL,'2026-07-21 16:05:48','2026-07-21 16:05:48'),
(21,26,4,'2026-07-23',3300000.00,'Transfer',NULL,NULL,NULL,'2026-07-23 09:19:20','2026-07-23 09:19:20'),
(22,3,4,'2026-07-23',1665000.00,'Transfer',NULL,'INV/DNA/2026/3114-1',NULL,'2026-07-23 12:58:35','2026-07-23 12:58:35'),
(23,29,4,'2026-07-23',848000.00,'Transfer',NULL,'Jl-26070730',NULL,'2026-07-23 14:55:59','2026-07-23 14:55:59'),
(24,28,4,'2026-07-23',3450000.00,'Transfer',NULL,NULL,NULL,'2026-07-23 14:56:28','2026-07-23 14:56:28'),
(25,30,3,'2026-07-23',1002000.00,'transfer',NULL,NULL,NULL,'2026-07-23 16:20:27','2026-07-23 16:20:27'),
(26,31,3,'2026-07-23',750000.00,'transfer',NULL,NULL,NULL,'2026-07-23 16:24:20','2026-07-23 16:24:20'),
(27,32,3,'2026-07-24',8624700.00,'transfer',NULL,NULL,NULL,'2026-07-24 15:30:15','2026-07-24 15:30:15'),
(28,34,4,'2026-07-25',400000.00,'Transfer',NULL,NULL,NULL,'2026-07-25 11:04:16','2026-07-25 11:04:16'),
(29,35,4,'2026-07-25',750000.00,'Transfer',NULL,NULL,NULL,'2026-07-25 11:16:39','2026-07-25 11:16:39'),
(30,36,3,'2026-07-25',6800000.00,'transfer',NULL,NULL,NULL,'2026-07-25 11:41:57','2026-07-25 11:41:57'),
(31,37,4,'2026-07-27',850000.00,'Transfer',NULL,NULL,NULL,'2026-07-27 12:31:25','2026-07-27 12:31:25'),
(32,38,4,'2026-07-27',3000000.00,NULL,NULL,NULL,NULL,'2026-07-27 12:33:13','2026-07-27 12:33:13'),
(33,33,3,'2026-07-27',1963479.00,'transfer',NULL,'FKTP.P-26/07/0869','supplier-invoices/rjsIC53kLTn67ZTFd7wRrex4GQIjr3e0DEXknMRH.pdf','2026-07-27 14:01:32','2026-07-27 14:01:32'),
(34,41,4,'2026-07-28',3145000.00,'Transfer',NULL,NULL,NULL,'2026-07-28 10:18:54','2026-07-28 10:18:54'),
(35,39,4,'2026-07-28',2058000.00,'Transfer',NULL,'Jl-26070744',NULL,'2026-07-28 10:25:08','2026-07-28 10:25:08'),
(36,42,4,'2026-07-28',200000.00,NULL,NULL,NULL,NULL,'2026-07-28 10:28:29','2026-07-28 10:28:29'),
(37,40,3,'2026-07-28',3254076.00,'transfer',NULL,NULL,NULL,'2026-07-28 16:15:09','2026-07-28 16:15:09'),
(38,48,4,'2026-07-29',900000.00,NULL,NULL,NULL,NULL,'2026-07-29 09:05:37','2026-07-29 09:05:37'),
(39,43,4,'2026-07-30',16813170.00,'Transfer',NULL,NULL,NULL,'2026-07-30 13:37:29','2026-07-30 13:37:29'),
(40,51,4,'2026-07-31',1548000.00,'Transfer',NULL,'Jl-26070758',NULL,'2026-07-31 13:51:30','2026-07-31 13:51:30'),
(41,52,4,'2026-07-31',400000.00,'Transfer',NULL,'Jl-26070760',NULL,'2026-07-31 13:53:02','2026-07-31 13:53:02'),
(42,53,4,'2026-07-31',996000.00,'TrAnsfer',NULL,'Jl-26070761',NULL,'2026-07-31 13:53:47','2026-07-31 13:53:47'),
(43,50,4,'2026-07-31',3036960.00,'Transfer',NULL,NULL,NULL,'2026-07-31 13:57:11','2026-07-31 13:57:11'),
(44,59,3,'2026-08-03',125000.00,NULL,NULL,NULL,NULL,'2026-08-03 13:49:08','2026-08-03 13:49:08'),
(45,62,3,'2026-08-03',1060549.50,'transfer',NULL,NULL,NULL,'2026-08-03 15:09:29','2026-08-03 15:09:29'),
(46,63,3,'2026-08-03',4400000.00,NULL,NULL,NULL,NULL,'2026-08-03 15:17:24','2026-08-03 15:17:24'),
(47,64,3,'2026-08-03',9600000.00,'transfer',NULL,NULL,NULL,'2026-08-03 15:33:35','2026-08-03 15:33:35'),
(48,65,3,'2026-08-03',539000.00,'transfer',NULL,'SO.2026.08.00023',NULL,'2026-08-03 16:28:54','2026-08-03 16:28:54'),
(49,61,3,'2026-08-03',3124239.30,'transfer',NULL,NULL,NULL,'2026-08-03 16:34:37','2026-08-03 16:34:37'),
(50,66,4,'2026-08-03',6400000.00,'Transfer',NULL,NULL,NULL,'2026-08-03 23:04:15','2026-08-03 23:04:15'),
(51,56,4,'2026-08-04',894327.00,'Transfer',NULL,NULL,NULL,'2026-08-04 08:43:48','2026-08-04 08:43:48'),
(52,49,3,'2026-08-04',2489998.62,'transfer',NULL,'SQ.2026.07.04335',NULL,'2026-08-04 12:45:17','2026-08-04 12:45:17'),
(53,70,3,'2026-08-04',459000.00,NULL,NULL,NULL,NULL,'2026-08-04 13:04:38','2026-08-04 13:04:38'),
(54,58,3,'2026-08-04',1092462.00,'transfer',NULL,'FKTP.P-26/08/0914',NULL,'2026-08-04 16:02:49','2026-08-04 16:02:49'),
(55,57,3,'2026-08-04',3188808.00,'transfer',NULL,'FKTP.P-26/0/0913',NULL,'2026-08-04 16:03:39','2026-08-04 16:03:39'),
(56,69,3,'2026-08-04',897003.21,'transfer',NULL,NULL,NULL,'2026-08-04 16:05:16','2026-08-04 16:05:16'),
(57,68,3,'2026-08-04',1135000.00,'transfer',NULL,NULL,NULL,'2026-08-04 16:05:44','2026-08-04 16:05:44'),
(58,67,3,'2026-08-04',9532125.00,'transfer',NULL,'92607766',NULL,'2026-08-04 16:12:32','2026-08-04 16:12:32'),
(59,73,4,'2026-08-04',1330771.00,NULL,NULL,NULL,NULL,'2026-08-04 16:41:02','2026-08-04 16:41:02'),
(60,72,4,'2026-08-05',290000.00,'Transfer',NULL,'Jl-26080780',NULL,'2026-08-05 09:35:52','2026-08-05 09:35:52'),
(61,75,3,'2026-08-05',318000.00,'transfer',NULL,NULL,NULL,'2026-08-05 11:09:52','2026-08-05 11:09:52'),
(62,76,3,'2026-08-05',2.00,'transfer',NULL,NULL,NULL,'2026-08-05 11:16:05','2026-08-05 11:16:05'),
(63,79,3,'2026-08-05',10000.00,NULL,NULL,NULL,NULL,'2026-08-05 16:32:03','2026-08-05 16:32:03'),
(64,77,3,'2026-08-05',300000.00,NULL,NULL,NULL,NULL,'2026-08-05 16:32:27','2026-08-05 16:32:27'),
(65,71,3,'2026-08-05',40630.00,NULL,NULL,NULL,NULL,'2026-08-05 16:32:43','2026-08-05 16:32:43'),
(66,74,3,'2026-08-05',500.00,NULL,NULL,NULL,NULL,'2026-08-05 16:32:56','2026-08-05 16:32:56');
/*!40000 ALTER TABLE `supplier_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES
(1,'SUP-0001','PT Onemed Distribusi','Sales Onemed','021-7770001',NULL,NULL,'03.111.222.3-093.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'SUP-0002','PT Enseval Medika Prima','Sales Enseval','021-7770002',NULL,NULL,'04.222.333.4-093.000',45,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'SUP-0003','CV Sumber Medis Jaya','Bpk. Hendra','0813-3333-4444',NULL,NULL,'',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'SUP-0004','Sarana Maju Sejahtera',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 14:48:51','2026-07-13 14:48:51'),
(5,'SUP-0005','pak egi',NULL,'08131081203',NULL,'cisauk',NULL,0,1,'2026-07-14 11:16:05','2026-07-14 11:16:05'),
(6,'SUP-0006','PT ARDHIKA UMRAN ABADI',NULL,NULL,NULL,'Jl. Bintara VII No.100A RT.06 RW.03 Bintara, Bekasi - Jawa Barat',NULL,0,1,'2026-07-14 11:40:03','2026-07-14 11:40:03'),
(7,'SUP-0007','PT Demaz Noer Abadi','Adetya Nur Azis','085814390858',NULL,'Perkampungan Kecil Blok G62 Kel. Penggilingan Kec Cakung Jakarta Timur DKI Jakarta',NULL,0,1,'2026-07-14 12:20:34','2026-07-14 12:20:34'),
(8,'SUP-0008','Rumah Sakit Ibu dan Anak Dhia',NULL,'081282103297',NULL,'Jl. Cendrawasih Raya No.90, Sawah Lama, Kec. Ciputat, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-14 12:27:08','2026-07-14 12:27:08'),
(9,'SUP-0009','CV. SAMZIO NUSA MEDIKA',NULL,'0816 1794 2649',NULL,'Jl. Panglima Polim Perumahan Cluster Plawad Indah Blok C No.3 Tangerang 15141',NULL,0,1,'2026-07-14 13:17:00','2026-07-14 13:17:00'),
(10,'SUP-0010','PT LIFOTRONIC TECHNOLOGY INDONESIA',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-14 13:26:02','2026-07-14 13:26:02'),
(11,'SUP-0011','PT. ERA MEDIKA AKESINDO','BUDI RAHMAT',NULL,NULL,'JL. SISINGAMANGARAJA KM10.8 KOMPLEK AMPLAS TRADE CENTER BLOK MAHONI NO 08 KOTA MEDAN, SUMATERA UTARA','91.542.645.6-125.000',0,1,'2026-07-14 13:34:39','2026-07-14 13:34:39'),
(12,'SUP-0012','PT Andalas Prima Sentosa','Zalfiyah','089611918823',NULL,'Jl. Pemuda No.29 8, RT.8/RW.4, Rawamangun, Kec. Pulo Gadung, Kota Jakarta Timur, Daerah Khusus Ibukota Jakarta',NULL,0,1,'2026-07-14 14:34:54','2026-07-14 14:34:54'),
(13,'SUP-0013','Nur Khanif',NULL,NULL,NULL,'Pamulang',NULL,0,1,'2026-07-15 15:24:39','2026-07-15 15:24:39'),
(14,'SUP-0014','PT. Khabib Kreasi Mandiri',NULL,NULL,NULL,'Jl. Beringin IX No.118, RT.004/RW007/RW.008, Pamulang Bar., Kec. Pamulang, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-15 16:08:08','2026-07-15 16:08:08'),
(15,'SUP-0015','Asep Kurnia',NULL,NULL,NULL,'Sukabumi',NULL,0,1,'2026-07-16 15:10:57','2026-07-16 15:10:57'),
(16,'SUP-0016','PT Elba Lab Medika','Pak dimas',NULL,NULL,'Jalan raya kalimalang kav agraria kel. Duren sawit jakarta','76.532.551.9-008.000',0,1,'2026-07-17 12:47:52','2026-07-17 12:47:52'),
(17,'SUP-0017','PT sarana maju sejahtera',NULL,NULL,NULL,'Jl johar no 2 menteng central jakarta rt 18 rw 6 kebon sirih menteng jakarta',NULL,0,1,'2026-07-20 11:29:31','2026-07-20 11:29:31'),
(18,'SUP-0018','PT Telaga Medika Solusindo',NULL,NULL,NULL,'Bestari, Komplek Ruko Jungle Walk Blok B No.26-27, Talaga, Cibadak, Kec. Cikupa, Kabupaten Tangerang, Banten',NULL,0,1,'2026-07-20 13:31:41','2026-07-20 13:31:41'),
(19,'SUP-0019','PT Berkat Mulia Simpolin',NULL,NULL,NULL,'Jl. Limo Raya No.2, Limo, Kec. Limo, Kota Depok, Jawa Barat 16515',NULL,0,1,'2026-07-21 11:19:47','2026-07-21 11:19:47'),
(20,'SUP-0020','PT Mikhael Anugrah Medikal Makasar',NULL,NULL,NULL,'Jl. Goldel Hills Blk. A No.2, Tamalanrea, Kec. Tamalanrea, Kota Makassar, Sulawesi Selatan','02.349.095.6-801.000',0,1,'2026-07-21 14:48:06','2026-07-21 14:48:06'),
(21,'SUP-0021','Ardiyansyah',NULL,NULL,NULL,'depok',NULL,0,1,'2026-07-21 14:49:17','2026-07-21 14:49:17'),
(22,'SUP-0022','Punjul Puromo',NULL,NULL,NULL,'Villa Dago Pamulang Tangerang Selatan',NULL,0,1,'2026-07-21 15:26:34','2026-07-21 15:26:34'),
(23,'SUP-0023','Pak Rahadian Tjahyo wibisono',NULL,NULL,NULL,'Bekasi',NULL,0,1,'2026-07-21 16:09:14','2026-07-21 16:09:14'),
(24,'SUP-0024','Pak setya wahyu',NULL,NULL,NULL,'Gunung sindur',NULL,0,1,'2026-07-23 14:58:07','2026-07-23 14:58:07'),
(25,'SUP-0025','Ian Ardyansyah',NULL,NULL,NULL,'Depok',NULL,0,1,'2026-07-25 11:37:41','2026-07-25 11:37:41'),
(26,'SUP-0026','Ian Ardyansyah',NULL,NULL,NULL,'Depok',NULL,0,1,'2026-07-25 11:39:49','2026-07-25 11:39:49'),
(27,'SUP-0027','Ibu fitri',NULL,NULL,NULL,'Tangerang',NULL,0,1,'2026-07-28 10:27:39','2026-07-28 10:27:39'),
(28,'SUP-0028','PT Burhan Sejahtera Mulia',NULL,NULL,NULL,'Graha BSM Jl Kayu Manis Kec. Matraman Jakarta Timur DKI Jakarta',NULL,0,1,'2026-07-30 13:56:47','2026-07-30 13:56:47');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_invoices`
--

DROP TABLE IF EXISTS `tax_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('output','input') NOT NULL,
  `tax_number` varchar(255) NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `purchase_order_id` bigint(20) unsigned DEFAULT NULL,
  `partner_name` varchar(255) NOT NULL,
  `partner_npwp` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_invoices_tax_number_unique` (`tax_number`),
  KEY `tax_invoices_invoice_id_foreign` (`invoice_id`),
  KEY `tax_invoices_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `tax_invoices_user_id_foreign` (`user_id`),
  KEY `tax_invoices_type_date_index` (`type`,`date`),
  CONSTRAINT `tax_invoices_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_invoices`
--

LOCK TABLES `tax_invoices` WRITE;
/*!40000 ALTER TABLE `tax_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES
(1,'Pieces','pcs','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Box','box','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Unit','unit','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Set','set','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Pack','pack','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'Lusin','lsn','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'Vial','Vial','2026-07-13 12:28:55','2026-07-13 12:29:17'),
(8,'Botol','btl','2026-07-13 13:23:41','2026-07-13 13:23:41');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Administrator','admin@dimaslovemedika.com','2026-07-10 20:33:43','$2y$12$oCqRgpSNOFj/tgjHtDDqUecJBBYnOZPuYY5c9E7GNTf6Q5lw5bFlK',1,NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff Operasional','staff@dimaslovemedika.com','2026-07-10 20:33:44','$2y$12$Yg6Wf6sq6ZjqE1tPxacIbOTcrwDFuFVjaNcCpJe1e1G6hfUORuW4.',1,NULL,'2026-07-10 20:33:44','2026-07-10 20:33:44'),
(3,'rafly','admin@rafly.com',NULL,'$2y$12$ve0fYV0BDzI/j2M3iY43guTLzgK.dxAAj5OUONIl8qVzkIUj3p7BG',1,'rjCdPrtJ0gYPwNqJ5KCno1TaRHxZhfqWHz1iu3AWmFWfHBGczWiEjoADwWL0','2026-07-13 12:19:51','2026-07-13 15:11:38'),
(4,'dimas','admin@dimas.com',NULL,'$2y$12$6G8HJMg1CvNiMojTSFLCcO2gm1qwSMI1OkOnyFQLgGsNq4Ypj89zq',1,'E98Gh0YqMo7ZVR6AvM4uWwObvU8c4koxjAbz31nrmN4Efyqx0ms9SMQYDnWX','2026-07-15 16:17:06','2026-07-15 16:17:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES
(1,'Gudang Utama','Jl. Kodiklat TNI Buaran Hankam No. 59, Serpong, Tangerang Selatan',1,1,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dlm_medika'
--

--
-- Dumping routines for database 'dlm_medika'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-06  2:00:01
