/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: dlm_medika
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `causer_type` varchar(255) DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `attribute_changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attribute_changes`)),
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
(1,'satuan','created','App\\Models\\Unit',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pieces\",\"symbol\":\"pcs\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'satuan','created','App\\Models\\Unit',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Box\",\"symbol\":\"box\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'satuan','created','App\\Models\\Unit',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Unit\",\"symbol\":\"unit\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'satuan','created','App\\Models\\Unit',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Set\",\"symbol\":\"set\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'satuan','created','App\\Models\\Unit',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Pack\",\"symbol\":\"pack\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'satuan','created','App\\Models\\Unit',6,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Lusin\",\"symbol\":\"lsn\"}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'kategori','created','App\\Models\\Category',1,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'kategori','created','App\\Models\\Category',2,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Nonelektromedik Non Steril\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'kategori','created','App\\Models\\Category',3,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alkes Diagnostik In Vitro\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'kategori','created','App\\Models\\Category',4,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Alat Laboratorium\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'kategori','created','App\\Models\\Category',5,'created',NULL,NULL,'{\"attributes\":{\"name\":\"Consumable Medis\",\"description\":null}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'produk','created','App\\Models\\Product',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0001\",\"name\":\"Masker Bedah 3 Ply (Box 50)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"22000.00\",\"sell_price\":\"35000.00\",\"min_stock\":\"50.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'produk','created','App\\Models\\Product',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0002\",\"name\":\"Sarung Tangan Latex Steril (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"65000.00\",\"sell_price\":\"95000.00\",\"min_stock\":\"30.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'produk','created','App\\Models\\Product',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0003\",\"name\":\"Spuit \\/ Syringe 3ml (Box 100)\",\"category_id\":1,\"unit_id\":2,\"cost_price\":\"48000.00\",\"sell_price\":\"72000.00\",\"min_stock\":\"25.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'produk','created','App\\Models\\Product',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0004\",\"name\":\"Infus Set Dewasa\",\"category_id\":1,\"unit_id\":1,\"cost_price\":\"4500.00\",\"sell_price\":\"8000.00\",\"min_stock\":\"100.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'produk','created','App\\Models\\Product',5,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0005\",\"name\":\"Kasa Steril 16x16 (Pack)\",\"category_id\":1,\"unit_id\":5,\"cost_price\":\"3500.00\",\"sell_price\":\"6500.00\",\"min_stock\":\"80.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'produk','created','App\\Models\\Product',6,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0006\",\"name\":\"Rapid Test Antigen (Box 25)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"210000.00\",\"sell_price\":\"320000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'produk','created','App\\Models\\Product',7,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0007\",\"name\":\"Tabung Vacutainer EDTA (Box 100)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"85000.00\",\"sell_price\":\"130000.00\",\"min_stock\":\"15.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'produk','created','App\\Models\\Product',8,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0008\",\"name\":\"Alkohol Swab (Box 100)\",\"category_id\":5,\"unit_id\":2,\"cost_price\":\"9000.00\",\"sell_price\":\"16000.00\",\"min_stock\":\"40.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'produk','created','App\\Models\\Product',9,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0009\",\"name\":\"Termometer Digital\",\"category_id\":4,\"unit_id\":3,\"cost_price\":\"28000.00\",\"sell_price\":\"55000.00\",\"min_stock\":\"10.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'produk','created','App\\Models\\Product',10,'created',NULL,NULL,'{\"attributes\":{\"code\":\"PRD-0010\",\"name\":\"Pinset Anatomis Stainless\",\"category_id\":2,\"unit_id\":1,\"cost_price\":\"15000.00\",\"sell_price\":\"30000.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'pelanggan','created','App\\Models\\Customer',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0001\",\"name\":\"RS Medika Sentosa\",\"phone\":\"021-5551001\",\"npwp\":\"01.234.567.8-091.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'pelanggan','created','App\\Models\\Customer',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0002\",\"name\":\"Klinik Sehat Bersama\",\"phone\":\"021-5552002\",\"npwp\":\"02.345.678.9-091.000\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'pelanggan','created','App\\Models\\Customer',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0003\",\"name\":\"Apotek Kimia Farmasi\",\"phone\":\"0812-1111-2222\",\"npwp\":\"\",\"payment_term_days\":7,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'pelanggan','created','App\\Models\\Customer',4,'created',NULL,NULL,'{\"attributes\":{\"code\":\"CUST-0004\",\"name\":\"Puskesmas Serpong\",\"phone\":\"021-5553003\",\"npwp\":\"\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'supplier','created','App\\Models\\Supplier',1,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0001\",\"name\":\"PT Onemed Distribusi\",\"phone\":\"021-7770001\",\"npwp\":\"03.111.222.3-093.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'supplier','created','App\\Models\\Supplier',2,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0002\",\"name\":\"PT Enseval Medika Prima\",\"phone\":\"021-7770002\",\"npwp\":\"04.222.333.4-093.000\",\"payment_term_days\":45,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'supplier','created','App\\Models\\Supplier',3,'created',NULL,NULL,'{\"attributes\":{\"code\":\"SUP-0003\",\"name\":\"CV Sumber Medis Jaya\",\"phone\":\"0813-3333-4444\",\"npwp\":\"\",\"payment_term_days\":14,\"is_active\":true}}','[]','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'pelanggan','created','App\\Models\\Customer',5,'created','App\\Models\\User',1,'{\"attributes\":{\"code\":\"CUST-0005\",\"name\":\"joko\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 00:01:34','2026-07-13 00:01:34'),
(30,'satuan','created','App\\Models\\Unit',7,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:28:55','2026-07-13 12:28:55'),
(31,'satuan','updated','App\\Models\\Unit',7,'updated','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Vial\",\"symbol\":\"Vial\"},\"old\":{\"name\":\"vial\",\"symbol\":\"v\"}}','[]','2026-07-13 12:29:17','2026-07-13 12:29:17'),
(32,'produk','created','App\\Models\\Product',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:07','2026-07-13 12:41:07'),
(33,'produk','created','App\\Models\\Product',12,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 12:41:50','2026-07-13 12:41:50'),
(34,'produk','created','App\\Models\\Product',13,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:42:38','2026-07-13 12:42:38'),
(35,'produk','created','App\\Models\\Product',14,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:43:21','2026-07-13 12:43:21'),
(36,'produk','created','App\\Models\\Product',15,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:44:26','2026-07-13 12:44:26'),
(37,'produk','created','App\\Models\\Product',16,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:45:59','2026-07-13 12:45:59'),
(38,'produk','created','App\\Models\\Product',17,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:46:53','2026-07-13 12:46:53'),
(39,'produk','created','App\\Models\\Product',18,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:48:42','2026-07-13 12:48:42'),
(40,'produk','created','App\\Models\\Product',19,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 12:49:31','2026-07-13 12:49:31'),
(41,'pelanggan','created','App\\Models\\Customer',6,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0006\",\"name\":\"PT Amanah Husada Pamulang\",\"phone\":null,\"npwp\":\"66.376.297.9-411.000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 12:57:55','2026-07-13 12:57:55'),
(42,'pelanggan','created','App\\Models\\Customer',7,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0007\",\"name\":\"PT Allaya Mandiri Sejahtera\",\"phone\":null,\"npwp\":\"902616440452000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 13:10:48','2026-07-13 13:10:48'),
(43,'produk','deleted','App\\Models\\Product',17,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0017\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:02','2026-07-13 13:13:02'),
(44,'produk','deleted','App\\Models\\Product',15,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0015\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"340000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:09','2026-07-13 13:13:09'),
(45,'produk','deleted','App\\Models\\Product',16,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0016\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:13:13','2026-07-13 13:13:13'),
(46,'produk','created','App\\Models\\Product',20,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0020\",\"name\":\"Accu Chek Instant\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"245000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:15:32','2026-07-13 13:15:32'),
(47,'produk','created','App\\Models\\Product',21,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0021\",\"name\":\"Accu Chek Performa\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:01','2026-07-13 13:16:01'),
(48,'produk','created','App\\Models\\Product',22,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0022\",\"name\":\"Accu Chek Guide\",\"category_id\":5,\"unit_id\":5,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:16:39','2026-07-13 13:16:39'),
(49,'produk','deleted','App\\Models\\Product',18,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0018\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:15','2026-07-13 13:18:15'),
(50,'produk','created','App\\Models\\Product',23,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0023\",\"name\":\"Vacutube EDTA\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:18:47','2026-07-13 13:18:47'),
(51,'produk','deleted','App\\Models\\Product',19,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0019\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":5,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:18:58','2026-07-13 13:18:58'),
(52,'produk','created','App\\Models\\Product',24,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0024\",\"name\":\"Vacutube Plain (Tabung Merah)\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"60000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:19:25','2026-07-13 13:19:25'),
(53,'produk','deleted','App\\Models\\Product',12,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0012\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"300000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:19:36','2026-07-13 13:19:36'),
(54,'produk','created','App\\Models\\Product',25,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:20','2026-07-13 13:20:20'),
(55,'produk','deleted','App\\Models\\Product',25,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:20:41','2026-07-13 13:20:41'),
(56,'produk','created','App\\Models\\Product',26,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0025\",\"name\":\"Diluent Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"350000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:21:11','2026-07-13 13:21:11'),
(57,'produk','deleted','App\\Models\\Product',11,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0011\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"5.00\",\"is_active\":true}}','[]','2026-07-13 13:21:16','2026-07-13 13:21:16'),
(58,'produk','created','App\\Models\\Product',27,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0027\",\"name\":\"Diluent Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"500000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:22:25','2026-07-13 13:22:25'),
(59,'produk','updated','App\\Models\\Product',26,'updated','App\\Models\\User',3,'{\"attributes\":{\"cost_price\":\"299999.99\"},\"old\":{\"cost_price\":\"350000.00\"}}','[]','2026-07-13 13:22:39','2026-07-13 13:22:39'),
(60,'produk','deleted','App\\Models\\Product',13,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0013\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:23:01','2026-07-13 13:23:01'),
(61,'satuan','created','App\\Models\\Unit',8,'created','App\\Models\\User',3,'{\"attributes\":{\"name\":\"Botol\",\"symbol\":\"btl\"}}','[]','2026-07-13 13:23:41','2026-07-13 13:23:41'),
(62,'produk','created','App\\Models\\Product',28,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0028\",\"name\":\"Lyse Lifotronic\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"330000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:24:50','2026-07-13 13:24:50'),
(63,'produk','deleted','App\\Models\\Product',14,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0014\",\"name\":\"Lyse Mindray\",\"category_id\":3,\"unit_id\":2,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"3.00\",\"is_active\":true}}','[]','2026-07-13 13:24:57','2026-07-13 13:24:57'),
(64,'produk','created','App\\Models\\Product',29,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:32','2026-07-13 13:25:32'),
(65,'produk','deleted','App\\Models\\Product',29,'deleted','App\\Models\\User',3,'{\"old\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:25:54','2026-07-13 13:25:54'),
(66,'produk','created','App\\Models\\Product',30,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"PRD-0029\",\"name\":\"Lyse Mindray M10\",\"category_id\":3,\"unit_id\":8,\"cost_price\":\"630000.00\",\"sell_price\":\"0.00\",\"min_stock\":\"0.00\",\"is_active\":true}}','[]','2026-07-13 13:26:28','2026-07-13 13:26:28'),
(67,'pelanggan','created','App\\Models\\Customer',8,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0008\",\"name\":\"RSIA Vitalaya\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:09:33','2026-07-13 14:09:33'),
(68,'pelanggan','created','App\\Models\\Customer',9,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0009\",\"name\":\"RS Citra Insani\",\"phone\":null,\"npwp\":\"O23803026403000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:10:42','2026-07-13 14:10:42'),
(69,'pelanggan','updated','App\\Models\\Customer',9,'updated','App\\Models\\User',3,'{\"attributes\":{\"payment_term_days\":30},\"old\":{\"payment_term_days\":0}}','[]','2026-07-13 14:11:06','2026-07-13 14:11:06'),
(70,'pelanggan','created','App\\Models\\Customer',10,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0010\",\"name\":\"RS BHAYANGKARA\",\"phone\":null,\"npwp\":\"1237767013000\",\"payment_term_days\":30,\"is_active\":true}}','[]','2026-07-13 14:12:57','2026-07-13 14:12:57'),
(71,'pelanggan','created','App\\Models\\Customer',11,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"CUST-0011\",\"name\":\"PT Nauli Sejahtera Medika\",\"phone\":null,\"npwp\":\"86.947.018.7-452.000\",\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:16:43','2026-07-13 14:16:43'),
(72,'supplier','created','App\\Models\\Supplier',4,'created','App\\Models\\User',3,'{\"attributes\":{\"code\":\"SUP-0004\",\"name\":\"Sarana Maju Sejahtera\",\"phone\":null,\"npwp\":null,\"payment_term_days\":0,\"is_active\":true}}','[]','2026-07-13 14:48:51','2026-07-13 14:48:51');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('pt-dimas-love-medika-cache-settings.all','a:18:{s:12:\"company_name\";s:20:\"PT DIMAS LOVE MEDIKA\";s:12:\"company_npwp\";s:19:\"1000 0000 0468 5165\";s:11:\"company_nib\";s:13:\"0108250170791\";s:12:\"company_izin\";s:17:\"01082501707910001\";s:12:\"company_kbli\";s:71:\"46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia\";s:15:\"company_address\";s:116:\"Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310\";s:13:\"company_phone\";s:29:\"021-38939414 / 0859-3319-1346\";s:13:\"company_email\";s:21:\"anggihdimas@gmail.com\";s:11:\"company_pjt\";s:37:\"Nia Love Fiana Puteri (D.III Farmasi)\";s:8:\"ppn_rate\";s:2:\"11\";s:19:\"fp_transaction_code\";s:2:\"04\";s:9:\"fp_prefix\";s:0:\"\";s:14:\"fp_last_serial\";s:2:\"11\";s:14:\"fp_serial_year\";s:2:\"26\";s:9:\"bank_name\";s:8:\"Bank BCA\";s:15:\"bank_account_no\";s:10:\"8011111629\";s:19:\"bank_account_holder\";s:20:\"PT DIMAS LOVE MEDIKA\";s:13:\"director_name\";s:16:\"M Anggih Dimas W\";}',2099279690),
('pt-dimas-love-medika-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:45:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:13:\"products.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:15:\"products.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"products.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:15:\"products.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:15:\"categories.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:17:\"categories.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:17:\"categories.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:17:\"categories.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:10:\"units.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:12:\"units.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:12:\"units.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:12:\"units.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:14:\"customers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:16:\"customers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:16:\"customers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:16:\"customers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:14:\"suppliers.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:16:\"suppliers.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:16:\"suppliers.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:16:\"suppliers.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:17:\"sales-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:19:\"sales-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:19:\"sales-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:19:\"sales-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:25;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:15:\"invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:26;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:15:\"invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:27;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:15:\"invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:28;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:20:\"purchase-orders.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:29;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:22:\"purchase-orders.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:30;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:22:\"purchase-orders.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:31;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:22:\"purchase-orders.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:32;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:17:\"tax-invoices.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:33;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:19:\"tax-invoices.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:34;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:19:\"tax-invoices.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:35;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:19:\"tax-invoices.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:36;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:15:\"quotations.view\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:37;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:17:\"quotations.create\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:38;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:17:\"quotations.update\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:39;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:17:\"quotations.delete\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:40;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:19:\"reports.operational\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:41;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:15:\"reports.finance\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:42;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:15:\"settings.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:43;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:12:\"users.manage\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:44;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:17:\"transactions.void\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:2:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"Admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"Staff\";s:1:\"c\";s:3:\"web\";}}}',1784005917);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Alkes Nonelektromedik Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Alkes Nonelektromedik Non Steril',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Alkes Diagnostik In Vitro',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Alat Laboratorium',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Consumable Medis',NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_payments`
--

DROP TABLE IF EXISTS `customer_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_payments_invoice_id_foreign` (`invoice_id`),
  KEY `customer_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `customer_payments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_payments`
--

LOCK TABLES `customer_payments` WRITE;
/*!40000 ALTER TABLE `customer_payments` DISABLE KEYS */;
INSERT INTO `customer_payments` VALUES
(1,1,NULL,'2026-04-19',576000.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,3,NULL,'2026-03-29',912420.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,4,NULL,'2026-05-08',2816070.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,9,NULL,'2026-05-14',770000.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(5,10,NULL,'2026-06-10',213120.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(6,11,NULL,'2026-06-14',632700.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(7,12,NULL,'2026-07-05',441336.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(8,13,NULL,'2026-07-13',173160.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(9,14,NULL,'2026-07-17',770000.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(10,15,NULL,'2026-07-26',841380.00,'transfer',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(11,13,1,'2026-07-10',173160.00,'CBD',NULL,'2026-07-10 20:53:19','2026-07-10 20:53:19'),
(12,13,1,'2026-07-10',86580.00,'CBD',NULL,'2026-07-10 20:53:36','2026-07-10 20:53:36'),
(13,8,1,'2026-07-13',594960.00,'CBD',NULL,'2026-07-13 00:06:27','2026-07-13 00:06:27'),
(14,20,1,'2026-07-13',320000.00,NULL,NULL,'2026-07-13 12:12:30','2026-07-13 12:12:30'),
(15,19,1,'2026-07-13',107000.00,NULL,NULL,'2026-07-13 12:17:03','2026-07-13 12:17:03'),
(16,12,1,'2026-07-13',662004.00,NULL,NULL,'2026-07-13 12:17:29','2026-07-13 12:17:29'),
(17,21,3,'2026-07-13',1000000.00,'transfer',NULL,'2026-07-13 14:40:02','2026-07-13 14:40:02');
/*!40000 ALTER TABLE `customer_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'CUST-0001','RS Medika Sentosa','dr. Andi','021-5551001',NULL,NULL,'01.234.567.8-091.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'CUST-0002','Klinik Sehat Bersama','Ibu Rina','021-5552002',NULL,NULL,'02.345.678.9-091.000',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'CUST-0003','Apotek Kimia Farmasi','Bpk. Joko','0812-1111-2222',NULL,NULL,'',7,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'CUST-0004','Puskesmas Serpong','Ibu Sari','021-5553003',NULL,NULL,'',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'CUST-0005','joko',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 00:01:34','2026-07-13 00:01:34'),
(6,'CUST-0006','PT Amanah Husada Pamulang',NULL,NULL,NULL,'Jl Raya Siliwangi 1A Pondok Benda Pamulang Kota Tangerang Selatan Banten','66.376.297.9-411.000',30,1,'2026-07-13 12:57:55','2026-07-13 12:57:55'),
(7,'CUST-0007','PT Allaya Mandiri Sejahtera',NULL,NULL,NULL,'Ruko Mardi Grass Citra Raya KF 02, 02 Mekar Bakti Panongan Kab Tangerang Banten 15757\r\nTangerang Banten','902616440452000',0,1,'2026-07-13 13:10:48','2026-07-13 13:10:48'),
(8,'CUST-0008','RSIA Vitalaya',NULL,NULL,NULL,'Jl. Siliwangi No.50, Pd. Benda, Kec. Pamulang, Kota Tangerang Selatan, Banten',NULL,0,1,'2026-07-13 14:09:33','2026-07-13 14:09:33'),
(9,'CUST-0009','RS Citra Insani',NULL,NULL,NULL,'Jl. Permata Lb. Wangi Jl. Raya Parung No.242, Pamegarsari, Kec. Parung, Kabupaten Bogor, Jawa Barat','O23803026403000',30,1,'2026-07-13 14:10:42','2026-07-13 14:11:06'),
(10,'CUST-0010','RS BHAYANGKARA',NULL,NULL,NULL,'Jl. Ciputat Raya No.40, RT.1/RW.9, Pd. Pinang, Kec. Kebayoran Lama, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12310','1237767013000',30,1,'2026-07-13 14:12:57','2026-07-13 14:12:57'),
(11,'CUST-0011','PT Nauli Sejahtera Medika',NULL,NULL,NULL,'Ruko golden Road Jl Pahlawan Seribu BSD City (Sektor VII.C) C32,22 Lengkong Wetan Serpong Tangerang Selatan Banten','86.947.018.7-452.000',0,1,'2026-07-13 14:16:43','2026-07-13 14:16:43');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipt_items`
--

DROP TABLE IF EXISTS `goods_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipt_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `goods_receipt_id` bigint(20) unsigned NOT NULL,
  `purchase_order_item_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `goods_receipt_items_goods_receipt_id_foreign` (`goods_receipt_id`),
  KEY `goods_receipt_items_purchase_order_item_id_foreign` (`purchase_order_item_id`),
  KEY `goods_receipt_items_product_id_foreign` (`product_id`),
  CONSTRAINT `goods_receipt_items_goods_receipt_id_foreign` FOREIGN KEY (`goods_receipt_id`) REFERENCES `goods_receipts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipt_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `goods_receipt_items_purchase_order_item_id_foreign` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `purchase_order_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipt_items`
--

LOCK TABLES `goods_receipt_items` WRITE;
/*!40000 ALTER TABLE `goods_receipt_items` DISABLE KEYS */;
INSERT INTO `goods_receipt_items` VALUES
(1,1,1,1,57.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,1,2,5,25.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,2,3,1,54.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,2,4,5,56.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,2,5,10,60.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(6,3,6,2,44.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(7,3,7,5,11.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(8,3,8,9,20.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(9,4,9,2,44.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(10,4,10,5,23.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(11,4,11,7,54.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(12,5,12,10,24.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(13,6,13,2,15.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(14,6,14,5,55.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(15,6,15,9,43.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(16,7,16,5,56.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(17,7,17,6,32.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(18,7,18,8,56.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(19,8,19,2,55.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(20,8,20,4,54.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(21,8,21,9,20.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(22,9,22,8,100.00,'2026-07-13 12:15:42','2026-07-13 12:15:42'),
(23,10,23,23,1.00,'2026-07-13 14:50:43','2026-07-13 14:50:43'),
(24,10,24,3,1.00,'2026-07-13 14:50:43','2026-07-13 14:50:43'),
(25,10,25,2,1.00,'2026-07-13 14:50:43','2026-07-13 14:50:43'),
(26,10,26,3,1.00,'2026-07-13 14:50:43','2026-07-13 14:50:43');
/*!40000 ALTER TABLE `goods_receipt_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipts`
--

DROP TABLE IF EXISTS `goods_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gr_number` varchar(255) NOT NULL,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `goods_receipts_gr_number_unique` (`gr_number`),
  KEY `goods_receipts_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `goods_receipts_warehouse_id_foreign` (`warehouse_id`),
  KEY `goods_receipts_user_id_foreign` (`user_id`),
  CONSTRAINT `goods_receipts_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `goods_receipts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `goods_receipts_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipts`
--

LOCK TABLES `goods_receipts` WRITE;
/*!40000 ALTER TABLE `goods_receipts` DISABLE KEYS */;
INSERT INTO `goods_receipts` VALUES
(1,'GR/2603/00001',1,1,NULL,'2026-03-16',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,'GR/2604/00002',2,1,NULL,'2026-04-21',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,'GR/2605/00003',3,1,NULL,'2026-05-14',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,'GR/2605/00004',4,1,NULL,'2026-05-17',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,'GR/2606/00005',5,1,NULL,'2026-06-23',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(6,'GR/2606/00006',6,1,NULL,'2026-06-26',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(7,'GR/2607/00007',7,1,NULL,'2026-07-11',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(8,'GR/2607/00008',8,1,NULL,'2026-07-14',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(9,'GR/2607/00009',9,1,1,'2026-07-13',NULL,'2026-07-13 12:15:42','2026-07-13 12:15:42'),
(10,'GR/2607/00010',10,1,3,'2026-07-13',NULL,'2026-07-13 14:50:43','2026-07-13 14:50:43');
/*!40000 ALTER TABLE `goods_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) NOT NULL,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'unpaid',
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_sales_order_id_foreign` (`sales_order_id`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'INV/2603/00001',1,NULL,'2026-03-22','2026-04-21','paid',576000.00,576000.00,NULL,'2026-03-21 00:00:00','2026-07-10 20:52:07'),
(2,'INV/2603/00002',2,NULL,'2026-03-23','2026-03-30','unpaid',3124650.00,0.00,NULL,'2026-03-22 00:00:00','2026-07-10 20:52:07'),
(3,'INV/2603/00003',3,NULL,'2026-03-23','2026-03-30','paid',912420.00,912420.00,NULL,'2026-03-22 00:00:00','2026-07-10 20:52:07'),
(4,'INV/2604/00004',4,NULL,'2026-04-23','2026-05-23','paid',2816070.00,2816070.00,NULL,'2026-04-22 00:00:00','2026-07-10 20:52:07'),
(5,'INV/2604/00005',5,NULL,'2026-04-23','2026-05-07','unpaid',1278720.00,0.00,NULL,'2026-04-22 00:00:00','2026-07-10 20:52:07'),
(6,'INV/2605/00006',6,NULL,'2026-05-08','2026-06-07','unpaid',1178820.00,0.00,NULL,'2026-05-07 00:00:00','2026-07-10 20:52:08'),
(7,'INV/2605/00007',7,NULL,'2026-05-05','2026-06-04','unpaid',7864000.00,0.00,NULL,'2026-05-04 00:00:00','2026-07-10 20:52:08'),
(8,'INV/2605/00008',8,NULL,'2026-05-14','2026-06-13','paid',594960.00,594960.00,NULL,'2026-05-13 00:00:00','2026-07-13 00:06:27'),
(9,'INV/2605/00009',9,NULL,'2026-05-11','2026-05-18','paid',770000.00,770000.00,NULL,'2026-05-10 00:00:00','2026-07-10 20:52:08'),
(10,'INV/2606/00010',10,NULL,'2026-06-07','2026-07-07','partial',532800.00,213120.00,NULL,'2026-06-06 00:00:00','2026-07-10 20:52:08'),
(11,'INV/2606/00011',11,NULL,'2026-06-09','2026-06-16','partial',1581750.00,632700.00,NULL,'2026-06-08 00:00:00','2026-07-10 20:52:08'),
(12,'INV/2606/00012',12,NULL,'2026-06-28','2026-07-05','paid',1103340.00,1103340.00,NULL,'2026-06-27 00:00:00','2026-07-13 12:17:29'),
(13,'INV/2607/00013',13,NULL,'2026-07-10','2026-08-09','paid',432900.00,432900.00,NULL,'2026-07-09 00:00:00','2026-07-10 20:53:36'),
(14,'INV/2607/00014',14,NULL,'2026-07-05','2026-07-19','paid',770000.00,770000.00,NULL,'2026-07-04 00:00:00','2026-07-10 20:52:08'),
(15,'INV/2607/00015',15,NULL,'2026-07-12','2026-08-11','paid',841380.00,841380.00,NULL,'2026-07-11 00:00:00','2026-07-10 20:52:08'),
(16,'INV/2607/00016',16,1,'2026-07-13','2026-07-13','unpaid',865800.00,0.00,NULL,'2026-07-13 00:03:27','2026-07-13 00:03:27'),
(17,'INV/2607/00017',17,1,'2026-07-13','2026-07-20','unpaid',50000.00,0.00,NULL,'2026-07-13 00:15:19','2026-07-13 00:15:19'),
(18,'INV/2607/00018',18,1,'2026-07-13','2026-07-27','unpaid',35000.00,0.00,NULL,'2026-07-13 00:31:46','2026-07-13 00:31:46'),
(19,'INV/2607/00019',20,1,'2026-07-13','2026-07-14','paid',107000.00,107000.00,NULL,'2026-07-13 12:05:46','2026-07-13 12:17:03'),
(20,'INV/2607/00020',21,1,'2026-07-13','2026-07-23','paid',320000.00,320000.00,NULL,'2026-07-13 12:12:22','2026-07-13 12:12:30'),
(21,'INV/2607/00021',23,3,'2026-07-13','2026-07-13','partial',2233875.00,1000000.00,NULL,'2026-07-13 14:36:43','2026-07-13 14:40:02');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_07_10_142631_create_activity_log_table',1),
(5,'2026_07_10_142631_create_permission_tables',1),
(6,'2026_07_11_000001_create_categories_table',1),
(7,'2026_07_11_000002_create_units_table',1),
(8,'2026_07_11_000003_create_warehouses_table',1),
(9,'2026_07_11_000004_create_products_table',1),
(10,'2026_07_11_000005_create_customers_table',1),
(11,'2026_07_11_000006_create_suppliers_table',1),
(12,'2026_07_11_000007_create_settings_table',1),
(13,'2026_07_12_000001_create_stock_movements_table',1),
(14,'2026_07_12_000002_create_purchase_orders_table',1),
(15,'2026_07_12_000003_create_purchase_order_items_table',1),
(16,'2026_07_12_000004_create_goods_receipts_table',1),
(17,'2026_07_12_000005_create_supplier_payments_table',1),
(18,'2026_07_12_000006_create_sales_orders_table',1),
(19,'2026_07_12_000007_create_sales_order_items_table',1),
(20,'2026_07_12_000008_create_invoices_table',1),
(21,'2026_07_12_000009_create_customer_payments_table',1),
(22,'2026_07_13_000001_create_tax_invoices_table',1),
(23,'2026_07_13_000002_create_quotations_table',1),
(24,'2026_07_13_000003_add_due_date_to_purchase_orders_table',2),
(25,'2026_07_13_000004_add_due_date_to_sales_orders_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1),
(1,'App\\Models\\User',3),
(2,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'products.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(2,'products.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(3,'products.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(4,'products.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(5,'categories.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(6,'categories.create','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(7,'categories.update','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(8,'categories.delete','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(9,'units.view','web','2026-07-10 20:33:42','2026-07-10 20:33:42'),
(10,'units.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'units.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'units.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'customers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(14,'customers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(15,'customers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(16,'customers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(17,'suppliers.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(18,'suppliers.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(19,'suppliers.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(20,'suppliers.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(21,'sales-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(22,'sales-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(23,'sales-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(24,'sales-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(25,'invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(26,'invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(27,'invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(28,'invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(29,'purchase-orders.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(30,'purchase-orders.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(31,'purchase-orders.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(32,'purchase-orders.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(33,'tax-invoices.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(34,'tax-invoices.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(35,'tax-invoices.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(36,'tax-invoices.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(37,'quotations.view','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(38,'quotations.create','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(39,'quotations.update','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(40,'quotations.delete','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(41,'reports.operational','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(42,'reports.finance','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(43,'settings.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(44,'users.manage','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(45,'transactions.void','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `cost_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sell_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `min_stock` decimal(18,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_unit_id_foreign` (`unit_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'PRD-0001','Masker Bedah 3 Ply (Box 50)',5,2,22000.00,35000.00,385.00,50.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 12:05:34'),
(2,'PRD-0002','Sarung Tangan Latex Steril (Box 100)',1,2,65000.00,95000.00,288.00,30.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:50:43'),
(3,'PRD-0003','Spuit / Syringe 3ml (Box 100)',1,2,48000.00,72000.00,79.00,25.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:50:43'),
(4,'PRD-0004','Infus Set Dewasa',1,1,4500.00,8000.00,534.00,100.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-10 20:52:08'),
(5,'PRD-0005','Kasa Steril 16x16 (Pack)',1,5,3500.00,6500.00,617.00,80.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:36:32'),
(6,'PRD-0006','Rapid Test Antigen (Box 25)',3,2,210000.00,320000.00,41.00,10.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:36:32'),
(7,'PRD-0007','Tabung Vacutainer EDTA (Box 100)',3,2,85000.00,130000.00,78.00,15.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:36:32'),
(8,'PRD-0008','Alkohol Swab (Box 100)',5,2,9000.00,16000.00,325.00,40.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-13 14:36:32'),
(9,'PRD-0009','Termometer Digital',4,3,28000.00,55000.00,41.00,10.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-10 20:52:08'),
(10,'PRD-0010','Pinset Anatomis Stainless',2,1,15000.00,30000.00,79.00,5.00,NULL,NULL,1,'2026-07-10 20:33:43','2026-07-10 20:52:08'),
(20,'PRD-0020','Accu Chek Instant',5,5,245000.00,0.00,14.00,0.00,NULL,NULL,1,'2026-07-13 13:15:32','2026-07-13 13:15:32'),
(21,'PRD-0021','Accu Chek Performa',5,5,350000.00,0.00,5.00,0.00,NULL,NULL,1,'2026-07-13 13:16:01','2026-07-13 13:16:01'),
(22,'PRD-0022','Accu Chek Guide',5,5,350000.00,0.00,7.98,0.00,NULL,NULL,1,'2026-07-13 13:16:39','2026-07-13 13:16:39'),
(23,'PRD-0023','Vacutube EDTA',3,2,60000.00,0.00,12.98,0.00,NULL,NULL,1,'2026-07-13 13:18:47','2026-07-13 14:50:43'),
(24,'PRD-0024','Vacutube Plain (Tabung Merah)',3,2,60000.00,0.00,3.97,0.00,NULL,NULL,1,'2026-07-13 13:19:25','2026-07-13 13:19:25'),
(26,'PRD-0025','Diluent Lifotronic',3,2,299999.99,0.00,21.00,0.00,NULL,NULL,1,'2026-07-13 13:21:11','2026-07-13 13:22:39'),
(27,'PRD-0027','Diluent Mindray',3,2,500000.00,0.00,30.00,0.00,NULL,NULL,1,'2026-07-13 13:22:25','2026-07-13 13:22:25'),
(28,'PRD-0028','Lyse Lifotronic',3,8,330000.00,0.00,30.00,0.00,NULL,NULL,1,'2026-07-13 13:24:50','2026-07-13 13:24:50'),
(30,'PRD-0029','Lyse Mindray M10',3,8,630000.00,0.00,7.00,0.00,NULL,NULL,1,'2026-07-13 13:26:28','2026-07-13 13:26:28');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `qty_received` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cost_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_items_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `purchase_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `purchase_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `purchase_order_items_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
INSERT INTO `purchase_order_items` VALUES
(1,1,1,57.00,57.00,22000.00,0.00,1254000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,1,5,25.00,25.00,3500.00,0.00,87500.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,2,1,54.00,54.00,22000.00,0.00,1188000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,2,5,56.00,56.00,3500.00,0.00,196000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,2,10,60.00,60.00,15000.00,0.00,900000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(6,3,2,44.00,44.00,65000.00,0.00,2860000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(7,3,5,11.00,11.00,3500.00,0.00,38500.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(8,3,9,20.00,20.00,28000.00,0.00,560000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(9,4,2,44.00,44.00,65000.00,0.00,2860000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(10,4,5,23.00,23.00,3500.00,0.00,80500.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(11,4,7,54.00,54.00,85000.00,0.00,4590000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(12,5,10,24.00,24.00,15000.00,0.00,360000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(13,6,2,15.00,15.00,65000.00,0.00,975000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(14,6,5,55.00,55.00,3500.00,0.00,192500.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(15,6,9,43.00,43.00,28000.00,0.00,1204000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(16,7,5,56.00,56.00,3500.00,0.00,196000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(17,7,6,32.00,32.00,210000.00,0.00,6720000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(18,7,8,56.00,56.00,9000.00,0.00,504000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(19,8,2,55.00,55.00,65000.00,0.00,3575000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(20,8,4,54.00,54.00,4500.00,0.00,243000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(21,8,9,20.00,20.00,28000.00,0.00,560000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(22,9,8,100.00,100.00,9000.00,0.00,900000.00,'2026-07-13 00:09:13','2026-07-13 12:15:42'),
(23,10,23,1.00,1.00,60000.00,0.00,60000.00,'2026-07-13 14:49:26','2026-07-13 14:50:43'),
(24,10,3,1.00,1.00,48000.00,0.00,48000.00,'2026-07-13 14:49:26','2026-07-13 14:50:43'),
(25,10,2,1.00,1.00,65000.00,0.00,65000.00,'2026-07-13 14:49:26','2026-07-13 14:50:43'),
(26,10,3,1.00,1.00,48000.00,0.00,48000.00,'2026-07-13 14:49:26','2026-07-13 14:50:43');
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `po_number` varchar(255) NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_orders_po_number_unique` (`po_number`),
  KEY `purchase_orders_supplier_id_foreign` (`supplier_id`),
  KEY `purchase_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
INSERT INTO `purchase_orders` VALUES
(1,'PO/2603/00001',1,NULL,'2026-03-14','2026-04-13','received',1,11.00,1341500.00,0.00,1341500.00,147565.00,1489065.00,1489065.00,NULL,'2026-03-14 00:00:00','2026-07-13 12:04:48'),
(2,'PO/2604/00002',1,NULL,'2026-04-19','2026-05-19','received',0,11.00,2284000.00,0.00,2284000.00,0.00,2284000.00,0.00,NULL,'2026-04-19 00:00:00','2026-07-13 12:04:48'),
(3,'PO/2605/00003',3,NULL,'2026-05-12','2026-05-26','received',0,11.00,3458500.00,0.00,3458500.00,0.00,3458500.00,0.00,NULL,'2026-05-12 00:00:00','2026-07-13 12:04:48'),
(4,'PO/2605/00004',3,NULL,'2026-05-15','2026-05-29','received',0,11.00,7530500.00,0.00,7530500.00,0.00,7530500.00,3765250.00,NULL,'2026-05-15 00:00:00','2026-07-13 12:04:48'),
(5,'PO/2606/00005',1,NULL,'2026-06-21','2026-07-21','received',0,11.00,360000.00,0.00,360000.00,0.00,360000.00,180000.00,NULL,'2026-06-21 00:00:00','2026-07-13 12:04:48'),
(6,'PO/2606/00006',3,NULL,'2026-06-24','2026-07-08','received',1,11.00,2371500.00,0.00,2371500.00,260865.00,2632365.00,1316183.00,NULL,'2026-06-24 00:00:00','2026-07-13 12:04:48'),
(7,'PO/2607/00007',3,NULL,'2026-07-09','2026-07-23','received',0,11.00,7420000.00,0.00,7420000.00,0.00,7420000.00,0.00,NULL,'2026-07-09 00:00:00','2026-07-13 12:04:48'),
(8,'PO/2607/00008',2,NULL,'2026-07-12','2026-08-26','received',1,11.00,4378000.00,0.00,4378000.00,481580.00,4859580.00,0.00,NULL,'2026-07-12 00:00:00','2026-07-13 12:04:48'),
(9,'PO/2607/00009',2,1,'2026-07-13','2026-08-27','received',1,11.00,900000.00,0.00,900000.00,99000.00,999000.00,999000.00,NULL,'2026-07-13 00:09:13','2026-07-13 12:15:42'),
(10,'PO/2607/00010',4,3,'2026-07-13','2026-07-13','received',1,11.00,221000.00,0.00,221000.00,24310.00,245310.00,245310.00,NULL,'2026-07-13 14:49:26','2026-07-13 14:50:43');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_items_quotation_id_foreign` (`quotation_id`),
  KEY `quotation_items_product_id_foreign` (`product_id`),
  CONSTRAINT `quotation_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `quotation_items_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
INSERT INTO `quotation_items` VALUES
(1,1,2,8.00,95000.00,0.00,760000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(2,1,8,2.00,16000.00,0.00,32000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(3,1,9,8.00,55000.00,0.00,440000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(4,2,4,5.00,8000.00,0.00,40000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(5,2,5,9.00,6500.00,0.00,58500.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(6,2,7,14.00,130000.00,0.00,1820000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(7,3,4,11.00,8000.00,0.00,88000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(8,4,3,6.00,72000.00,0.00,432000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(9,4,10,9.00,30000.00,0.00,270000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(10,5,2,10.00,95000.00,0.00,950000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(11,5,8,3.00,16000.00,0.00,48000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08');
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `valid_until` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `terms` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `converted_sales_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotations_quotation_number_unique` (`quotation_number`),
  KEY `quotations_customer_id_foreign` (`customer_id`),
  KEY `quotations_user_id_foreign` (`user_id`),
  KEY `quotations_converted_sales_order_id_foreign` (`converted_sales_order_id`),
  CONSTRAINT `quotations_converted_sales_order_id_foreign` FOREIGN KEY (`converted_sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quotations_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `quotations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` VALUES
(1,'QT/2606/00001',3,NULL,'2026-06-28','2026-07-12','draft',1,11.00,1232000.00,0.00,1232000.00,135520.00,1367520.00,'1. Harga sudah termasuk PPN.\n2. Penawaran berlaku 14 hari.',NULL,NULL,'2026-06-28 20:52:08','2026-07-10 20:52:08'),
(2,'QT/2606/00002',2,NULL,'2026-06-08','2026-06-22','sent',1,11.00,1918500.00,0.00,1918500.00,211035.00,2129535.00,'1. Harga sudah termasuk PPN.\n2. Penawaran berlaku 14 hari.',NULL,NULL,'2026-06-08 20:52:08','2026-07-10 20:52:08'),
(3,'QT/2606/00003',2,NULL,'2026-06-27','2026-07-11','accepted',1,11.00,88000.00,0.00,88000.00,9680.00,97680.00,'1. Harga sudah termasuk PPN.\n2. Penawaran berlaku 14 hari.',NULL,NULL,'2026-06-27 20:52:08','2026-07-10 20:52:08'),
(4,'QT/2606/00004',4,NULL,'2026-06-11','2026-06-25','rejected',1,11.00,702000.00,0.00,702000.00,77220.00,779220.00,'1. Harga sudah termasuk PPN.\n2. Penawaran berlaku 14 hari.',NULL,NULL,'2026-06-11 20:52:08','2026-07-10 20:52:08'),
(5,'QT/2606/00005',1,NULL,'2026-06-08','2026-06-22','sent',1,11.00,998000.00,0.00,998000.00,109780.00,1107780.00,'1. Harga sudah termasuk PPN.\n2. Penawaran berlaku 14 hari.',NULL,NULL,'2026-06-08 20:52:08','2026-07-10 20:52:08');
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,1),
(1,2),
(2,1),
(2,2),
(3,1),
(3,2),
(4,1),
(5,1),
(5,2),
(6,1),
(6,2),
(7,1),
(7,2),
(8,1),
(9,1),
(9,2),
(10,1),
(10,2),
(11,1),
(11,2),
(12,1),
(13,1),
(13,2),
(14,1),
(14,2),
(15,1),
(15,2),
(16,1),
(17,1),
(17,2),
(18,1),
(18,2),
(19,1),
(19,2),
(20,1),
(21,1),
(21,2),
(22,1),
(22,2),
(23,1),
(23,2),
(24,1),
(25,1),
(25,2),
(26,1),
(26,2),
(27,1),
(27,2),
(28,1),
(29,1),
(29,2),
(30,1),
(30,2),
(31,1),
(31,2),
(32,1),
(33,1),
(33,2),
(34,1),
(34,2),
(35,1),
(36,1),
(37,1),
(37,2),
(38,1),
(38,2),
(39,1),
(39,2),
(40,1),
(41,1),
(41,2),
(42,1),
(43,1),
(44,1),
(45,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff','web','2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_items`
--

DROP TABLE IF EXISTS `sales_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sales_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `sell_price` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount_reason` varchar(255) DEFAULT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_order_items_sales_order_id_foreign` (`sales_order_id`),
  KEY `sales_order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `sales_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `sales_order_items_sales_order_id_foreign` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_items`
--

LOCK TABLES `sales_order_items` WRITE;
/*!40000 ALTER TABLE `sales_order_items` DISABLE KEYS */;
INSERT INTO `sales_order_items` VALUES
(1,1,4,17.00,8000.00,0.00,NULL,136000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,1,9,8.00,55000.00,0.00,NULL,440000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,2,1,2.00,35000.00,0.00,NULL,70000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,2,6,6.00,320000.00,0.00,NULL,1920000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,2,9,15.00,55000.00,0.00,NULL,825000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(6,3,3,6.00,72000.00,0.00,NULL,432000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(7,3,7,3.00,130000.00,0.00,NULL,390000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(8,4,3,6.00,72000.00,0.00,NULL,432000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(9,4,7,9.00,130000.00,0.00,NULL,1170000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(10,4,9,17.00,55000.00,0.00,NULL,935000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(11,5,3,16.00,72000.00,0.00,NULL,1152000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(12,6,3,11.00,72000.00,0.00,NULL,792000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(13,6,10,9.00,30000.00,0.00,NULL,270000.00,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(14,7,6,19.00,320000.00,0.00,NULL,6080000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(15,7,7,12.00,130000.00,0.00,NULL,1560000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(16,7,8,14.00,16000.00,0.00,NULL,224000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(17,8,1,8.00,35000.00,0.00,NULL,280000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(18,8,8,16.00,16000.00,0.00,NULL,256000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(19,9,9,14.00,55000.00,0.00,NULL,770000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(20,10,10,16.00,30000.00,0.00,NULL,480000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(21,11,2,15.00,95000.00,0.00,NULL,1425000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(22,12,2,5.00,95000.00,0.00,NULL,475000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(23,12,4,3.00,8000.00,0.00,NULL,24000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(24,12,9,9.00,55000.00,0.00,NULL,495000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(25,13,7,3.00,130000.00,0.00,NULL,390000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(26,14,9,14.00,55000.00,0.00,NULL,770000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(27,15,1,14.00,35000.00,0.00,NULL,490000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(28,15,3,3.00,72000.00,0.00,NULL,216000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(29,15,5,8.00,6500.00,0.00,NULL,52000.00,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(31,16,7,6.00,130000.00,0.00,NULL,780000.00,'2026-07-13 00:03:01','2026-07-13 00:03:01'),
(32,17,2,1.00,50000.00,0.00,NULL,50000.00,'2026-07-13 00:14:17','2026-07-13 00:14:17'),
(33,18,1,1.00,35000.00,0.00,NULL,35000.00,'2026-07-13 00:31:41','2026-07-13 00:31:41'),
(34,19,10,1.00,30000.00,0.00,NULL,30000.00,'2026-07-13 12:04:56','2026-07-13 12:04:56'),
(35,20,1,1.00,35000.00,0.00,NULL,35000.00,'2026-07-13 12:05:27','2026-07-13 12:05:27'),
(36,20,3,1.00,72000.00,0.00,NULL,72000.00,'2026-07-13 12:05:27','2026-07-13 12:05:27'),
(37,21,6,1.00,320000.00,0.00,NULL,320000.00,'2026-07-13 12:10:46','2026-07-13 12:10:46'),
(38,22,4,1.00,8000.00,20.00,NULL,7980.00,'2026-07-13 14:18:34','2026-07-13 14:18:34'),
(39,22,6,1.00,320000.00,0.00,NULL,320000.00,'2026-07-13 14:18:34','2026-07-13 14:18:34'),
(40,22,7,1.00,130000.00,0.00,NULL,130000.00,'2026-07-13 14:18:34','2026-07-13 14:18:34'),
(41,23,7,3.00,130000.00,0.00,NULL,390000.00,'2026-07-13 14:36:25','2026-07-13 14:36:25'),
(42,23,8,1.00,16000.00,0.00,NULL,16000.00,'2026-07-13 14:36:25','2026-07-13 14:36:25'),
(43,23,5,1.00,6500.00,0.00,NULL,6500.00,'2026-07-13 14:36:25','2026-07-13 14:36:25'),
(44,23,6,5.00,320000.00,0.00,NULL,1600000.00,'2026-07-13 14:36:25','2026-07-13 14:36:25');
/*!40000 ALTER TABLE `sales_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_orders`
--

DROP TABLE IF EXISTS `sales_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `so_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `is_taxable` tinyint(1) NOT NULL DEFAULT 1,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `subtotal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `stock_deducted` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_orders_so_number_unique` (`so_number`),
  KEY `sales_orders_customer_id_foreign` (`customer_id`),
  KEY `sales_orders_user_id_foreign` (`user_id`),
  CONSTRAINT `sales_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `sales_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_orders`
--

LOCK TABLES `sales_orders` WRITE;
/*!40000 ALTER TABLE `sales_orders` DISABLE KEYS */;
INSERT INTO `sales_orders` VALUES
(1,'SO/2603/00001',4,NULL,'2026-03-21','2026-04-21','completed',0,11.00,576000.00,0.00,576000.00,0.00,576000.00,1,NULL,'2026-03-21 00:00:00','2026-07-13 12:04:48'),
(2,'SO/2603/00002',3,NULL,'2026-03-22','2026-03-30','completed',1,11.00,2815000.00,0.00,2815000.00,309650.00,3124650.00,1,NULL,'2026-03-22 00:00:00','2026-07-13 12:04:48'),
(3,'SO/2603/00003',3,NULL,'2026-03-22','2026-03-30','completed',1,11.00,822000.00,0.00,822000.00,90420.00,912420.00,1,NULL,'2026-03-22 00:00:00','2026-07-13 12:04:48'),
(4,'SO/2604/00004',1,NULL,'2026-04-22','2026-05-23','completed',1,11.00,2537000.00,0.00,2537000.00,279070.00,2816070.00,1,NULL,'2026-04-22 00:00:00','2026-07-13 12:04:48'),
(5,'SO/2604/00005',2,NULL,'2026-04-22','2026-05-07','completed',1,11.00,1152000.00,0.00,1152000.00,126720.00,1278720.00,1,NULL,'2026-04-22 00:00:00','2026-07-13 12:04:48'),
(6,'SO/2605/00006',4,NULL,'2026-05-07','2026-06-07','completed',1,11.00,1062000.00,0.00,1062000.00,116820.00,1178820.00,1,NULL,'2026-05-07 00:00:00','2026-07-13 12:04:48'),
(7,'SO/2605/00007',4,NULL,'2026-05-04','2026-06-04','completed',0,11.00,7864000.00,0.00,7864000.00,0.00,7864000.00,1,NULL,'2026-05-04 00:00:00','2026-07-13 12:04:48'),
(8,'SO/2605/00008',1,NULL,'2026-05-13','2026-06-13','completed',1,11.00,536000.00,0.00,536000.00,58960.00,594960.00,1,NULL,'2026-05-13 00:00:00','2026-07-13 12:04:48'),
(9,'SO/2605/00009',3,NULL,'2026-05-10','2026-05-18','completed',0,11.00,770000.00,0.00,770000.00,0.00,770000.00,1,NULL,'2026-05-10 00:00:00','2026-07-13 12:04:48'),
(10,'SO/2606/00010',1,NULL,'2026-06-06','2026-07-07','completed',1,11.00,480000.00,0.00,480000.00,52800.00,532800.00,1,NULL,'2026-06-06 00:00:00','2026-07-13 12:04:48'),
(11,'SO/2606/00011',3,NULL,'2026-06-08','2026-06-16','completed',1,11.00,1425000.00,0.00,1425000.00,156750.00,1581750.00,1,NULL,'2026-06-08 00:00:00','2026-07-13 12:04:48'),
(12,'SO/2606/00012',3,NULL,'2026-06-27','2026-07-05','completed',1,11.00,994000.00,0.00,994000.00,109340.00,1103340.00,1,NULL,'2026-06-27 00:00:00','2026-07-13 12:04:48'),
(13,'SO/2607/00013',4,NULL,'2026-07-09','2026-08-09','completed',1,11.00,390000.00,0.00,390000.00,42900.00,432900.00,1,NULL,'2026-07-09 00:00:00','2026-07-13 12:04:48'),
(14,'SO/2607/00014',2,NULL,'2026-07-04','2026-07-19','completed',0,11.00,770000.00,0.00,770000.00,0.00,770000.00,1,NULL,'2026-07-04 00:00:00','2026-07-13 12:04:48'),
(15,'SO/2607/00015',4,NULL,'2026-07-11','2026-08-11','completed',1,11.00,758000.00,0.00,758000.00,83380.00,841380.00,1,NULL,'2026-07-11 00:00:00','2026-07-13 12:04:48'),
(16,'SO/2607/00016',5,1,'2026-07-13','2026-07-13','completed',0,11.00,780000.00,0.00,780000.00,85800.00,865800.00,1,NULL,'2026-07-13 00:02:46','2026-07-13 12:04:48'),
(17,'SO/2607/00017',3,1,'2026-07-13','2026-07-20','completed',0,11.00,50000.00,0.00,50000.00,0.00,50000.00,1,NULL,'2026-07-13 00:14:17','2026-07-13 12:04:48'),
(18,'SO/2607/00018',2,1,'2026-07-13','2026-07-27','completed',0,11.00,35000.00,0.00,35000.00,0.00,35000.00,1,NULL,'2026-07-13 00:31:41','2026-07-13 12:04:48'),
(19,'SO/2607/00019',5,1,'2026-07-13','2026-07-31','draft',0,11.00,30000.00,0.00,30000.00,0.00,30000.00,0,NULL,'2026-07-13 12:04:56','2026-07-13 12:04:56'),
(20,'SO/2607/00020',2,1,'2026-07-13','2026-07-23','completed',0,11.00,107000.00,0.00,107000.00,0.00,107000.00,1,NULL,'2026-07-13 12:05:27','2026-07-13 12:05:46'),
(21,'SO/2607/00021',4,1,'2026-07-13','2026-07-23','completed',0,11.00,320000.00,0.00,320000.00,0.00,320000.00,1,NULL,'2026-07-13 12:10:46','2026-07-13 12:12:22'),
(22,'SO/2607/00022',8,3,'2026-07-13','2026-07-13','cancelled',1,11.00,457980.00,0.00,457980.00,50377.80,508357.80,0,NULL,'2026-07-13 14:18:34','2026-07-13 14:24:53'),
(23,'SO/2607/00023',8,3,'2026-07-13','2026-07-13','completed',1,11.00,2012500.00,0.00,2012500.00,221375.00,2233875.00,1,NULL,'2026-07-13 14:36:25','2026-07-13 14:36:43');
/*!40000 ALTER TABLE `sales_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('Hr1G7jVKnZvTFONVGqKxo8JYJMkZUQa9DrT7m1si',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoicjJOM1ZXZWU2TllpUlUyaEo4dktVejBOTnB5a2xCZzRRMGt3Zm82NCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzQ6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9kYXNoYm9hcmQiO319',1783920070),
('IyLWlQXOS5MIk9we7OGLWCECqxFnt2eVoCq2IJ5s',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)','YToyOntzOjY6Il90b2tlbiI7czo0MDoiaEVUbXhlZGZtVWhFeVB2czQwbmhUTDg3aWM3TEwwZ0FLT3Mwc3pDMCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1783918006),
('Nnc1mKPc3gY2b210uEmtt6HQj7pkYbhm1TSODUrr',3,'127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiaFAyRG9LVDhVQXNKa3RscDk1U1MwazBQZE5xVXNNd0RRcG5LbmhRTSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjQwOiJodHRwOi8vZGxtLm1lZHotZWFzeS5jb20vaW52b2ljZXMvMjEvcGRmIjtzOjU6InJvdXRlIjtzOjEyOiJpbnZvaWNlcy5wZGYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=',1783928864),
('P4r3j6wNoCXGECAQaCq3SgL7C6WYGw3xFfnDPFuV',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)','YToyOntzOjY6Il90b2tlbiI7czo0MDoiRzhNNEJ2azVYNWRrbzd0cDJuc2FzdHYxVkNKNmhJb1BoTnNXRDk1USI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1783918005),
('s0dgRDPqxMMyxUXlOhDVJdQba3bS0OPlERQw9cPP',3,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNVlGVkltRW1LSjZrZWwzY0xSamszb1ExTHQwYmhjcEt2TXhaalVhaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9wdXJjaGFzZS1vcmRlcnMiO3M6NToicm91dGUiO3M6MjE6InB1cmNoYXNlLW9yZGVycy5pbmRleCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==',1783929050),
('SMuEJAtxDPD7N9HxXDFPlfxRDep4iu0zOHjjSYqA',NULL,'127.0.0.1','WhatsApp/2.23.20.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXBHN2J0bWlRNlFKUHhXdTc4aGVoVlJ0dldwdXBsMVAzMWFmS09ZUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1783920002),
('tNmauFL0unuQv8ywpJ9qAPEKoeawFQ3a3yuOeT5w',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0VWMWU5Qnc5dHQ0S2g5ZkQzMjZMeEQ4ZXN6d3BmaloyVEgwY1l6VSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNToiaHR0cDovL2RsbS5tZWR6LWVhc3kuY29tLiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1783918006),
('UT3bKLqYfQbWsyUOowtjKbZGGYtbts28wQ5mB9nB',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSHpOZTRkVmdnbUVmbjF5ZGJuTlQwMlZwRUxKY2g0aTFWajJXZU84YSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzQ6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9kYXNoYm9hcmQiO319',1783929959),
('wLJie49mD4iqFwIhUm7oIxhrBk0XcMG5KLzZTamA',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36 (compatible; +https://developers.cloudflare.com/security-center/)','YToyOntzOjY6Il90b2tlbiI7czo0MDoiUmdYTkY3ZVpuaHZNbWdHSno2T1AwR0p5aDk4MDgyejB3TnZDVHE2NCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1783918005),
('xQ56Qxvy93KaN4CMrzsW57mlI1UOZxTDdvRNxztr',3,'127.0.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiUjk1bGUxaEpJSDh1T0xYeWp3ZndzbEZEMXF1dW9ScXdBaVlDQ3RDeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9kbG0ubWVkei1lYXN5LmNvbS9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mzt9',1783920284);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'company_name','PT DIMAS LOVE MEDIKA','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'company_npwp','1000 0000 0468 5165','2026-07-10 20:33:43','2026-07-13 12:14:50'),
(3,'company_nib','0108250170791','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'company_izin','01082501707910001','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'company_kbli','46791 - Perdagangan Besar Alat Kesehatan dan Laboratorium untuk Manusia','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'company_address','Jl. Kodiklat TNI Buaran Hankam No. 59 RT.001/RW.003, Kel. Buaran, Kec. Serpong, Kota Tangerang Selatan, Banten 15310','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'company_phone','021-38939414 / 0859-3319-1346','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(8,'company_email','anggihdimas@gmail.com','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(9,'company_pjt','Nia Love Fiana Puteri (D.III Farmasi)','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(10,'ppn_rate','11','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(11,'fp_transaction_code','04','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(12,'fp_prefix','','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(13,'fp_last_serial','11','2026-07-10 20:52:07','2026-07-10 20:52:08'),
(14,'fp_serial_year','26','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(35,'bank_name','Bank BCA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(36,'bank_account_no','8011111629','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(37,'bank_account_holder','PT DIMAS LOVE MEDIKA','2026-07-13 12:13:43','2026-07-13 12:13:43'),
(38,'director_name','M Anggih Dimas W','2026-07-13 12:13:43','2026-07-13 12:13:43');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `warehouse_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('in','out','adjustment') NOT NULL,
  `qty` decimal(18,2) NOT NULL,
  `balance_after` decimal(18,2) NOT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `moved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_warehouse_id_foreign` (`warehouse_id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  KEY `stock_movements_product_id_moved_at_index` (`product_id`,`moved_at`),
  CONSTRAINT `stock_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` VALUES
(1,1,1,'in',57.00,357.00,'Penerimaan PO PO/2603/00001',1,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,5,1,'in',25.00,425.00,'Penerimaan PO PO/2603/00001',1,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,1,1,'in',54.00,411.00,'Penerimaan PO PO/2604/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,5,1,'in',56.00,481.00,'Penerimaan PO PO/2604/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,10,1,'in',60.00,80.00,'Penerimaan PO PO/2604/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(6,2,1,'in',44.00,194.00,'Penerimaan PO PO/2605/00003',3,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(7,5,1,'in',11.00,492.00,'Penerimaan PO PO/2605/00003',3,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(8,9,1,'in',20.00,55.00,'Penerimaan PO PO/2605/00003',3,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(9,2,1,'in',44.00,238.00,'Penerimaan PO PO/2605/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(10,5,1,'in',23.00,515.00,'Penerimaan PO PO/2605/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(11,7,1,'in',54.00,114.00,'Penerimaan PO PO/2605/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(12,10,1,'in',24.00,104.00,'Penerimaan PO PO/2606/00005',5,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(13,2,1,'in',15.00,253.00,'Penerimaan PO PO/2606/00006',6,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(14,5,1,'in',55.00,570.00,'Penerimaan PO PO/2606/00006',6,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(15,9,1,'in',43.00,98.00,'Penerimaan PO PO/2606/00006',6,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(16,5,1,'in',56.00,626.00,'Penerimaan PO PO/2607/00007',7,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(17,6,1,'in',32.00,72.00,'Penerimaan PO PO/2607/00007',7,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(18,8,1,'in',56.00,256.00,'Penerimaan PO PO/2607/00007',7,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(19,2,1,'in',55.00,308.00,'Penerimaan PO PO/2607/00008',8,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(20,4,1,'in',54.00,554.00,'Penerimaan PO PO/2607/00008',8,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(21,9,1,'in',20.00,118.00,'Penerimaan PO PO/2607/00008',8,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(22,4,1,'out',-17.00,537.00,'Sales Order SO/2603/00001',1,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(23,9,1,'out',-8.00,110.00,'Sales Order SO/2603/00001',1,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(24,1,1,'out',-2.00,409.00,'Sales Order SO/2603/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(25,6,1,'out',-6.00,66.00,'Sales Order SO/2603/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(26,9,1,'out',-15.00,95.00,'Sales Order SO/2603/00002',2,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(27,3,1,'out',-6.00,114.00,'Sales Order SO/2603/00003',3,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(28,7,1,'out',-3.00,111.00,'Sales Order SO/2603/00003',3,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(29,3,1,'out',-6.00,108.00,'Sales Order SO/2604/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(30,7,1,'out',-9.00,102.00,'Sales Order SO/2604/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(31,9,1,'out',-17.00,78.00,'Sales Order SO/2604/00004',4,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(32,3,1,'out',-16.00,92.00,'Sales Order SO/2604/00005',5,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(33,3,1,'out',-11.00,81.00,'Sales Order SO/2605/00006',6,'Demo',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07','2026-07-10 20:52:07'),
(34,10,1,'out',-9.00,95.00,'Sales Order SO/2605/00006',6,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(35,6,1,'out',-19.00,47.00,'Sales Order SO/2605/00007',7,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(36,7,1,'out',-12.00,90.00,'Sales Order SO/2605/00007',7,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(37,8,1,'out',-14.00,242.00,'Sales Order SO/2605/00007',7,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(38,1,1,'out',-8.00,401.00,'Sales Order SO/2605/00008',8,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(39,8,1,'out',-16.00,226.00,'Sales Order SO/2605/00008',8,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(40,9,1,'out',-14.00,64.00,'Sales Order SO/2605/00009',9,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(41,10,1,'out',-16.00,79.00,'Sales Order SO/2606/00010',10,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(42,2,1,'out',-15.00,293.00,'Sales Order SO/2606/00011',11,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(43,2,1,'out',-5.00,288.00,'Sales Order SO/2606/00012',12,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(44,4,1,'out',-3.00,534.00,'Sales Order SO/2606/00012',12,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(45,9,1,'out',-9.00,55.00,'Sales Order SO/2606/00012',12,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(46,7,1,'out',-3.00,87.00,'Sales Order SO/2607/00013',13,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(47,9,1,'out',-14.00,41.00,'Sales Order SO/2607/00014',14,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(48,1,1,'out',-14.00,387.00,'Sales Order SO/2607/00015',15,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(49,3,1,'out',-3.00,78.00,'Sales Order SO/2607/00015',15,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(50,5,1,'out',-8.00,618.00,'Sales Order SO/2607/00015',15,'Demo',NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08','2026-07-10 20:52:08'),
(51,7,1,'out',-6.00,81.00,'Sales Order SO/2607/00016',16,'Penjualan SO SO/2607/00016',1,'2026-07-13 00:03:12','2026-07-13 00:03:12','2026-07-13 00:03:12'),
(52,2,1,'out',-1.00,287.00,'Sales Order SO/2607/00017',17,'Penjualan SO SO/2607/00017',1,'2026-07-13 00:14:24','2026-07-13 00:14:24','2026-07-13 00:14:24'),
(53,1,1,'out',-1.00,386.00,'Sales Order SO/2607/00018',18,'Penjualan SO SO/2607/00018',1,'2026-07-13 00:31:44','2026-07-13 00:31:44','2026-07-13 00:31:44'),
(54,1,1,'out',-1.00,385.00,'Sales Order SO/2607/00020',20,'Penjualan SO SO/2607/00020',1,'2026-07-13 12:05:34','2026-07-13 12:05:34','2026-07-13 12:05:34'),
(55,3,1,'out',-1.00,77.00,'Sales Order SO/2607/00020',20,'Penjualan SO SO/2607/00020',1,'2026-07-13 12:05:34','2026-07-13 12:05:34','2026-07-13 12:05:34'),
(56,6,1,'out',-1.00,46.00,'Sales Order SO/2607/00021',21,'Penjualan SO SO/2607/00021',1,'2026-07-13 12:10:48','2026-07-13 12:10:48','2026-07-13 12:10:48'),
(57,8,1,'in',100.00,326.00,'Penerimaan PO PO/2607/00009',9,'GR GR/2607/00009',1,'2026-07-13 12:15:42','2026-07-13 12:15:42','2026-07-13 12:15:42'),
(58,7,1,'out',-3.00,78.00,'Sales Order SO/2607/00023',23,'Penjualan SO SO/2607/00023',3,'2026-07-13 14:36:32','2026-07-13 14:36:32','2026-07-13 14:36:32'),
(59,8,1,'out',-1.00,325.00,'Sales Order SO/2607/00023',23,'Penjualan SO SO/2607/00023',3,'2026-07-13 14:36:32','2026-07-13 14:36:32','2026-07-13 14:36:32'),
(60,5,1,'out',-1.00,617.00,'Sales Order SO/2607/00023',23,'Penjualan SO SO/2607/00023',3,'2026-07-13 14:36:32','2026-07-13 14:36:32','2026-07-13 14:36:32'),
(61,6,1,'out',-5.00,41.00,'Sales Order SO/2607/00023',23,'Penjualan SO SO/2607/00023',3,'2026-07-13 14:36:32','2026-07-13 14:36:32','2026-07-13 14:36:32'),
(62,23,1,'in',1.00,12.98,'Penerimaan PO PO/2607/00010',10,'GR GR/2607/00010',3,'2026-07-13 14:50:43','2026-07-13 14:50:43','2026-07-13 14:50:43'),
(63,3,1,'in',1.00,78.00,'Penerimaan PO PO/2607/00010',10,'GR GR/2607/00010',3,'2026-07-13 14:50:43','2026-07-13 14:50:43','2026-07-13 14:50:43'),
(64,2,1,'in',1.00,288.00,'Penerimaan PO PO/2607/00010',10,'GR GR/2607/00010',3,'2026-07-13 14:50:43','2026-07-13 14:50:43','2026-07-13 14:50:43'),
(65,3,1,'in',1.00,79.00,'Penerimaan PO PO/2607/00010',10,'GR GR/2607/00010',3,'2026-07-13 14:50:43','2026-07-13 14:50:43','2026-07-13 14:50:43');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payments`
--

DROP TABLE IF EXISTS `supplier_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_payments_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `supplier_payments_user_id_foreign` (`user_id`),
  CONSTRAINT `supplier_payments_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supplier_payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payments`
--

LOCK TABLES `supplier_payments` WRITE;
/*!40000 ALTER TABLE `supplier_payments` DISABLE KEYS */;
INSERT INTO `supplier_payments` VALUES
(1,1,NULL,'2026-03-19',1489065.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,4,NULL,'2026-05-20',3765250.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,5,NULL,'2026-06-26',180000.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,6,NULL,'2026-06-29',1316183.00,'transfer',NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,9,1,'2026-07-13',999000.00,NULL,NULL,'2026-07-13 12:15:25','2026-07-13 12:15:25'),
(6,10,3,'2026-07-13',245310.00,NULL,NULL,'2026-07-13 14:50:00','2026-07-13 14:50:00');
/*!40000 ALTER TABLE `supplier_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `npwp` varchar(30) DEFAULT NULL,
  `payment_term_days` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES
(1,'SUP-0001','PT Onemed Distribusi','Sales Onemed','021-7770001',NULL,NULL,'03.111.222.3-093.000',30,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'SUP-0002','PT Enseval Medika Prima','Sales Enseval','021-7770002',NULL,NULL,'04.222.333.4-093.000',45,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'SUP-0003','CV Sumber Medis Jaya','Bpk. Hendra','0813-3333-4444',NULL,NULL,'',14,1,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'SUP-0004','Sarana Maju Sejahtera',NULL,NULL,NULL,NULL,NULL,0,1,'2026-07-13 14:48:51','2026-07-13 14:48:51');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_invoices`
--

DROP TABLE IF EXISTS `tax_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('output','input') NOT NULL,
  `tax_number` varchar(255) NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `purchase_order_id` bigint(20) unsigned DEFAULT NULL,
  `partner_name` varchar(255) NOT NULL,
  `partner_npwp` varchar(30) DEFAULT NULL,
  `date` date NOT NULL,
  `dpp` decimal(18,2) NOT NULL DEFAULT 0.00,
  `ppn_rate` decimal(5,2) NOT NULL DEFAULT 11.00,
  `ppn` decimal(18,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_invoices_tax_number_unique` (`tax_number`),
  KEY `tax_invoices_invoice_id_foreign` (`invoice_id`),
  KEY `tax_invoices_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `tax_invoices_user_id_foreign` (`user_id`),
  KEY `tax_invoices_type_date_index` (`type`,`date`),
  CONSTRAINT `tax_invoices_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tax_invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_invoices`
--

LOCK TABLES `tax_invoices` WRITE;
/*!40000 ALTER TABLE `tax_invoices` DISABLE KEYS */;
INSERT INTO `tax_invoices` VALUES
(1,'output','040.000-26.00000001',2,NULL,'Apotek Kimia Farmasi','','2026-03-23',2815000.00,11.00,309650.00,NULL,NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(2,'output','040.000-26.00000002',3,NULL,'Apotek Kimia Farmasi','','2026-03-23',822000.00,11.00,90420.00,NULL,NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(3,'output','040.000-26.00000003',4,NULL,'RS Medika Sentosa','01.234.567.8-091.000','2026-04-23',2537000.00,11.00,279070.00,NULL,NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(4,'output','040.000-26.00000004',5,NULL,'Klinik Sehat Bersama','02.345.678.9-091.000','2026-04-23',1152000.00,11.00,126720.00,NULL,NULL,'2026-07-10 20:52:07','2026-07-10 20:52:07'),
(5,'output','040.000-26.00000005',6,NULL,'Puskesmas Serpong','','2026-05-08',1062000.00,11.00,116820.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(6,'output','040.000-26.00000006',8,NULL,'RS Medika Sentosa','01.234.567.8-091.000','2026-05-14',536000.00,11.00,58960.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(7,'output','040.000-26.00000007',10,NULL,'RS Medika Sentosa','01.234.567.8-091.000','2026-06-07',480000.00,11.00,52800.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(8,'output','040.000-26.00000008',11,NULL,'Apotek Kimia Farmasi','','2026-06-09',1425000.00,11.00,156750.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(9,'output','040.000-26.00000009',12,NULL,'Apotek Kimia Farmasi','','2026-06-28',994000.00,11.00,109340.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(10,'output','040.000-26.00000010',13,NULL,'Puskesmas Serpong','','2026-07-10',390000.00,11.00,42900.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08'),
(11,'output','040.000-26.00000011',15,NULL,'Puskesmas Serpong','','2026-07-12',758000.00,11.00,83380.00,NULL,NULL,'2026-07-10 20:52:08','2026-07-10 20:52:08');
/*!40000 ALTER TABLE `tax_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES
(1,'Pieces','pcs','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Box','box','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(3,'Unit','unit','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(4,'Set','set','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(5,'Pack','pack','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(6,'Lusin','lsn','2026-07-10 20:33:43','2026-07-10 20:33:43'),
(7,'Vial','Vial','2026-07-13 12:28:55','2026-07-13 12:29:17'),
(8,'Botol','btl','2026-07-13 13:23:41','2026-07-13 13:23:41');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Administrator','admin@dimaslovemedika.com','2026-07-10 20:33:43','$2y$12$oCqRgpSNOFj/tgjHtDDqUecJBBYnOZPuYY5c9E7GNTf6Q5lw5bFlK',1,NULL,'2026-07-10 20:33:43','2026-07-10 20:33:43'),
(2,'Staff Operasional','staff@dimaslovemedika.com','2026-07-10 20:33:44','$2y$12$Yg6Wf6sq6ZjqE1tPxacIbOTcrwDFuFVjaNcCpJe1e1G6hfUORuW4.',1,NULL,'2026-07-10 20:33:44','2026-07-10 20:33:44'),
(3,'rafli','admin@rafli.com',NULL,'$2y$12$ve0fYV0BDzI/j2M3iY43guTLzgK.dxAAj5OUONIl8qVzkIUj3p7BG',1,NULL,'2026-07-13 12:19:51','2026-07-13 12:19:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` VALUES
(1,'Gudang Utama','Jl. Kodiklat TNI Buaran Hankam No. 59, Serpong, Tangerang Selatan',1,1,'2026-07-10 20:33:43','2026-07-10 20:33:43');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dlm_medika'
--

--
-- Dumping routines for database 'dlm_medika'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-13  8:09:31
